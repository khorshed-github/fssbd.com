<?php
include 'conf/conn.php';
$_SESSION['flc_admin'] = 1;

?>