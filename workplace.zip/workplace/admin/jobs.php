<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
  if(loggedin() == false){
	  header("Location:login.php");
  }

  if(checkaccess($_SESSION['flc_admin'], 'jobs.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
//DELETE FROM `jobs2` WHERE `id` > '100'
  error_reporting(0);
//print_r($_SESSION);
if(isset($_GET['create'])){
	$date = sanetize($_GET['create']);
	create_jobs_status($date);
	header('Location:jobs.php');
}
$error = array();
if(isset($_POST['copy_from'])){
    $from = sanetize($_POST['copy_from']);
    $to = sanetize($_POST['copy_to']);
    if(!empty($from) && !empty($to)){
        $from_sql = get_table_data_specific('jobs2','date',$from);
        $to_sql = get_table_data_specific('jobs2','date',$to);
        //create_jobs_status($to);
		if($from_sql->num_rows !== 0){
			$update  = mysqli_query($db, "UPDATE `jobs2` SET `date` = '$to' WHERE `date` = '$from'");
			header('Location:jobs.php');
        }else{
             $error[] = 'There is no job from this date';
        }
    }else{
        $error[] = 'All Fields Required';
    }
}
?>
	
	<div class="container col-md-10 col-sm-10"  >
		<div class="panel panel-default" >
		    <div class="panel-body" >
		        <?php if(!empty($error)){echo '<div class="alert alert-danger" >'.$error[0].'</div>';}?>
		        <form action="jobs.php" method="post" class="form-inline pull-left">
        			<div class="form-group">
        			    Move Job From
        			</div>
        			<div class="form-group">
        				<input type="text" name="copy_from"  id="datepicker3" class="form-control"   />
        			</div>
        			<div class="form-group">
        			   To
        			</div>
        			<div class="form-group">
        				<input type="text" name="copy_to"  id="datepicker4" class="form-control"   />
        			</div>
        			<div class="form-group">
        				<input type="submit" value="COPY JOBS" class="btn btn-primary" />
        			</div>
        		</form>
		    </div>
		</div>
		<form action="jobs.php" class="form-inline pull-left">
			<div class="form-group">
				<input type="text" name="create"  id="datepicker" class="form-control"   />
			</div>
			<div class="form-group">
				<input type="submit" value="CREATE JOB BY DATE" class="btn btn-primary" />
			</div>
		</form>
		<form class="form-inline" action="jobs.php" method="get" >
			
			<div class="form-group">
				<input type="text" name="date"  id="datepicker2" class="form-control"   />
			</div>
			<div class="form-group">
				<input type="submit" value="SEARCH JOB BY DATE" class="btn btn-primary" />
			</div>
			<?php if(isset($_GET['date'])){?>
				<a href="tasks.php?date=<?php echo sanetize($_GET['date']);?>" class="btn btn-primary">Set Jobs</a>
			<?php }?>
		</form>
		<br />
		<div class="table-responsive">
			<table class="table table-bordered table-striped">
				<tr>
					<th>Action</th>
					<th>Job</th>
					<th>Step</th>
					
					
				</tr>
				<?php 
				if(!isset($_GET['list'])){
				$sl = 1;
				foreach(get_table_data_specific('jobs2','date',sanetize($_GET['date'])) as $jobs){
					if($sl < 11){
					?>
					<tr>
						<td>
							<a href="jobs2.php?view=<?php echo $jobs['id']?>" class="btn btn-info btn-xs">View</a>
						</td>
						<td><?php echo $jobs['taskid'];?></td>
						<td><?php echo $jobs['step'];?></td>
						
					</tr>
					<?php }
					$sl++;
				}}else{
					foreach(paginationed_job(sanetize($_GET['list']),sanetize($_GET['date'])) as $jobs){
					
					?>
					<tr>
						<td class="form-inline" style="width:50px;" >
							<a href="jobs2.php?view=<?php echo $jobs['id']?>" class="btn btn-info btn-xs">View</a>
						</td>
						<td><?php echo $jobs['taskid'];?></td>
						<td><?php echo $jobs['step'];?></td>
						
					</tr>
					<?php }
				}?>
			</table>
		</div>
				<div class="pagination">
					  <?php 
					  $count = 0;
					  
					  $rows = pagination_list_job($_GET['date']);
					  if($rows > 1){
						for($count = 0; $count < $rows; $count++ ){?>
						<li><a class="table_pagination_links <?php if($_GET['list'] == $count){echo 'active';}?>" <?php if($count  > ($_GET['list'] + 4)){echo 'style="display:none;"';}else if($count  < ($_GET['list'] - 4)){echo 'style="display:none;"';}?>  href="jobs.php?date=<?php echo $_GET['date']?>&list=<?php echo $count;?>"><?php echo $count+1;?></a></li>
					  <?php }}?>
				</div>
	</div>
<?php
  include 'include/footer.php';
?>