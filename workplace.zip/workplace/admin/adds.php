<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
  if(loggedin() == false){
	  header("Location:login.php");
  }

  if(checkaccess($_SESSION['flc_admin'], 'adds.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
error_reporting(0);
if(isset($_GET['delete'])){
    $id = sanetize($_GET['delete']);
    $sql = mysqli_query($db, "DELETE FROM `adds` WHERE `id` = '$id'");
    if($sql == true){
        header('Location:adds.php');
    }
}
if(isset($_POST['type'])){
	$type 	= sanetize($_POST['type']);
	$script = urlencode($_POST['script']);
	echo $script;
	$link 	= sanetize($_POST['link']);
	$date 	= sanetize($_POST['date']);
	if($type == '1'){
		if(!empty($script)){
			$sql = mysqli_query($db, "INSERT INTO `adds` 
			(`type`,`script`,`date`)
			VALUES
			('$type','$script','$date')
			");
			if($sql == true){
				header('Location:adds.php');
			}
		}else{
			$error[] = 'all fields required';
		}
	}else if($type == '2'){
		$image = $_FILES['file']['name'];
		$tmp_name = $_FILES['file']['tmp_name'];
		$rand = rand(1000000,9000000);
		$image_name = $rand.$image;
		move_uploaded_file($tmp_name, '../images/ads/'.$image_name);
		if(!empty($link)){
			$sql = mysqli_query($db, "INSERT INTO `adds` 
				(`type`,`link`,`image`,`date`)
				VALUES
				('$type','$link','$image_name','$date')
				");	
			if($sql == true){
				header('Location:adds.php');
			}
		}else{
			$error[] = 'all fields required';
		}
	}
}
if(isset($_POST['edit_type'])){
	$type 	= sanetize($_POST['edit_type']);
	$script = urlencode($_POST['edit_script']);
	$link 	= sanetize($_POST['edit_link']);
	$date 	= sanetize($_POST['edit_date']);
	if($type == '1'){
		if(!empty($script)){
			$sql = mysqli_query($db, "UPDATE `adds` 
			SET 
			`type` = '$type',
			`script` = '$script',
			`date` = '$date'
			WHERE `id` = '".$_GET['edit']."'");
			if($sql == true){
				header('Location:adds.php');
			}else{
				$error[] = mysqli_error($db);
			}
		}else{
			$error[] = 'all fields required';
		}
	}else if($type == '2'){
		$image = $_FILES['edit_file']['name'];
		$tmp_name = $_FILES['edit_file']['tmp_name'];
		$rand = rand(1000000,9000000);
		$image_name = $rand.$image;
		move_uploaded_file($tmp_name, '../images/ads/'.$image_name);
		if(!empty($link)){
			$sql = mysqli_query($db, "UPDATE `adds` 
				SET `type` = '$type',
				`link` = '$link',
				`image` = '$image_name',
				`date` = '$date'
				WHERE `id` = '".$_GET['edit']."'");	
			if($sql == true){
				header('Location:adds.php');
			}
		}else{
			$error[] = 'all fields required';
		}
	}
}

if(isset($_POST['banner_edit_type'])){
	$type 	= sanetize($_POST['banner_edit_type']);
	$script = urlencode($_POST['banner_edit_script']);
	$link 	= sanetize($_POST['banner_edit_link']);
	$date 	= sanetize($_POST['banner_edit_date']);
	if($type == '1'){
		if(!empty($script)){
			$sql = mysqli_query($db, "UPDATE `banners` 
			SET `type` = '$type',
			`script` = '$script',
			`date` = '$date'
			WHERE `id` = '".$_GET['banner_edit']."'");
			if($sql == true){
				header('Location:adds.php');
			}else{
				$error[] = mysqli_error($db);
			}
		}else{
			$error[] = 'all fields required';
		}
	}else if($type == '2'){
		$image = $_FILES['banner_edit_file']['name'];
		$tmp_name = $_FILES['banner_edit_file']['tmp_name'];
		$rand = rand(1000000,9000000);
		$image_name = $rand.$image;
		move_uploaded_file($tmp_name, '../images/ads/'.$image_name);
		if(!empty($link)){
			$sql = mysqli_query($db, "UPDATE `banners` 
				SET `type` = '$type',
				`link` = '$link',
				`image` = '$image_name',
				`date` = '$date'
				WHERE `id` = '".$_GET['banner_edit']."'");	
			if($sql == true){
				header('Location:adds.php');
			}
		}else{
			$error[] = 'all fields required';
		}
	}
}
?>
	
	<div class="container col-md-10 col-sm-10">
		 
		 <div href="#" class="" style="text-decoration:none;">
			<?php if(isset($_GET['new'])){?>
				<div class="panel panel-default">
					<div class="panel-heading">
						Place New Ad
					</div>
					<div class="panel-body">
						<form action="<?php echo $_SERVER['REQUEST_URI']?>" method="post" class="form-inline" enctype="multipart/form-data" >
							<div class="form-group">
								<select name="type" id="" class="form-control"  >
									<option value="0">Select Ad Type</option>
									<option value="1">Script</option>
									<option value="2">Link</option>
								</select>
							</div>
							<div class="form-group">
								<!--<input type="text" name="script"  placeholder="script" class="form-control"  />-->
								<textarea name="script" ></textarea>
							</div>
							<div class="form-group">
								<input type="text" name="link" placeholder="link" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="file" name="file" placeholder="image" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="text" name="date"  id="datepicker"  value="<?php echo dates();?>" name="file" placeholder="image" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="submit" value="Insert " class="btn btn-success"   />
							</div>
						</form>
						
					</div>
				</div>
			<?php }else if($_GET['edit']){?>
				<div class="panel panel-default">
					<div class="panel-heading">
						Edit
					</div>
					<div class="panel-body">
						<form action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post" class="form-inline" enctype="multipart/form-data" >
							<div class="form-group">
								<select name="edit_type" id="" class="form-control"  >
									<option value="0">Select Ad Type</option>
									<option value="1">Script</option>
									<option value="2">Link</option>
								</select>
							</div>
							<div class="form-group">
								<input type="text" name="edit_script" <?php echo 'value="'.get_table_data_single_row('adds','id',sanetize($_GET['edit']),'script').'"'; ?> placeholder="script" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="text" name="edit_link" <?php echo 'value="'.get_table_data_single_row('adds','id',sanetize($_GET['edit']),'link').'"'; ?> placeholder="link" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="file" name="edit_file" placeholder="image" class="form-control"  />
							</div>
							
							<div class="form-group">
								<input type="text" name="edit_date"  id="datepicker"  value="<?php echo dates();?>" name="file" placeholder="image" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="submit" value="Insert " class="btn btn-success"   />
							</div>
						</form>
						
					</div>
				</div>
			<?php }else if($_GET['banner_edit']){ ?>
				<div class="panel panel-default">
					<div class="panel-heading">
						Edit
					</div>
					<div class="panel-body">
						<form action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post" class="form-inline" enctype="multipart/form-data" >
							<div class="form-group">
								<select name="banner_edit_type" id="" class="form-control"  >
									<option value="0">Select Ad Type</option>
									<option value="1">Script</option>
									<option value="2">Link</option>
								</select>
							</div>
							<div class="form-group">
								<input type="text" name="banner_edit_script" <?php echo 'value="'.get_table_data_single_row('banners','id',sanetize($_GET['banner_edit']),'script').'"'; ?> placeholder="script" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="text" name="banner_edit_link" <?php echo 'value="'.get_table_data_single_row('banners','id',sanetize($_GET['banner_edit']),'link').'"'; ?> placeholder="link" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="file" name="banner_edit_file" placeholder="image" class="form-control"  />
							</div>
							
							<div class="form-group">
								<input type="text" name="banner_edit_date"  id="datepicker"  value="<?php echo dates();?>" name="file" placeholder="image" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="submit" value="Insert " class="btn btn-success"   />
							</div>
						</form>
						
					</div>
				</div>
			<?php }?>
			<div class="panel panel-default">
				<div class="panel-heading">
					<h4>Banner Adds</h4>
				</div>
				
				<div class="panel-body table-responsive">
					<table class="table table-bordered table-striped">
						<tr class="text-nowrap" >
							<th>Action</th>
							<th>AD Type</th>
							<th>Script</th>
							<th>Link</th>
							<th>Image Name</th>
							<th>Date</th>
							
						</tr>
						<?php 
						
						foreach(get_table_data_all('banners') as $users){?>
							<tr>
								
								<td>
									<a href="adds.php?banner_edit=<?php echo $users['id'];?>" class="btn btn-success btn-xs" >Edit</a>
								</td>
								<td><?php 
								if($users['type'] == '1'){
									echo 'Script';
								}else if($users['type'] == '2'){
									echo 'Link';
								}
								?></td>
								<td><?php echo $users['script']?></td>
								<td><?php echo $users['link']?></td>
								<td><?php echo $users['image']?></td>
								<td><?php echo $users['date']?></td>
								
							</tr>
						<?php }?>
					</table>
				</div>
				
			</div>
			<div class="panel panel-default">
				<div class="panel-heading">
					<h4>Rendom Ads</h4>
				</div>
				
				<div class="panel-body table-responsive">
					<a href="adds.php?new" class="btn btn-primary" >Place New Add</a>
					<br />
					<br />
					<table class="table table-bordered table-striped">
						<tr class="text-nowrap" >
							<th>Action</th>
							<th>AD Type</th>
							<th>Script</th>
							<th>Link</th>
							<th>Image Name</th>
							<th>Date</th>
							
						</tr>
						<?php 
						if(!isset($_GET['list'])){
						foreach(get_ten_data('adds') as $users){?>
							<tr>
								
								<td>
								    <a href="adds.php?delete=<?php echo $users['id'];?>" class="btn btn-success btn-xs" >Delete</a>
									<a href="adds.php?edit=<?php echo $users['id'];?>" class="btn btn-success btn-xs" >Edit</a>
								</td>
								<td><?php 
								if($users['type'] == '1'){
									echo 'Script';
								}else if($users['type'] == '2'){
									echo 'Link';
								}
								?></td>
								<td><?php echo $users['script']?></td>
								<td><?php echo $users['link']?></td>
								<td><?php echo $users['image']?></td>
								<td><?php echo $users['date']?></td>
								
							</tr>
						<?php }}else{
							foreach(paginationed($_GET['list'],'adds') as $users){
							?>
							<tr>
								
								<td>
									<a href="adds.php?edit=<?php echo $users['id'];?>" class="btn btn-success btn-xs" >Edit</a>
								</td>
								<td><?php 
								if($users['type'] == '1'){
									echo 'Script';
								}else if($users['type'] == '2'){
									echo 'Link';
								}
								?></td>
								<td><?php echo $users['script']?></td>
								<td><?php echo $users['link']?></td>
								<td><?php echo $users['image']?></td>
								<td><?php echo $users['date']?></td>
								
							</tr>
							<?php }}?>
					</table>
				</div>
				<div class="pagination col-md-12">
					  <?php 
					  $count = 0;
					  
					  $rows = pagination_list('adds');
					  if($rows > 1){
						for($count = 0; $count < $rows; $count++ ){?>
						<li><a class="table_pagination_links <?php if($_GET['list'] == $count){echo 'active';}?>" <?php if($count  > ($_GET['list'] + 4)){echo 'style="display:none;"';}else if($count  < ($_GET['list'] - 4)){echo 'style="display:none;"';}?>  href="adds.php?list=<?php echo $count;?>"><?php echo $count+1;?></a></li>
					  <?php }}?>
				</div>
			</div>
		</div>
	</div>
<?php
  include 'include/footer.php';
?>