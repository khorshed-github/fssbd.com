<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
  error_reporting(0);
  if(loggedin() == false){
	  header("Location:login.php");
  }

  if(checkaccess($_SESSION['flc_admin'], 'varification.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
  //sendsms('01813404900','test_message');
  //sendsms('01813404900','Dear SELF EMPLOYMENTS user, You have got '.$bdt.'TK joining commission for level '.$level.' User '.get_table_data_single_row('flc_users','id',$uid,'number'));
    			
  //print_r($_SESSION);
  //error_reporting(0);
if(isset($_GET['accept'])){
	$id = sanetize($_GET['accept']);
	
	$uid = get_table_data_single_row('varify','id',$id,'uid');
	$sql = mysqli_query($db, "UPDATE `flc_users` SET `varify` = '1' WHERE `id` = '$uid'");
	$admin_id = $_SESSION['flc_admin'];
	sendsms(get_table_data_single_row('flc_users','id',$uid,'number'),'Welcome, Your SELF EMPLOYMENTS  account has been successfully Varified. Thanks for being with us');
    $sql2 = mysqli_query($db, "UPDATE `varify` SET `status` = '1',`accept` = '$admin_id' WHERE `id` = '$id'");    		

}
if(isset($_GET['cancel'])){
	$id = sanetize($_GET['cancel']);

    $sql = mysqli_query($db, "DELETE FROM `varify` WHERE `id` = '$id'");
	header('Location:varification.php');
}

?>
	
	<div class="container col-md-10 col-sm-10"  >
		 
		 <div href="#" class="" style="text-decoration:none;">
			
			<!--
			<div class="panel panel-body">
				<div class="panel-body">
					<form action="act_request.php?search" method="post"  class="form-inline pull-left form-group">
						<div class="input-group">
						  <input type="text" placeholder="Search By Name" name="sr_name"  class="form-control" aria-label="...">
						  <div class="input-group-btn">
							<button class="btn btn-success" >Search</button>
						  </div>
						</div>
					</form>
					<form action="act_request.php?search" method="post"  class="form-inline pull-left form-group">
						<div class="input-group">
						  <input type="text" placeholder="Search By Mobile" name="sr_mobile"   class="form-control" aria-label="...">
						  <div class="input-group-btn">
							<button class="btn btn-success" >Search</button>
						  </div>
						</div>
					</form>
					<form action="act_request.php?search" method="post"  class="form-inline pull-left form-group">
						<div class="input-group">
						  <input type="text" placeholder="Search By Refer ID" name="sr_referid"   class="form-control" aria-label="...">
						  <div class="input-group-btn">
							<button class="btn btn-success" >Search</button>
						  </div>
						</div>
					</form>
					<form action="act_request.php?search" method="post"  class="form-inline pull-left form-group">
						<div class="input-group">
						  <input type="text" placeholder="Search By Sender Number" name="sr_sender"   class="form-control" aria-label="...">
						  <div class="input-group-btn">
							<button class="btn btn-success" >Search</button>
						  </div>
						</div>
					</form>
					<form action="act_request.php?search" method="post"  class="form-inline pull-left form-group">
						<div class="input-group">
						  <input type="text" placeholder="Search By TrxID" name="sr_trxid"   class="form-control" aria-label="...">
						  <div class="input-group-btn">
							<button class="btn btn-success" >Search</button>
						  </div>
						</div>
					</form>
					
					<form action="act_request.php?search" method="post"  class="form-inline pull-left form-group">
						<div class="input-group">
						  <input type="text" id="datepicker3"  placeholder="Search By Request Date" name="sr_date"   class="form-control" aria-label="..."/>
						  <div class="input-group-btn">
							<button class="btn btn-success" >Search</button>
						  </div>
						</div>
					</form>
					
				</div>
			</div>
			-->
			<div class="panel panel-default">
				<div class="panel-heading">
					<h4>Varification Requests</h4>
				</div>
				<div class="panel-body table-responsive">
					<table class="table table-bordered table-striped">
						<tr class="text-nowrap" >
							<th>Action</th>
							<th>Name</th>
							<th>Mobile-Number</th>
							<th>Referrance-Number</th>
							<th>Referr ID</th>
						
							<th>Date</th>
							<th>Time</th>
							<th>Accepted By</th>
						</tr>
						<?php 
						if(isset($_GET['search'])){
							foreach($search as $users){?>
								<tr>
									<td>
										<?php if($users['status'] == '0'){?>
											<a class="btn btn-success btn-sm" href="varification.php?accept=<?php echo $users['id'];?>">Accept</a>
											<a class="btn btn-danger btn-sm"  href="varification.php?cancel=<?php echo $users['id'];?>">Cancel</a>
										<?php }else if($users['status'] == '1'){
											echo 'Accepted';
										}?>
									</td>
									<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'username')?></td>
									<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'number')?></td>
									<td><?php echo get_table_data_single_row('flc_users','id',get_table_data_single_row('flc_users','id',$users['uid'],'ref'),'number')?></td>
									<td><?php echo 112233 + $users['uid']?></td>
								
									<td><?php echo $users['date']?></td>
									<td><?php echo $users['time']?></td>
									<td><?php echo get_table_data_single_row('admin','id',$users['accept'],'number')?></td>
									
								</tr>
							<?php }
						}else{
						if(!isset($_GET['list'])){
						foreach(get_ten_data('varify') as $users){?>
							<tr>
								<td>
									<?php if($users['status'] == '0'){?>
										<a class="btn btn-success btn-sm" href="varification.php?accept=<?php echo $users['id'];?>">Accept</a>
										<a class="btn btn-danger btn-sm"  href="varification.php?cancel=<?php echo $users['id'];?>">Cancel</a>
									<?php }else if($users['status'] == '1'){
										echo 'Accepted';
									}?>
								</td>
								<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'username')?></td>
								<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'number')?></td>
								<td><?php echo get_table_data_single_row('flc_users','id',get_table_data_single_row('flc_users','id',$users['uid'],'ref'),'number')?></td>
								<td><?php echo 112233 + $users['uid']?></td>
							
								<td><?php echo $users['date']?></td>
								<td><?php echo $users['time']?></td>
								<td><?php echo get_table_data_single_row('admin','id',$users['accept'],'number')?></td>
								
							</tr>
						<?php }}else{
							foreach(paginationed($_GET['list'],'varify') as $users){
							?>
							<tr>
								<td>
									<?php if($users['status'] == '0'){?>
										<a class="btn btn-success btn-sm" href="varification.php?accept=<?php echo $users['id'];?>">Accept</a>
										<a class="btn btn-danger btn-sm"  href="varification.php?cancel=<?php echo $users['id'];?>">Cancel</a>
									<?php }else if($users['status'] == '1'){
										echo 'Accepted';
									}?>
								</td>
								<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'username')?></td>
								<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'number')?></td>
								<td><?php echo get_table_data_single_row('flc_users','id',get_table_data_single_row('flc_users','id',$users['uid'],'ref'),'number')?></td>
								<td><?php echo 112233 + $users['id']?></td>
							
								<td><?php echo $users['date']?></td>
								<td><?php echo $users['time']?></td>
								<td><?php echo get_table_data_single_row('admin','id',$users['accept'],'number')?></td>
								
							</tr>
							<?php }}}?>
					</table>
				</div>
				<?php if(!isset($_GET['search'])){?>
					<div class="pagination">
						  <?php 
						  $count = 0;
						  
						  $rows = pagination_list('varify');
						  if($rows > 1){
							for($count = 0; $count < $rows; $count++ ){?>
							<li><a class="table_pagination_links <?php if($_GET['list'] == $count){echo 'active';}?>" <?php if($count  > ($_GET['list'] + 4)){echo 'style="display:none;"';}else if($count  < ($_GET['list'] - 4)){echo 'style="display:none;"';}?>  href="varification.php?list=<?php echo $count;?>"><?php echo $count+1;?></a></li>
						  <?php }}?>
					</div>
				<?php }?>
			 </div>
		 </div>
		
		
		
		 
		 
	</div>
<?php
  include 'include/footer.php';
?>