<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
  if(loggedin() == false){
	  header("Location:login.php");
  }
    if(loggedin() == false){
	  header("Location:login.php");
  }
  if(checkaccess($_SESSION['flc_admin'], 'addfund.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
 error_reporting(0);
if(isset($_GET['accept'])){
	$id = sanetize($_GET['accept']);
	$uid = get_table_data_single_row('addfund','id',$id,'uid');
	$number = get_table_data_single_row('flc_users','id',$uid,'number');
	$balance = get_table_data_single_row('flc_users','id',$uid,'balance');
	$amount = get_table_data_single_row('addfund','id',$id,'amount');
	$new_balance = $balance + $amount;
	$sql = mysqli_query($db, "UPDATE `flc_users` SET `balance` = '$new_balance' WHERE `id` = '$uid'");
	accounts_update($uid,$amount,'Deposit Request accepted and deposited to balance',$balance,$new_balance,'cr');
	sendsms($number,'Dear  user, Your deposit request accepted and deposited to balance');
	$update  = mysqli_query($db, "UPDATE `addfund` SET `status` = '1' WHERE `id` = '$id'");
	header('Location:addfund.php');
}
if(isset($_GET['cancel'])){
	$id = sanetize($_GET['cancel']);
	$uid = get_table_data_single_row('addfund','id',$id,'uid');
	$number = get_table_data_single_row('flc_users','id',$uid,'number');
	sendsms($number,'Dear  user, Your deposit request has been canceled');
	$update  = mysqli_query($db, "UPDATE `addfund` SET `status` = '2' WHERE `id` = '$id'");
	header('Location:addfund.php');
}
?>
	
	<div class="container col-md-10 col-sm-10"  >
		 
		 <div href="#" class="" style="text-decoration:none;">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h4>Deposit Requests</h4>
				</div>
				<div class="panel-body table-responsive">
					<table class="table table-bordered table-striped">
						<tr class="text-nowrap" >
							<th>Action</th>
							<th>User-Number</th>
							<th>Sender Number</th>
							<th>Payment Method</th>
							<th>Amount</th>
							<th>Transection ID</th>
							<th>Date</th>
							<th>Time</th>
							
						</tr>
						<?php 
						if(!isset($_GET['list'])){
						foreach(get_ten_data('addfund') as $users){?>
							<tr>
								<td>
									<?php if($users['status'] == '1'){
										echo 'Accepted';
									}else if($users['status'] == '2'){
										echo 'Canceled';
									}else if($users['status'] == '0'){?>
										<div class="dropdown">
										  <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
											Action
											<span class="caret"></span>
										  </button>
											<ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
												<li><a href="addfund.php?accept=<?php echo $users['id'];?>">Accept </a></li>
												<li><a href="addfund.php?cancel=<?php echo $users['id'];?>">Cancel</a></li>
											</ul>
										</div>
									<?php }?>
								</td>
								<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'number');?></td>
								<td><?php echo $users['sender']?></td>
								<td><?php echo $users['method']?></td>
								<td><?php echo $users['amount']?></td>
								<td><?php echo $users['trxid']?></td>
								<td><?php echo $users['date']?></td>
								<td><?php echo $users['time']?></td>
								
							</tr>
						<?php }}else{
							foreach(paginationed($_GET['list'],'addfund') as $users){
							?>
							<tr>
								<td>
									<?php if($users['status'] == '1'){
										echo 'Accepted';
									}else if($users['status'] == '2'){
										echo 'Canceled';
									}else if($users['status'] == '0'){?>
										<div class="dropdown">
										  <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
											Action
											<span class="caret"></span>
										  </button>
											<ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
												<li><a href="addfund.php?accept=<?php echo $users['id'];?>">Accept </a></li>
												<li><a href="addfund.php?cancel=<?php echo $users['id'];?>">Cancel</a></li>
											</ul>
										</div>
									<?php }?>
								</td>
								<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'number');?></td>
								<td><?php echo $users['sender']?></td>
								<td><?php echo $users['method']?></td>
								<td><?php echo $users['amount']?></td>
								<td><?php echo $users['trxid']?></td>
								<td><?php echo $users['date']?></td>
								<td><?php echo $users['time']?></td>
								
							</tr>
							<?php }}?>
					</table>
				</div>
				<div class="pagination">
					  <?php 
					  $count = 0;
					  
					  $rows = pagination_list('addfund');
					  if($rows > 1){
						for($count = 0; $count < $rows; $count++ ){?>
						<li><a class="table_pagination_links <?php if($_GET['list'] == $count){echo 'active';}?>" <?php if($count  > ($_GET['list'] + 4)){echo 'style="display:none;"';}else if($count  < ($_GET['list'] - 4)){echo 'style="display:none;"';}?>  href="addfund.php?list=<?php echo $count;?>"><?php echo $count+1;?></a></li>
					  <?php }}?>
				</div>
			 </div>
		 </div>
		
		
		
		 
		 
	</div>
<?php
  include 'include/footer.php';
?>