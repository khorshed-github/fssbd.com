<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
  if(loggedin() == false){
	  header("Location:login.php");
  }
  if(checkaccess($_SESSION['flc_admin'], 'userlist.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
  //print_r($_SESSION);
  //error_reporting(0);
  if(isset($_GET['remove'])){
	  $uid = sanetize($_GET['remove']);
	  
		  
		  $sql = mysqli_query($db, "UPDATE `flc_users` SET `dp` = '0' WHERE `id` = '$uid'");
		 if($sql == true){
			  header("Location:dps.php");
		  }
	  
  }
  if(isset($_GET['make_dp'])){
	  $uid = get_table_data_single_row('flc_users','number',sanetize($_GET['make_dp']),'id');
	  
	  
		 
		  $sql = mysqli_query($db, "UPDATE `flc_users` SET `dp` = '1' WHERE `id` = '$uid'");
		  if($sql == true){
			  header("Location:dps.php");
		  }
	 
  }
if(isset($_POST['smstext'])){
  $uid = sanetize($_GET['sendsms']);
  $number = get_table_data_single_row('flc_users','id',$uid,'number');
  $message = sanetize($_POST['smstext']);
  if(!empty($message)){
	  sendsms($number, $message);
	  header('Location:userlist.php');
  }
}
  if(isset($_POST['remarks'])){
	$uid = sanetize($_GET['fundupdate']);
	$add = sanetize($_POST['add']);
	$cut = sanetize($_POST['cut']);
	$remarks = sanetize($_POST['remarks']);
		if(!empty($remarks)){
			if(empty($add) && !empty($cut)){
				$old_balance = get_table_data_single_row('flc_users','id',$uid,'balance');
				$new_balance = $old_balance - $cut;
				$sql = mysqli_query($db, "UPDATE `flc_users` SET `balance` = '$new_balance' WHERE `id` = '$uid'");
				accounts_update($uid, $cut, $remarks, $old_balance, $new_balance,'dr');
				$number =  get_table_data_single_row('flc_users','id',$uid,'number');
				$message = 'Dear SELF EMPLOYMENTS user, '.$cut.'TK has been deducted from your balance for '.$remarks; 
				sendsms($number, $message);
				if($sql == true){
					header('Location:userlist.php');
				}
			}else if(empty($cut) && !empty($add)){
				 $old_balance = get_table_data_single_row('flc_users','id',$uid,'balance');
				$new_balance = $old_balance + $add;
				$sql = mysqli_query($db, "UPDATE `flc_users` SET `balance` = '$new_balance' WHERE `id` = '$uid'");
				accounts_update($uid, $add, $remarks, $old_balance, $new_balance,'cr');
				$number =  get_table_data_single_row('flc_users','id',$uid,'number');
				$message = 'Dear SELF EMPLOYMENTS user, '.$add.'TK has been added on your balance for '.$remarks; 
				sendsms($number, $message);
				if($sql == true){
					header('Location:userlist.php');
				}
			}
		}
  }
  if(isset($_GET['act'])){
	  $uid = sanetize($_GET['act']);
	  $sql = mysqli_query($db, "UPDATE `flc_users` SET `status` = '1' WHERE `id` = '$uid'");
	  header('Location:userlist.php');
  }
  if(isset($_GET['deact'])){
	   $uid = sanetize($_GET['deact']);
	  $sql = mysqli_query($db, "UPDATE `flc_users` SET `status` = '2' WHERE `id` = '$uid' ");
	  header('Location:userlist.php');
  }
?>
	
	<div class="container col-md-10 col-sm-10"  >
		 
		 <div href="#" class="" style="text-decoration:none;">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h4>Delivery Points</h4>
				</div>
				<div class="panel-body table-responsive">
					
					<form action="dps.php" class="form-inline"  method="get">
						<input type="text"  name="make_dp" placeholder="Insert Number" class="form-control"  />
						<input type="submit" value="Make Delivery Point" class="btn btn-success"   />
					</form>
					<br />
					<form action="dps.php" class="form-inline"  method="get">
						<input type="text"  name="search" placeholder="Search Number" class="form-control"  />
						<input type="submit" value="Search" class="btn btn-success"   />
					</form>
					<br />
					<?php if(isset($_GET['search'])){?>
						<table class="table table-bordered table-striped">
						<tr class="text-nowrap" >
							<th>Action</th>
							<th>User-name</th>
							<th>Number</th>
							<th>Sells</th>
							<th>Income</th>
							
						</tr>
						<?php 
						
						foreach(get_table_data_specific('flc_users','number',sanetize($_GET['search'])) as $users){
							if($users['dp'] == '1'){
							?>
							<tr>
								<td>
									<div class="dropdown">
									  <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
										Action
										<span class="caret"></span>
									  </button>
										<ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
											<li><a href="dps.php?remove=<?php echo $users['id'];?>">Remove</a></li>
										</ul>
									</div>
								</td>
								<td><?php echo $users['username']?></td>
								<td><?php echo $users['number']?></td>
								<td><?php echo get_table_data_specific('i_purchase','dp',$users['id'])->num_rows;?></td>
								<td><?php echo get_dp_incomes($users['id']);?></td>
								
							</tr>
							<?php }}?>
					</table>
					<br />
					<?php }?>
					<table class="table table-bordered table-striped">
						<tr class="text-nowrap" >
							<th>Action</th>
							<th>User-name</th>
							<th>Number</th>
							<th>Sells</th>
							<th>Income</th>
						</tr>
						<?php 
						if(!isset($_GET['list'])){
						foreach(get_ten_data_dp('flc_users') as $users){?>
							<tr>
								<td>
									<div class="dropdown">
									  <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
										Action
										<span class="caret"></span>
									  </button>
										<ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
											<li><a href="dps.php?remove=<?php echo $users['id'];?>">Remove</a></li>
											
										</ul>
									</div>
								</td>
								<td><?php echo $users['username']?></td>
								<td><?php echo $users['number']?></td>
								<td><?php echo get_table_data_specific('i_purchase','dp',$users['id'])->num_rows;?></td>
								<td><?php echo get_dp_incomes($users['id']);?></td>
								
							</tr>
						<?php }}else{
							foreach(paginationed_dp($_GET['list'],'flc_users') as $users){
							?>
							<tr>
								<td>
									<div class="dropdown">
									  <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
										Action
										<span class="caret"></span>
									  </button>
										<ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
											<li><a href="dps.php?remove=<?php echo $users['id'];?>">Remove</a></li>
											
										</ul>
									</div>
								</td>
								<td><?php echo $users['username']?></td>
								<td><?php echo $users['number']?></td>
								<td><?php echo get_table_data_specific('i_purchase','dp',$users['id'])->num_rows;?></td>
								<td><?php echo get_dp_incomes($users['id']);?></td>
								
							</tr>
							<?php }}?>
					</table>
				</div>
				<div class="pagination">
					  <?php 
					  $count = 0;
					  
					  $rows = pagination_list_dp('flc_users');
					  if($rows > 1){
						for($count = 0; $count < $rows; $count++ ){?>
						<li><a class="table_pagination_links <?php if($_GET['list'] == $count){echo 'active';}?>" <?php if($count  > ($_GET['list'] + 4)){echo 'style="display:none;"';}else if($count  < ($_GET['list'] - 4)){echo 'style="display:none;"';}?>  href="dps.php?list=<?php echo $count;?>"><?php echo $count+1;?></a></li>
					  <?php }}?>
				</div>
			 </div>
		 </div>
		
		
		
		 
		 
	</div>
<?php
  include 'include/footer.php';
?>