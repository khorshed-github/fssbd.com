<?php
	function checknumber($data){
		if(strlen(strval($data)) > 11){
			return false;
		}else if(strlen(strval($data)) < 11){
			return false;
		}else if(strlen(strval($data)) == 11){
			if(substr(strval($data), 0, 3) == '018'){
				return true;
			}else if(substr(strval($data), 0, 3) == '017'){
				return true;
			}else if(substr(strval($data), 0, 3) == '011'){
				return false;
			}else if(substr(strval($data), 0, 3) == '016'){
				return true;
			}else if(substr(strval($data), 0, 3) == '015'){
				return true;
			}else if(substr(strval($data), 0, 3) == '019'){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
	function sendsms($number, $message){
		/*
		 * Created by PhpStorm.
		 * User: ahsuoy
		 * Date: 4/20/2017
		 * Time: 4:40 PM
		 */
		
		// base64 encoded authorization key (username:password)
		$authKey = base64_encode("Self-Employment:Mymessage.56");
		
		// request url
		$url = "http://107.20.199.106/restapi/sms/1/text/single";
		
		// post data
		$data = [
			"from" => 'Mobisheba',
			"to"   => ["88".$number],
			"text" => $message,
		];
		
		//print_r($data);
		$ch = curl_init();
		
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
		curl_setopt($ch, CURLOPT_POST, 1);
		
		// header data
		$headers = [];
		$headers[] = "Content-Type: application/json";
		$headers[] = "Accept: application/json";
		$headers[] = "Authorization: Basic " . $authKey;
		
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		
		$result = curl_exec($ch);
		if (curl_errno($ch)) {
			echo 'Error:' . curl_error($ch);
		}
		
		curl_close ($ch);
		
		// convert the response into php array from json
		$result = json_decode($result, true);
		
	   //print_r($result);
	   
		 $status = $result['messages']['0']['status']['groupId'];
	
	
	}
	function loggedin(){
		if(isset($_SESSION['flc_admin'])){
			return true;
		}else{
			return false;
		}
	}
	function create_tasks_status($uid){
		global $db;
		$task = 1;
		$step = 0;
		$cont = 0;
		$date  = gmdate('Y-m-d',time()+(6*60*60));
		$sql = mysqli_query($db, "SELECT * FROM `dailytask` WHERE `uid` = '$uid' AND `date` = '$date'");
		
		if($sql->num_rows == 0){
			while($cont == 0){
				if($task > 10){
					$cont = 1;
				}else{
					$sql = mysqli_query($db, "INSERT INTO `dailytask` 
					(`uid`,`task`,`status`,`date`)
					VALUES 
					('$uid','$task','0','".dates()."');
					");
					$cont2 = 0;
					$step = 1;
					while($cont2 == 0){
						if($step > 10){
							$cont2 = 1;
						}else{
							$sql = mysqli_query($db, "INSERT INTO `steps` 
							(`uid`,`taskid`,`step`,`status`,`date`)
							VALUES 
							('$uid','$task','$step','0','".dates()."');
							");
							$step++;
							
						}
					}
					$task++;
					
				}
			}
			
		}
	}
	function create_jobs_status($date){
		global $db;
		if(get_table_data_specific('jobs2','date',$date)->num_rows == 0){
			$task = 1;
			$step = 1;
			$cont = 0;
			//$date  = gmdate('Y-m-d',time()+(6*60*60));
			$sql = mysqli_query($db, "SELECT * FROM `jobs2` WHERE `date` = '$date'");
			
			if($sql->num_rows == 0){
				while($cont == 0){
					if($task > 10){
						$cont = 1;
					}else{
						$sql = mysqli_query($db, "INSERT INTO `jobs2` 
						(`taskid`,`step`,`status`,`date`)
						VALUES 
						('$task','$step','0','$date');
						");
						$step++;
						$task++;
						
					}
				}
				
			}
			
		}
	}
	function get_task_id($uid){
		global $db;
		
		$date = dates();
		
			$sql = mysqli_query($db, "SELECT * FROM `dailytask` WHERE `uid` = '$uid' AND `date` = '$date' AND `status` = '0' LIMIT 1");
			$data = mysqli_fetch_assoc($sql);
			return $data['id'];
		
	}
	function get_step_id($uid,$task_number){
		global $db;
		
		$date = dates();
		
			$sql = mysqli_query($db, "SELECT * FROM `steps` WHERE `uid` = '$uid' AND `taskid` = '$task_number' AND `date` = '$date' AND `status` = '0' LIMIT 1");
			$data = mysqli_fetch_assoc($sql);
			return $data['id'];
		
	}
	function get_earning_rate($uid){
		global $db;
		$points = get_table_data_single_row('flc_users','id',$uid,'points');
		$sql = get_table_data_all('direct_income');
		foreach($sql as $data){
			if($points >= $data['min'] && $points <= $data['max']){
				$price = $data['price'];
			}
		}
		return $price;
	}
function accounts_update($id, $amount, $details, $old_bal, $new_bal,$type){
		global $db;
		$date = date('Y-m-d', time());
		$time = date('H-i-s', time());
		if($type == 'dr'){
			$sql = mysqli_query($db, "INSERT INTO `accounts` 
		(`uid`,`details`,`dr_amount`,`cr_amount`,`old_bal`,`new_bal`,`status`,`date`,`time`)
		VALUES
		('$id','$details','$amount','0.00','$old_bal','$new_bal','0','".dates()."','".times()."')
		");
		}else if($type == 'cr'){
			$sql = mysqli_query($db, "INSERT INTO `accounts` 
		(`uid`,`details`,`dr_amount`,`cr_amount`,`old_bal`,`new_bal`,`status`,`date`,`time`)
		VALUES
		('$id','$details','0.00','$amount','$old_bal','$new_bal','0','".dates()."','".times()."')
		");
		}
	}
	function send_uppler_level_commission($uid, $amount){
		global $db;
		$levels = get_uppler_levels($uid, '6');
		foreach($levels as $key => $upids){
			$level = $key + 1;
			$earning_type = $level+1;
			if($upids !== 0){
				$percent = get_table_data_single_row('work_referral','level',$level,'percent');
				$comm = ($amount / 100) * $percent;
				$old_balance = get_table_data_single_row('flc_users','id',$upids,'balance');
				$new_balance = $old_balance + $comm;
				$update = mysqli_query($db, "UPDATE `flc_users` SET `balance` = '$new_balance' WHERE `id` = '$upids'");
				accounts_update($upids,$comm,'work referral income from level '.$level.' User '.get_table_data_single_row('flc_users','id',$uid,'username'),$old_balance,$new_balance,'cr');
				income_entry($upids,$uid,$comm,$earning_type);
			}
		}
	}
	function get_uppler_levels($uid, $level){
		global $db;
		$cont = 0;
		$count = 0;
		$array = array();
		$ref = $uid;
		while($cont == 0){
			if($count == $level){
				$cont = 1;
			}else{
				$refid = get_table_data_single_row('flc_users','id',$ref,'ref');
				if(!empty($refid)){
					$array[] = $refid;
				}else{
					$array[] = 0;
				}
				$ref = $refid;
				$count++;
			}
		}
		return $array;
	}
	function income_entry($uid,$sid,$amount,$type,$extra_level){
		global $db;
		
		$sql = mysqli_query($db, "INSERT INTO `incomes`
			(`uid`,`sid`,`amount`,`type`,`date`,`time`,`status`,`extra_level`)
			VALUES
			('$uid','$sid','$amount','$type','".dates()."','".times()."','0',$extra_level)
		");
		$find = mysqli_query($db, "SELECT * FROM `income` WHERE `uid` = '$uid' AND `type` = '$type' AND `date` = '".dates()."' LIMIT 1");
		if($find->num_rows == 0){
		    $sql = mysqli_query($db, "INSERT INTO `income`
			(`uid`,`sid`,`amount`,`type`,`date`,`time`,`status`,`extra_level`)
			VALUES
			('$uid','$sid','$amount','$type','".dates()."','".times()."','0',$extra_level)
		");
		}else{
		    $data = mysqli_fetch_assoc($find);
		    $id = $data['id'];
		    $old_amount = $data['amount'];
		    $new_amount = $old_amount + $amount;
		    $update = mysqli_query($db, "UPDATE `income` SET `amount` = '$new_amount' WHERE `id` = '$id'");
		}
		/*if($type !== '3'){
		$tds_percent = get_table_data_single_row('getamounts','name','tds_amount','amount');
		$tds_amount = ($amount / 100) * $tds_percent;
		$old_balance = get_table_data_single_row('userlg','id',$uid,'mbalance');
		$new_balance = $old_balance - $tds_amount;
		$sql2 = mysqli_query($db, "UPDATE `userlg` SET `mbalance` = '$new_balance' WHERE `id` = '$uid'");
		accounts_update($uid, $tds_amount, 'TDS Deducted','cut','bonus','0');
		$old_tds_amount = get_table_data_single_row('tds_earnings','id','1','amount');
		$new_tds_amount = $old_tds_amount + $tds_amount;
		$update_tds = mysqli_query($db, "UPDATE `tds_earnings` SET `amount` = '$new_tds_amount' WHERE `id` = '1'");
		
		}*/
	}
	function get_total_balance(){
		$users = get_table_data_all('flc_users');
		$total = 0;
		foreach($users as $balance){
			$total = $total + ($balance['balance'] * 1);
		}
		return $total;
	}
	function get_ten_data($table_name){
		global $db;
		$sql = mysqli_query($db, "SELECT * FROM `".$table_name."` ORDER BY `id` DESC LIMIT 10");
		return $sql;
	}
	function paginationed($coun,$table_name){
		global $db;
                $count = sanetize($coun);
		$counts = $count.'0';
		
		$sql = mysqli_query($db, "SELECT * FROM `".$table_name."`  ORDER BY `id` DESC LIMIT $counts, 10");
		return $sql;
	}
	function pagination_list($table_name){
		global $db;
		
		$sql = mysqli_query($db, "SELECT * FROM `".$table_name."`  ORDER BY `id` DESC");
		$num_rows = mysqli_num_rows($sql);
		
		if($num_rows > 10){
			$rowscount = ($num_rows / 10);
			$count_total = ceil($rowscount);
			return $count_total;
		}else{
			return 1;
		}
	}
	function get_ten_data_aproval($table_name){
		global $db;
		$sql = mysqli_query($db, "SELECT * FROM `".$table_name."` WHERE `p_balance` != '0.00' ORDER BY `id` DESC LIMIT 10");
		return $sql;
	}
	function paginationed_aproval($coun,$table_name){
		global $db;
                $count = sanetize($coun);
		$counts = $count.'0';
		
		$sql = mysqli_query($db, "SELECT * FROM `".$table_name."` WHERE `p_balance` != '0.00'  ORDER BY `id` DESC LIMIT $counts, 10");
		return $sql;
	}
	function pagination_list_aproval($table_name){
		global $db;
		
		$sql = mysqli_query($db, "SELECT * FROM `".$table_name."` WHERE `p_balance` != '0.00'  ORDER BY `id` DESC");
		$num_rows = mysqli_num_rows($sql);
		
		if($num_rows > 10){
			$rowscount = ($num_rows / 10);
			$count_total = ceil($rowscount);
			return $count_total;
		}else{
			return 1;
		}
	}
	function get_ten_data_aproval_monthly($table_name){
		global $db;
		$sql = mysqli_query($db, "SELECT * FROM `".$table_name."` WHERE `s_balance` != '0.00' ORDER BY `id` DESC LIMIT 10");
		return $sql;
	}
	function paginationed_aproval_monthly($coun,$table_name){
		global $db;
                $count = sanetize($coun);
		$counts = $count.'0';
		
		$sql = mysqli_query($db, "SELECT * FROM `".$table_name."` WHERE `s_balance` != '0.00'  ORDER BY `id` DESC LIMIT $counts, 10");
		return $sql;
	}
	function pagination_list_aproval_monthly($table_name){
		global $db;
		
		$sql = mysqli_query($db, "SELECT * FROM `".$table_name."` WHERE `s_balance` != '0.00'  ORDER BY `id` DESC");
		$num_rows = mysqli_num_rows($sql);
		
		if($num_rows > 10){
			$rowscount = ($num_rows / 10);
			$count_total = ceil($rowscount);
			return $count_total;
		}else{
			return 1;
		}
	}
	function get_ten_data_dp($table_name){
		global $db;
		$sql = mysqli_query($db, "SELECT * FROM `".$table_name."` WHERE `dp` = '1' ORDER BY `id` DESC LIMIT 10");
		return $sql;
	}
	function paginationed_dp($coun,$table_name){
		global $db;
                $count = sanetize($coun);
		$counts = $count.'0';
		
		$sql = mysqli_query($db, "SELECT * FROM `".$table_name."` WHERE `dp` = '1'  ORDER BY `id` DESC LIMIT $counts, 10");
		return $sql;
	}
	function pagination_list_dp($table_name){
		global $db;
		
		$sql = mysqli_query($db, "SELECT * FROM `".$table_name."` WHERE `dp` = '1'  ORDER BY `id` DESC");
		$num_rows = mysqli_num_rows($sql);
		
		if($num_rows > 10){
			$rowscount = ($num_rows / 10);
			$count_total = ceil($rowscount);
			return $count_total;
		}else{
			return 1;
		}
	}
	function paginationed_job_details($coun,$date){
		global $db;
                $count = sanetize($coun);
		$counts = $count.'0';
		
		$sql = mysqli_query($db, "SELECT * FROM `jobs` WHERE `jobid` = '$date'   LIMIT $counts, 10");
		return $sql;
	}
	function pagination_list_job_details($date){
		global $db;
		
		$sql = mysqli_query($db, "SELECT * FROM `jobs`  WHERE `jobid` = '$date' ");
		$num_rows = mysqli_num_rows($sql);
		
		if($num_rows > 10){
			$rowscount = ($num_rows / 10);
			$count_total = ceil($rowscount);
			return $count_total;
		}else{
			return 1;
		}
	}
	function paginationed_job($coun,$date){
		global $db;
                $count = sanetize($coun);
		$counts = $count.'0';
		
		$sql = mysqli_query($db, "SELECT * FROM `jobs2` WHERE `date` = '$date'   LIMIT $counts, 10");
		return $sql;
	}
	function pagination_list_job($date){
		global $db;
		
		$sql = mysqli_query($db, "SELECT * FROM `jobs2`  WHERE `date` = '$date' ");
		$num_rows = mysqli_num_rows($sql);
		
		if($num_rows > 10){
			$rowscount = ($num_rows / 10);
			$count_total = ceil($rowscount);
			return $count_total;
		}else{
			return 1;
		}
	}
	// for jpg 
	function resize_imagejpg($file, $w, $h) {
	   list($width, $height) = getimagesize($file);
	   $src = imagecreatefromjpeg($file);
	   $dst = imagecreatetruecolor($w, $h);
	   imagecopyresampled($dst, $src, 0, 0, 0, 0, $w, $h, $width, $height);
	   return $dst;
	}

	 // for png
	function resize_imagepng($file, $w, $h) {
	   list($width, $height) = getimagesize($file);
	   $src = imagecreatefrompng($file);
	   $dst = imagecreatetruecolor($w, $h);
	   imagecopyresampled($dst, $src, 0, 0, 0, 0, $w, $h, $width, $height);
	   return $dst;
	}
	function store_image($img, $name){
		imagejpeg($img, '../images/job/shrinked/'.$name);
	}
	function get_income($type){
		//global $uid;
		global $db;
		if($type  == 'today'){
			$sql = mysqli_query($db, "SELECT * FROM `incomes` WHERE `date` = '".dates()."'");
			$total = 0;
			foreach($sql as $data){
				$total = $total  + ($data['amount'] * 1);
			}
			return $total;
		}else if($type == 'week'){
			$back_span = time() - (60*60*24*7);
			$back_date = date('Y-m-d',$back_span);
			$curr_date = date('Y-m-d',time());
			$sql = mysqli_query($db, "SELECT * FROM `incomes` WHERE  `date` BETWEEN '$back_date' AND '$curr_date'");
			$total = 0;
			foreach($sql as $data){
				$total = $total  + ($data['amount'] * 1);
			}
			return $total;
		}else if($type == 'last_week'){
			$back_span = time() - (60*60*24*14);
			$back_span2 = time() - (60*60*24*7);
			$back_date = date('Y-m-d',$back_span);
			$curr_date = date('Y-m-d',$back_span2);
			$sql = mysqli_query($db, "SELECT * FROM `incomes` WHERE   `date` BETWEEN '$back_date' AND '$curr_date'");
			$total = 0;
			foreach($sql as $data){
				$total = $total  + ($data['amount'] * 1);
			}
			return $total;
		}else if($type == 'month'){
			$back_span = time() - (60*60*24*30);
			$back_date = date('Y-m-d',$back_span);
			$curr_date = date('Y-m-d',time());
			$sql = mysqli_query($db, "SELECT * FROM `incomes` WHERE   `date` BETWEEN '$back_date' AND '$curr_date'");
			$total = 0;
			foreach($sql as $data){
				$total = $total  + ($data['amount'] * 1);
			}
			return $total;
		}else if($type == 'last_month'){
			$back_span = time() - (60*60*24*60);
			$back_span2 = time() - (60*60*24*30);
			$back_date = date('Y-m-d',$back_span);
			$curr_date = date('Y-m-d',$back_span2);
			$sql = mysqli_query($db, "SELECT * FROM `incomes` WHERE  `date` BETWEEN '$back_date' AND '$curr_date'");
			$total = 0;
			foreach($sql as $data){
				$total = $total  + ($data['amount'] * 1);
			}
			return $total;
		}else if($type == 'all'){
			$sql = mysqli_query($db, "SELECT * FROM `incomes`  ");
			$total = 0;
			foreach($sql as $data){
				$total = $total  + ($data['amount'] * 1);
			}
			return $total;
		}
	}
	
	function get_points_done($type){
		//global $uid;
		global $db;
		if($type  == 'today'){
			$sql = mysqli_query($db, "SELECT * FROM `dailytask` WHERE `date` = '".dates()."' AND `status` = '1'");
			
			return $sql->num_rows;
		}else if($type == 'week'){
			$back_span = time() - (60*60*24*7);
			$back_date = date('Y-m-d',$back_span);
			$curr_date = date('Y-m-d',time());
			$sql = mysqli_query($db, "SELECT * FROM `dailytask` WHERE `status` = '1' AND  `date` BETWEEN '$back_date' AND '$curr_date'");
			return $sql->num_rows;
		}else if($type == 'last_week'){
			$back_span = time() - (60*60*24*14);
			$back_span2 = time() - (60*60*24*7);
			$back_date = date('Y-m-d',$back_span);
			$curr_date = date('Y-m-d',$back_span2);
			$sql = mysqli_query($db, "SELECT * FROM `dailytask` WHERE `status` = '1'   `date` BETWEEN '$back_date' AND '$curr_date'");
			return $sql->num_rows;
		}else if($type == 'month'){
			$back_span = time() - (60*60*24*30);
			$back_date = date('Y-m-d',$back_span);
			$curr_date = date('Y-m-d',time());
			$sql = mysqli_query($db, "SELECT * FROM `dailytask` WHERE `status` = '1'   `date` BETWEEN '$back_date' AND '$curr_date'");
			return $sql->num_rows;
		}else if($type == 'last_month'){
			$back_span = time() - (60*60*24*60);
			$back_span2 = time() - (60*60*24*30);
			$back_date = date('Y-m-d',$back_span);
			$curr_date = date('Y-m-d',$back_span2);
			$sql = mysqli_query($db, "SELECT * FROM `dailytask` WHERE `status` = '1'  `date` BETWEEN '$back_date' AND '$curr_date'");
			return $sql->num_rows;
		}else if($type == 'all'){
			$sql = mysqli_query($db, "SELECT * FROM `dailytask` WHERE   `status` = '1'");
		return $sql->num_rows;
		}
	}
	function get_withdraw($type){
		//global $uid;
		global $db;
		if($type  == 'today'){
			$sql = mysqli_query($db, "SELECT * FROM `withdraw` WHERE `status` = '1'  AND  `date` = '".dates()."'");
			$total = 0;
			foreach($sql as $data){
				$total = $total  + ($data['amount'] * 1);
			}
			return $total;
		}else if($type == 'week'){
			$back_span = time() - (60*60*24*7);
			$back_date = date('Y-m-d',$back_span);
			$curr_date = date('Y-m-d',time());
			$sql = mysqli_query($db, "SELECT * FROM `withdraw` WHERE `status` = '1'  AND  `date` BETWEEN '$back_date' AND '$curr_date'");
			$total = 0;
			foreach($sql as $data){
				$total = $total  + ($data['amount'] * 1);
			}
			return $total;
		}else if($type == 'last_week'){
			$back_span = time() - (60*60*24*14);
			$back_span2 = time() - (60*60*24*7);
			$back_date = date('Y-m-d',$back_span);
			$curr_date = date('Y-m-d',$back_span2);
			$sql = mysqli_query($db, "SELECT * FROM `withdraw` WHERE `status` = '1'  AND  `date` BETWEEN '$back_date' AND '$curr_date'");
			$total = 0;
			foreach($sql as $data){
				$total = $total  + ($data['amount'] * 1);
			}
			return $total;
		}else if($type == 'month'){
			$back_span = time() - (60*60*24*30);
			$back_date = date('Y-m-d',$back_span);
			$curr_date = date('Y-m-d',time());
			$sql = mysqli_query($db, "SELECT * FROM `withdraw` WHERE `status` = '1'  AND  `date` BETWEEN '$back_date' AND '$curr_date'");
			$total = 0;
			foreach($sql as $data){
				$total = $total  + ($data['amount'] * 1);
			}
			return $total;
		}else if($type == 'last_month'){
			$back_span = time() - (60*60*24*60);
			$back_span2 = time() - (60*60*24*30);
			$back_date = date('Y-m-d',$back_span);
			$curr_date = date('Y-m-d',$back_span2);
			$sql = mysqli_query($db, "SELECT * FROM `withdraw` WHERE `status` = '1'  AND  `date` BETWEEN '$back_date' AND '$curr_date'");
			$total = 0;
			foreach($sql as $data){
				$total = $total  + ($data['amount'] * 1);
			}
			return $total;
		}else if($type == 'all'){
			$sql = mysqli_query($db, "SELECT * FROM `withdraw` WHERE `status` = '1'");
			$total = 0;
			foreach($sql as $data){
				$total = $total  + ($data['amount'] * 1);
			}
			return $total;
		}
	}
	function checkaccess($id, $page){
		global $db;
		$sql = mysqli_query($db, "SELECT * FROM `admin` WHERE `id` = '$id'");
		$data = mysqli_fetch_assoc($sql);
		
		if($data[$page] == '0'){
			return false;
		}else if($data[$page] == '1'){
			return true;
		}
	}
	function get_sell_total(){
		global $db;
		$sql = mysqli_query($db, "SELECT * FROM `i_purchase` WHERE `status` = '1'");
		$total = 0;
		foreach($sql as $data){
			$total = $total + ($data['amount'] * 1);
		}
		return $total;
	}
	function get_distributed_total(){
		global $db;
		$sql = mysqli_query($db, "SELECT * FROM `incomes` WHERE `type` BETWEEN '14' AND '20'");
		$total = 0;
		foreach($sql as $data){
			$total = $total + ($data['amount'] * 1);
		}
		
		return $total;
	}
	function get_dp_incomes($uid){
		global $db;
		$sql = mysqli_query($db, "SELECT * FROM `incomes` WHERE `type` = '20' AND `uid` = '$uid'");
		$total = 0;
		foreach($sql as $data){
			$total = $total + ($data['amount'] * 1);
		}
		
		return $total;
	}
	function get_report_work_income($from_date, $to_date){
	    global $db;
	    $total = 0;
	    	$sql =  mysqli_query($db, "SELECT * FROM `incomes` WHERE   `type` = '1' AND  `date` BETWEEN '$from_date' AND '$to_date'");
		foreach($sql as $data){
			$total = $total  + ($data['amount'] * 1);
		}
		
		return $total;	
	}
	function get_report_ref_work_income($from_date, $to_date){
	    global $db;
	    $total = 0;
			$sql2 = mysqli_query($db, "SELECT * FROM `incomes` WHERE   `type` = '2' AND  `date` BETWEEN '$from_date' AND '$to_date'");
			$sql3 = mysqli_query($db, "SELECT * FROM `incomes` WHERE   `type` = '3' AND  `date` BETWEEN '$from_date' AND '$to_date'");
			$sql4 = mysqli_query($db, "SELECT * FROM `incomes` WHERE   `type` = '4' AND  `date` BETWEEN '$from_date' AND '$to_date'");
			$sql5 = mysqli_query($db, "SELECT * FROM `incomes` WHERE   `type` = '5' AND  `date` BETWEEN '$from_date' AND '$to_date'");
			$sql6 = mysqli_query($db, "SELECT * FROM `incomes` WHERE   `type` = '6' AND  `date` BETWEEN '$from_date' AND '$to_date'");
			$sql7 = mysqli_query($db, "SELECT * FROM `incomes` WHERE   `type` = '7' AND  `date` BETWEEN '$from_date' AND '$to_date'");
		
		foreach($sql2 as $data2){
			$total = $total  + ($data2['amount'] * 1);
		}
		foreach($sql3 as $data3){
			$total = $total  + ($data3['amount'] * 1);
		}
		foreach($sql4 as $data4){
			$total = $total  + ($data4['amount'] * 1);
		}
		foreach($sql5 as $data5){
			$total = $total  + ($data5['amount'] * 1);
		}
		foreach($sql6 as $data6){
			$total = $total  + ($data6['amount'] * 1);
		}
		foreach($sql7 as $data7){
			$total = $total  + ($data7['amount'] * 1);
		}
		return $total;	
	}
	function get_report_product_sells_incomes($from_date, $to_date){
	    global $db;
	    $total = 0;
			$sql2 = mysqli_query($db, "SELECT * FROM `incomes` WHERE   `type` = '14' AND  `date` BETWEEN '$from_date' AND '$to_date'");
			$sql3 = mysqli_query($db, "SELECT * FROM `incomes` WHERE   `type` = '15' AND  `date` BETWEEN '$from_date' AND '$to_date'");
			$sql4 = mysqli_query($db, "SELECT * FROM `incomes` WHERE   `type` = '16' AND  `date` BETWEEN '$from_date' AND '$to_date'");
			$sql5 = mysqli_query($db, "SELECT * FROM `incomes` WHERE   `type` = '17' AND  `date` BETWEEN '$from_date' AND '$to_date'");
			$sql6 = mysqli_query($db, "SELECT * FROM `incomes` WHERE   `type` = '18' AND  `date` BETWEEN '$from_date' AND '$to_date'");
			$sql7 = mysqli_query($db, "SELECT * FROM `incomes` WHERE   `type` = '19' AND  `date` BETWEEN '$from_date' AND '$to_date'");
		
		foreach($sql2 as $data2){
			$total = $total  + ($data2['amount'] * 1);
		}
		foreach($sql3 as $data3){
			$total = $total  + ($data3['amount'] * 1);
		}
		foreach($sql4 as $data4){
			$total = $total  + ($data4['amount'] * 1);
		}
		foreach($sql5 as $data5){
			$total = $total  + ($data5['amount'] * 1);
		}
		foreach($sql6 as $data6){
			$total = $total  + ($data6['amount'] * 1);
		}
		foreach($sql7 as $data7){
			$total = $total  + ($data7['amount'] * 1);
		}
		return $total;	
	}
	function get_report_act_income($from_date, $to_date){
	    global $db;
	    $total = 0;
	    	$sql =  mysqli_query($db, "SELECT * FROM `incomes` WHERE   `type` = '8' AND  `date` BETWEEN '$from_date' AND '$to_date'");
			$sql2 = mysqli_query($db, "SELECT * FROM `incomes` WHERE   `type` = '9' AND  `date` BETWEEN '$from_date' AND '$to_date'");
			$sql3 = mysqli_query($db, "SELECT * FROM `incomes` WHERE   `type` = '10' AND  `date` BETWEEN '$from_date' AND '$to_date'");
			$sql4 = mysqli_query($db, "SELECT * FROM `incomes` WHERE   `type` = '11' AND  `date` BETWEEN '$from_date' AND '$to_date'");
			$sql5 = mysqli_query($db, "SELECT * FROM `incomes` WHERE   `type` = '12' AND  `date` BETWEEN '$from_date' AND '$to_date'");
			$sql6 = mysqli_query($db, "SELECT * FROM `incomes` WHERE   `type` = '13' AND  `date` BETWEEN '$from_date' AND '$to_date'");
			$sql7 = mysqli_query($db, "SELECT * FROM `incomes` WHERE   `type` = '14' AND  `date` BETWEEN '$from_date' AND '$to_date'");
		foreach($sql as $data){
			$total = $total  + ($data['amount'] * 1);
		}
		foreach($sql2 as $data2){
			$total = $total  + ($data2['amount'] * 1);
		}
		foreach($sql3 as $data3){
			$total = $total  + ($data3['amount'] * 1);
		}
		foreach($sql4 as $data4){
			$total = $total  + ($data4['amount'] * 1);
		}
		foreach($sql5 as $data5){
			$total = $total  + ($data5['amount'] * 1);
		}
		foreach($sql6 as $data6){
			$total = $total  + ($data6['amount'] * 1);
		}
		foreach($sql7 as $data7){
			$total = $total  + ($data7['amount'] * 1);
		}
		return $total;	
	}
	function get_report_activated_users($from_date, $to_date){
	    global $db;
	    	$sql =  mysqli_query($db, "SELECT * FROM `flc_users` WHERE  `a_date` BETWEEN '$from_date' AND '$to_date'");
	    return $sql->num_rows;
	}
	function get_report_bkash_sells($from_date, $to_date){
	    global $db;
	    $sql =  mysqli_query($db, "SELECT * FROM `i_purchase` WHERE  `status` = '1' AND `date`  BETWEEN '$from_date' AND '$to_date'");
	    $total = 0;
		foreach($sql as $data){
			$total = $total  + ($data['amount'] * 1);
		}
		return $total;
	}
	function get_report_balance_sells($from_date, $to_date){
	    global $db;
	    $total = 0;
		$sql =  mysqli_query($db, "SELECT * FROM `i_purchase` WHERE  `paytype` = '2' AND `date` BETWEEN '$from_date' AND '$to_date'");
	    foreach($sql as $data){
			$total = $total  + ($data['amount'] * 1);
		}
		return $total;
	    
	}
	function get_report_distributed($from_date, $to_date){
	    global $db;
	    $total = 0;
		$sql =  mysqli_query($db, "SELECT * FROM `i_purchase` WHERE  `delivery` = '1' AND `date` BETWEEN '$from_date' AND '$to_date'");
	    foreach($sql as $data){
			$total = $total  + ($data['amount'] * 1);
		}
		return $total;
	    
	}
	function product_delivered($from_date, $to_date){
	    global $db;
	    $total = 0;
		$sql =  mysqli_query($db, "SELECT * FROM `i_purchase` WHERE  `delivery` = '1' AND `date` BETWEEN '$from_date' AND '$to_date'");
	    return $sql->num_rows;
	    
	}
	function is_select_aproval($id){
		$found = 0;
		foreach($_SESSION['aproval_checked'] as $key => $value){
			if($value == $id){
				$found = 1;
				
			}
		}
		if($found == 1){
			return true;
		}else{
			return false;
		}
	}
	function get_age_range($min, $max){
		global $db;
		$sql = mysqli_query($db, "SELECT `dob` FROM `flc_users`");
		$count = array();	
		foreach($sql as $dates){
			$date = strtotime($dates['dob']);
			$time_now = time();
			$different = $time_now - $date;
			$year = floor($different / 31556926);
			if($year >= $min && $year <= $max){
				$count[] = $year;
			}
				
		}
		return count($count);
	}
	function get_address_like($address){
		global $db;
		$sql = mysqli_query($db, "SELECT * FROM `flc_users` WHERE `address` LIKE '%".$address."%'");
		return $sql->num_rows;
	}
	function get_incomes_reports($type){
		global $db;
		if($type == 'own_work'){
			$total = 0;
			$sql = mysqli_query($db, "SELECT `amount` FROM `incomes` WHERE `type` = '1'");
			foreach($sql as $income){
				$total = $total + ($income['amount'] * 1);
			}
			return floor($total);
		}else if($type == 'refer_work'){
			$total = 0;
			$sql = mysqli_query($db, "SELECT `amount` FROM `incomes` WHERE `type` = '2'");
			$sql2 = mysqli_query($db, "SELECT `amount` FROM `incomes` WHERE `type` = '3'");
			$sql3 = mysqli_query($db, "SELECT `amount` FROM `incomes` WHERE `type` = '4'");
			$sql4 = mysqli_query($db, "SELECT `amount` FROM `incomes` WHERE `type` = '5'");
			$sql5 = mysqli_query($db, "SELECT `amount` FROM `incomes` WHERE `type` = '6'");
			$sql6 = mysqli_query($db, "SELECT `amount` FROM `incomes` WHERE `type` = '7'");
			foreach($sql as $income){
				$total = $total + ($income['amount'] * 1);
			}
			foreach($sql2 as $income2){
				$total = $total + ($income2['amount'] * 1);
			}
			foreach($sql3 as $income3){
				$total = $total + ($income3['amount'] * 1);
			}
			foreach($sql4 as $income4){
				$total = $total + ($income4['amount'] * 1);
			}
			foreach($sql5 as $income5){
				$total = $total + ($income5['amount'] * 1);
			}
			foreach($sql6 as $income6){
				$total = $total + ($income6['amount'] * 1);
			}
			return floor($total);
		}else if($type == 'joining'){
			$total = 0;
			$sql = mysqli_query($db, "SELECT `amount` FROM `incomes` WHERE `type` = '8'");
			$sql2 = mysqli_query($db, "SELECT `amount` FROM `incomes` WHERE `type` = '9'");
			$sql3 = mysqli_query($db, "SELECT `amount` FROM `incomes` WHERE `type` = '10'");
			$sql4 = mysqli_query($db, "SELECT `amount` FROM `incomes` WHERE `type` = '11'");
			$sql5 = mysqli_query($db, "SELECT `amount` FROM `incomes` WHERE `type` = '12'");
			$sql6 = mysqli_query($db, "SELECT `amount` FROM `incomes` WHERE `type` = '13'");
			foreach($sql as $income){
				$total = $total + ($income['amount'] * 1);
			}
			foreach($sql2 as $income2){
				$total = $total + ($income2['amount'] * 1);
			}
			foreach($sql3 as $income3){
				$total = $total + ($income3['amount'] * 1);
			}
			foreach($sql4 as $income4){
				$total = $total + ($income4['amount'] * 1);
			}
			foreach($sql5 as $income5){
				$total = $total + ($income5['amount'] * 1);
			}
			foreach($sql6 as $income6){
				$total = $total + ($income6['amount'] * 1);
			}
			return floor($total);
		}else if($type == 'purchase'){
			$total = 0;
			$sql = mysqli_query($db, "SELECT `amount` FROM `incomes` WHERE `type` = '14'");
			$sql2 = mysqli_query($db, "SELECT `amount` FROM `incomes` WHERE `type` = '15'");
			$sql3 = mysqli_query($db, "SELECT `amount` FROM `incomes` WHERE `type` = '16'");
			$sql4 = mysqli_query($db, "SELECT `amount` FROM `incomes` WHERE `type` = '17'");
			$sql5 = mysqli_query($db, "SELECT `amount` FROM `incomes` WHERE `type` = '18'");
			$sql6 = mysqli_query($db, "SELECT `amount` FROM `incomes` WHERE `type` = '19'");
			foreach($sql as $income){
				$total = $total + ($income['amount'] * 1);
			}
			foreach($sql2 as $income2){
				$total = $total + ($income2['amount'] * 1);
			}
			foreach($sql3 as $income3){
				$total = $total + ($income3['amount'] * 1);
			}
			foreach($sql4 as $income4){
				$total = $total + ($income4['amount'] * 1);
			}
			foreach($sql5 as $income5){
				$total = $total + ($income5['amount'] * 1);
			}
			foreach($sql6 as $income6){
				$total = $total + ($income6['amount'] * 1);
			}
			return floor($total);
		}else if($type == 'delivery'){
			$total = 0;
			$sql = mysqli_query($db, "SELECT `amount` FROM `incomes` WHERE `type` = '20'");
			foreach($sql as $income){
				$total = $total + ($income['amount'] * 1);
			}
			
			return floor($total);
		}
	}
	function get_provident_fund(){
		global $db;
		$sql = mysqli_query($db, "SELECT `provident` FROM `withdraw`");
		$total = 0;
		foreach($sql as $amounts){
			$total = $total + $amounts['provident'];
		}
		return floor($total);
	}
	function get_withdraws($type){
		global $db;
		if($type == 'success'){
			$total = 0;
			$sql = mysqli_query($db, "SELECT `amount` FROM `withdraw` WHERE `status` = '1'");
			foreach($sql as $data){
				$total = $total + $data['amount'];
			}
			return floor($total);
		}else if($type == 'pending'){
			$total = 0;
			$sql = mysqli_query($db, "SELECT `amount` FROM `withdraw` WHERE `status` = '0'");
			foreach($sql as $data){
				$total = $total + $data['amount'];
			}
			return floor($total);
		}else if($type == 'cancelled'){
			$total = 0;
			$sql = mysqli_query($db, "SELECT `amount` FROM `withdraw` WHERE `status` = '2'");
			foreach($sql as $data){
				$total = $total + $data['amount'];
			}
			return floor($total);
		}else if($type == 'bkash'){
			$total = 0;
			$sql = mysqli_query($db, "SELECT `amount` FROM `withdraw` WHERE `method` = 'bkash'");
			foreach($sql as $data){
				$total = $total + $data['amount'];
			}
			return floor($total);
		}else if($type == 'bank'){
			$total = 0;
			$sql = mysqli_query($db, "SELECT `amount` FROM `withdraw` WHERE `method` = 'bank'");
			foreach($sql as $data){
				$total = $total + $data['amount'];
			}
			return floor($total);
		}
	}
	function get_completed_steps(){
		global $db;
		$sql = mysqli_query($db, "SELECT `points` FROM `flc_users`");
		$total = 0;
		foreach($sql as $data){
			$total = $total + ($data['points'] * 1); 
		}
		return $total;
	}
	function get_total_income($uid){
		global $db;
		$sql = mysqli_query($db, "SELECT `amount` FROM `incomes` WHERE `uid` = '$uid'");
		$total = 0;
		foreach($sql as $data){
			$total = $total + ($data['amount'] * 1);
		}
		return $total;
		
	}
	function get_total_withdraw($uid){
		global $db;
		$sql = mysqli_query($db, "SELECT `amount` FROM `withdraw` WHERE `uid` = '$uid' AND `status` = '1'");
		$total = 0;
		foreach($sql as $data){
			$total = $total + ($data['amount'] * 1);
		}
		return $total;
		
	}
	function get_last_withdraw($uid){
		global $db;
		$sql = mysqli_query($db, "SELECT `amount` FROM `withdraw` WHERE `uid` = '$uid' AND `status` = '1' ORDER BY `id` DESC LIMIT 1");
		$total = 0;
		foreach($sql as $data){
			$total = $total + ($data['amount'] * 1);
		}
		return $total;
		
	}
	function get_age($date){
		$date = strtotime($date);
			$time_now = time();
			$different = $time_now - $date;
			$year = floor($different / 31556926);
			return $year;
	}
?>