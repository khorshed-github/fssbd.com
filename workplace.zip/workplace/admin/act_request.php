<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
  error_reporting(0);
  if(loggedin() == false){
	  header("Location:login.php");
  }

  if(checkaccess($_SESSION['flc_admin'], 'act_request.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
  //sendsms('01813404900','test_message');
  //sendsms('01813404900','Dear SELF EMPLOYMENTS user, You have got '.$bdt.'TK joining commission for level '.$level.' User '.get_table_data_single_row('flc_users','id',$uid,'number'));
    			
  //print_r($_SESSION);
  //error_reporting(0);
if(isset($_GET['accept'])){
	$id = sanetize($_GET['accept']);
	
	$uid = get_table_data_single_row('act_request','id',$id,'uid');
	$sql = mysqli_query($db, "UPDATE `flc_users` SET `status` = '1',`a_date` = '".dates()."' WHERE `id` = '$uid'");
	$sql2 = mysqli_query($db, "SELECT * FROM `incomes` WHERE `sid` = '$uid' AND `type` = '8'");
	
	$refid = /*get_table_data_single_row('flc_users','id',$uid,'ref')*/ $uid + 112233;
	sendsms(get_table_data_single_row('flc_users','id',$uid,'number'),'Welcome, Your SELF EMPLOYMENTS  account has been successfully activated. You are now able to start your job full functionally. Your Refer ID is '.$refid);
    		
    //if($sql2->num_rows == 0){
	    if($sql == true){
    		$upids = get_uppler_levels($uid,get_table_data_all('joining_referal')->num_rows,'value');
    		foreach($upids as $key => $ids){
    			$level =  $key+1;
    			$bdt = get_table_data_single_row('joining_referal','level',$level,'bdt');
    			if($ids !== 0){
    				$old_balance = get_table_data_single_row('flc_users','id',$ids,'balance');
    				$new_balance = $old_balance + $bdt;
    				$sql = mysqli_query($db, "UPDATE `flc_users` SET `balance` = '$new_balance' WHERE `id` = '$ids'");
    				accounts_update($ids, $bdt,'Referal income added on balance for level '.$level.' User '.get_table_data_single_row('flc_users','id',$uid,'username'), $old_balance, $new_balance,'cr');
    				$type = $level+7;
					if($type > 13){
						income_entry($ids,$uid,$bdt,13,$type);
					}else{
						income_entry($ids,$uid,$bdt,$type,$type);
					}
    				sendsms(get_table_data_single_row('flc_users','id',$ids,'number'),'Dear SELF EMPLOYMENTS user, You have got '.$bdt.'TK joining commission for level '.$level.' User '.get_table_data_single_row('flc_users','id',$uid,'username'));
    				$sql = mysqli_query($db, "UPDATE `act_request` SET `status` = '1',`accept` = '".get_table_data_single_row('admin','id',$_SESSION['flc_admin'],'number')."' WHERE  `id` = '$id'");
    				
    			}
    		}
    		header('Location:act_request.php');
					
    	}else{
    		echo mysqli_error($db);
    	}
	//}else{
	//    header('Location:act_request.php');
	//}
}
if(isset($_POST['cancel_confirm'])){
	$id = sanetize($_POST['cancel_confirm']);
	$uid = get_table_data_single_row('act_request','id',$id,'uid');
	$number = get_table_data_single_row('flc_users','id',$uid,'number');
	$reason = sanetize($_POST['request_reason']);
	sendsms($number,$reason);
    $sql = mysqli_query($db, "DELETE FROM `act_request` WHERE `id` = '$id'");
	header('Location:act_request.php');
}
if(isset($_POST['sr_name'])){
	$sr_name = sanetize($_POST['sr_name']);
	
	$sql = mysqli_query($db, "SELECT `id` FROM `flc_users` WHERE `username` LIKE '%".$sr_name."%'");
	$ids_array = array();
	
	foreach($sql as $ids){
		$ids_array[] = $ids['id'];
	}
	//print_r($ids_array);
	$search = array();
	foreach($ids_array as $id){
		$sql2 = mysqli_query($db, "SELECT * FROM `act_request` WHERE `uid` = '$id'");
		foreach($sql2 as $requests){
			$search[] =  $requests;
		}
	}
	
	
}
if(isset($_POST['sr_mobile'])){
	$sr_mobile = sanetize($_POST['sr_mobile']);
	
	$ids = get_table_data_single_row('flc_users','number',$sr_mobile,'id');
	$ids_array = array();
	$ids_array[] = $ids;
	
	//print_r($ids_array);
	$search = array();
	foreach($ids_array as $id){
		$sql2 = mysqli_query($db, "SELECT * FROM `act_request` WHERE `uid` = '$id'");
		foreach($sql2 as $requests){
			$search[] =  $requests;
		}
	}
	
	
}
if(isset($_POST['sr_referid'])){
	$sr_referid = sanetize($_POST['sr_referid']);
	$ids = $sr_referid - 112233;
	
	$ids_array = array();
	$ids_array[] = $ids;
	
	//print_r($ids_array);
	$search = array();
	foreach($ids_array as $id){
		$sql2 = mysqli_query($db, "SELECT * FROM `act_request` WHERE `uid` = '$id'");
		foreach($sql2 as $requests){
			$search[] =  $requests;
		}
	}
	//print_r($search);
	
}
if(isset($_POST['sr_sender'])){
	$sr_sender = sanetize($_POST['sr_sender']);
	
	
	$search = mysqli_query($db, "SELECT * FROM `act_request` WHERE `sender` = '$sr_sender'");
		
	//print_r($search);
	
}
if(isset($_POST['sr_trxid'])){
	$sr_trxid = sanetize($_POST['sr_trxid']);
	$search = mysqli_query($db, "SELECT * FROM `act_request` WHERE `trxid` = '$sr_trxid'");	
	//print_r($search);
}
if(isset($_POST['sr_date'])){
	$sr_date = sanetize($_POST['sr_date']);
	$search = mysqli_query($db, "SELECT * FROM `act_request` WHERE `date` = '$sr_date'");	
	//print_r($search);
}
?>
<div class="modal fade" id="acceptModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Confirm Request</h4>
      </div>
      <div class="modal-body">
          <p>Are you sure, you want to accept? </p>
        <a href="?accept=" id="accept_confirm" class="btn btn-success"  >Yes</a>
        <a href="act_request.php" class="btn btn-danger"  >No</a>
      </div>
      <div class="modal-footer">
        
       
      </div>
    </div>
  </div>
</div>
	
	<div class="container col-md-10 col-sm-10"  >
		 
		 <div href="#" class="" style="text-decoration:none;">
			<?php if($_GET['cancel']){?>
				<div class="panel panel-body">
					<div class="panel-body">
						<form class="form-inline" action="<?php $_SERVER['REQUEST_URI'];?>" method="post" >
							<input type="text"  class="form-control" placeholder="Insert Cancel Reason" name="request_reason"   />
							<input type="hidden"   class="form-control" placeholder="Insert Cancel Reason" name="cancel_confirm" value="<?php echo sanetize($_GET['cancel']);?>"   />
							<input type="submit" value="Cancel Request" class="btn btn-danger"  />
						</form>
					</div>
				</div>
			<?php }?>
			<div class="panel panel-body">
				<div class="panel-body">
					<form action="act_request.php?search" method="post"  class="form-inline pull-left form-group">
						<div class="input-group">
						  <input type="text" placeholder="Search By Name" name="sr_name"  class="form-control" aria-label="...">
						  <div class="input-group-btn">
							<button class="btn btn-success" >Search</button>
						  </div>
						</div>
					</form>
					<form action="act_request.php?search" method="post"  class="form-inline pull-left form-group">
						<div class="input-group">
						  <input type="text" placeholder="Search By Mobile" name="sr_mobile"   class="form-control" aria-label="...">
						  <div class="input-group-btn">
							<button class="btn btn-success" >Search</button>
						  </div>
						</div>
					</form>
					<form action="act_request.php?search" method="post"  class="form-inline pull-left form-group">
						<div class="input-group">
						  <input type="text" placeholder="Search By Refer ID" name="sr_referid"   class="form-control" aria-label="...">
						  <div class="input-group-btn">
							<button class="btn btn-success" >Search</button>
						  </div>
						</div>
					</form>
					<form action="act_request.php?search" method="post"  class="form-inline pull-left form-group">
						<div class="input-group">
						  <input type="text" placeholder="Search By Sender Number" name="sr_sender"   class="form-control" aria-label="...">
						  <div class="input-group-btn">
							<button class="btn btn-success" >Search</button>
						  </div>
						</div>
					</form>
					<form action="act_request.php?search" method="post"  class="form-inline pull-left form-group">
						<div class="input-group">
						  <input type="text" placeholder="Search By TrxID" name="sr_trxid"   class="form-control" aria-label="...">
						  <div class="input-group-btn">
							<button class="btn btn-success" >Search</button>
						  </div>
						</div>
					</form>
					
					<form action="act_request.php?search" method="post"  class="form-inline pull-left form-group">
						<div class="input-group">
						  <input type="text" id="datepicker3"  placeholder="Search By Request Date" name="sr_date"   class="form-control" aria-label="..."/>
						  <div class="input-group-btn">
							<button class="btn btn-success" >Search</button>
						  </div>
						</div>
					</form>
					
				</div>
			</div>
			<div class="panel panel-default">
				<div class="panel-heading">
					<h4>Activation Requests</h4>
				</div>
				<div class="panel-body table-responsive">
					<table class="table table-bordered table-striped">
						<tr class="text-nowrap" >
							<th>Action</th>
							<th>Name</th>
							<th>Mobile-Number</th>
							<th>Referrance-Number</th>
							<th>Referr ID</th>
							<th>Sender Number</th>
							<th>Paid Amount</th>
							<th>Transection ID</th>
							<th>Date</th>
							<th>Time</th>
							<th>Accepted By</th>
						</tr>
						<?php 
						if(isset($_GET['search'])){
							foreach($search as $users){?>
								<tr>
									<td>
										<?php if($users['status'] == '0'){?>
											<a class="btn btn-success btn-sm take_accept_id" data-toggle="modal" data-target="#acceptModal" rev="<?php echo $users['id'];?>">Accept</a>
										    <a class="btn btn-danger btn-sm"  href="act_request.php?cancel=<?php echo $users['id'];?>">Cancel</a>
										<?php }else if($users['status'] == '1'){
											echo 'Accepted';
										}?>
									</td>
									<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'username')?></td>
									<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'number')?></td>
									<td><?php echo get_table_data_single_row('flc_users','id',get_table_data_single_row('flc_users','id',$users['uid'],'ref'),'number')?></td>
									<td><?php echo 112233 + $users['uid']?></td>
									<td><?php echo $users['sender']?></td>
									<td><?php echo $users['amount']?></td>
									<td><?php echo $users['trxid']?></td>
									<td><?php echo $users['date']?></td>
									<td><?php echo $users['time']?></td>
									<td><?php echo $users['accept'];?></td>
									
								</tr>
							<?php }
						}else{
						if(!isset($_GET['list'])){
						foreach(get_ten_data('act_request') as $users){?>
							<tr>
								<td>
									<?php if($users['status'] == '0'){?>
										<a class="btn btn-success btn-sm take_accept_id" data-toggle="modal" data-target="#acceptModal" rev="<?php echo $users['id'];?>">Accept</a>
										<a class="btn btn-danger btn-sm"  href="act_request.php?cancel=<?php echo $users['id'];?>">Cancel</a>
									<?php }else if($users['status'] == '1'){
										echo 'Accepted';
									}?>
								</td>
								<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'username')?></td>
								<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'number')?></td>
								<td><?php echo get_table_data_single_row('flc_users','id',get_table_data_single_row('flc_users','id',$users['uid'],'ref'),'number')?></td>
								<td><?php echo 112233 + $users['uid']?></td>
								<td><?php echo $users['sender']?></td>
								<td><?php echo $users['amount']?></td>
								<td><?php echo $users['trxid']?></td>
								<td><?php echo $users['date']?></td>
								<td><?php echo $users['time']?></td>
								<td><?php echo $users['accept'];?></td>
								
							</tr>
						<?php }}else{
							foreach(paginationed($_GET['list'],'act_request') as $users){
							?>
							<tr>
								<td>
									<?php if($users['status'] == '0'){?>
										<a class="btn btn-success btn-sm take_accept_id" data-toggle="modal" data-target="#acceptModal" rev="<?php echo $users['id'];?>">Accept</a>
										<a class="btn btn-danger btn-sm"  href="act_request.php?cancel=<?php echo $users['id'];?>">Cancel</a>
									<?php }else if($users['status'] == '1'){
										echo 'Accepted';
									}?>
								</td>
								<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'username')?></td>
								<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'number')?></td>
								<td><?php echo get_table_data_single_row('flc_users','id',get_table_data_single_row('flc_users','id',$users['uid'],'ref'),'number')?></td>
								<td><?php echo 112233 + $users['id']?></td>
								<td><?php echo $users['sender']?></td>
								<td><?php echo $users['amount']?></td>
								<td><?php echo $users['trxid']?></td>
								<td><?php echo $users['date']?></td>
								<td><?php echo $users['time']?></td>
								<td><?php echo $users['accept'];?></td>
								
							</tr>
							<?php }}}?>
					</table>
				</div>
				<?php if(!isset($_GET['search'])){?>
					<div class="pagination">
						  <?php 
						  $count = 0;
						  
						  $rows = pagination_list('act_request');
						  if($rows > 1){
							for($count = 0; $count < $rows; $count++ ){?>
							<li><a class="table_pagination_links <?php if($_GET['list'] == $count){echo 'active';}?>" <?php if($count  > ($_GET['list'] + 4)){echo 'style="display:none;"';}else if($count  < ($_GET['list'] - 4)){echo 'style="display:none;"';}?>  href="act_request.php?list=<?php echo $count;?>"><?php echo $count+1;?></a></li>
						  <?php }}?>
					</div>
				<?php }?>
			 </div>
		 </div>
		
		
		
		 
		 
	</div>
<?php
  include 'include/footer.php';
?>