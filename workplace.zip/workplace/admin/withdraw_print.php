<?php
include 'include/head.php';

$from = sanetize($_GET['print_search_from']);
$to = sanetize($_GET['print_search_to']);
$type = sanetize($_GET['print_search_method']);

$sql = mysqli_query($db, "SELECT * FROM `withdraw` WHERE `status` = '0' AND `method`= '$type' AND `date` BETWEEN '$from' AND '$to'");

?>
<?php  
if($type == 'bkash'){?>
    <table class="table" >
        <tr>
            <th>User Name</th>
            <th>User Number</th>
            <th>Bkash Number</th>
            <th>Withdraw Amount</th>
        </tr>
        <?php foreach($sql as $data){
       
								    if($data['charge'] == '0.00' ||  $data['charge'] == ''){ 
									    $charge = ($data['amount'] / 100) * get_table_data_single_row('dynamics','content','withdraw_charge','value');
									     $charge;
									}else{echo $data['charge'];}
								
							   
							        if($data['provident'] == '0.00' || $data['provident'] == ''){ 
									     $provident = ($data['amount'] / 100) * get_table_data_single_row('dynamics','content','provident_fund','value');
									
									}else{echo $data['provident'];}
								
        ?>
            <tr>
                <td><?php echo get_table_data_single_row('flc_users','id',$data['uid'],'username');?></td>
                <td><?php echo get_table_data_single_row('flc_users','id',$data['uid'],'number');?></td>
                <td><?php echo $data['receiver'];?></td>
                <td><?php echo $data['amount'] - ($charge + $provident);?></td>
            </tr>
        <?php }?>
        
        
    </table>
<?php }else{ ?>
    <table class="table" >
        <tr>
            <th>User Name</th>
            <th>User Number</th>
            <th>Bank Name</th>
            <th>Branch Name</th>
            <th>Account Name</th>
            <th>Account Number</th>
            <th>Withdraw Amount</th>
        </tr>
        <?php foreach($sql as $data){
       
		    if($data['charge'] == '0.00' ||  $data['charge'] == ''){ 
			    $charge = ($data['amount'] / 100) * get_table_data_single_row('dynamics','content','withdraw_charge','value');
			     $charge;
			}else{echo $data['charge'];}
		
	   
	        if($data['provident'] == '0.00' || $data['provident'] == ''){ 
			     $provident = ($data['amount'] / 100) * get_table_data_single_row('dynamics','content','provident_fund','value');
			
			}else{echo $data['provident'];}
								
        ?>
            <tr>
                <td><?php echo get_table_data_single_row('flc_users','id',$data['uid'],'username');?></td>
                <td><?php echo get_table_data_single_row('flc_users','id',$data['uid'],'number');?></td>
                <td><?php echo $data['bank_name'];?></td>
                <td><?php echo $data['branch_name'];?></td>
                <td><?php echo $data['acc_name'];?></td>
                <td><?php echo $data['acc_number'];?></td>
                <td><?php echo $data['amount'] - ($charge + $provident);?></td>
            </tr>
        <?php }?>
        
        
    </table>
<?php } ?>



