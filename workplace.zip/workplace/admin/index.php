<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
  if(loggedin() == false){
	  header("Location:login.php");
  }

  if(checkaccess($_SESSION['flc_admin'], 'index.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
  //print_r($_SESSION);
?>
	
	<div class="container col-lg-10 col-md-10 col-sm-9 col-xs-12">
	    <ul class="nav nav-tabs">
          <li role="presentation" <?php if(isset($_GET['members'])){echo 'class="active"';}?> ><a href="index.php?members">Total Members</a></li>
          <li role="presentation" <?php if(isset($_GET['device'])){echo 'class="active"';}?> ><a href="index.php?device">Devices</a></li>
          <li role="presentation" <?php if(isset($_GET['age'])){echo 'class="active"';}?> ><a href="index.php?age">Age</a></li>
          <li role="presentation" <?php if(isset($_GET['blood'])){echo 'class="active"';}?> ><a href="index.php?blood">Blood Group</a></li>
          <li role="presentation" <?php if(isset($_GET['occ'])){echo 'class="active"';}?> ><a href="index.php?occ">Occupation</a></li>
          <li role="presentation" <?php if(isset($_GET['qua'])){echo 'class="active"';}?> ><a href="index.php?qua">Qualification</a></li>
          <li role="presentation" <?php if(isset($_GET['location'])){echo 'class="active"';}?> ><a href="index.php?location">Location</a></li>
          <li role="presentation" <?php if(isset($_GET['income'])){echo 'class="active"';}?> ><a href="index.php?income">Income</a></li>
          <li role="presentation" <?php if(isset($_GET['withdraw'])){echo 'class="active"';}?> ><a href="index.php?withdraw">Withdraw</a></li>
          <li role="presentation" <?php if(isset($_GET['sale'])){echo 'class="active"';}?> ><a href="index.php?sale">Sale</a></li>
        </ul>
	 	<?php if(isset($_GET['members'])){?>
	 	<div class="panel panel-default">
			<div class="panel-heading">
				<h2>Total Members (<?php echo get_table_data_all('flc_users')->num_rows;?>)</h2>
			</div>
			<div class="panel-body">
				
				<div class="new_cards col-md-4 col-sm-4 col-xs-12">
					<div class="cards_left">
						Active
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','status','1')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-4 col-sm-4 col-xs-12">
					<div class="cards_left">
						Inactive
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','status','0')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-4 col-sm-4 col-xs-12">
					<div class="cards_left">
						Suspended
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','status','2')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-4 col-sm-4 col-xs-12">
					<div class="cards_left">
						Varified
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','varify','1')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-4 col-sm-4 col-xs-12">
					<div class="cards_left">
						Un-Varified
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','varify','0')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-4 col-sm-4 col-xs-12">
					<div class="cards_left">
						General
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','type','0')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-4 col-sm-4 col-xs-12">
					<div class="cards_left">
						Besic
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','type','1')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-4 col-sm-4 col-xs-12">
					<div class="cards_left">
						Advanced
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','type','2')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-4 col-sm-4 col-xs-12">
					<div class="cards_left">
						Premium
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','type','3')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-4 col-sm-4 col-xs-12">
					<div class="cards_left">
						Ambassadors
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','type','4')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-4 col-sm-4 col-xs-12">
					<div class="cards_left">
						<p style="font-size:14px;" >Brand Ambassadors</p>
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','type','5')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-4 col-sm-4 col-xs-12">
					<div class="cards_left">
						Male
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','gender','male')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-4 col-sm-4 col-xs-12">
					<div class="cards_left">
						Femele
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','gender','female')->num_rows;?>
					</div>
				</div>
			</div>
		</div>
	 	<?php }else if(isset($_GET['device'])){?>
	 	<div class="panel panel-default">
			<div class="panel-heading">
				<h2>Working Device</h2>
			</div>
			<div class="panel-body">
				
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Laptop
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','device','laptop')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Desktop
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','device','desktop')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Android
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','device','android')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						iOS
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','device','ios')->num_rows;?>
					</div>
				</div>
			</div>
		</div>
	 	<?php }else if(isset($_GET['age'])){?>
	 		<div class="panel panel-default">
			<div class="panel-heading">
				<h2>Age Range</h2>
			</div>
			<div class="panel-body">
				
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						10-17
					</div>
					<div class="cards_right">
						<?php echo get_age_range('10','17');?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						18-25
					</div>
					<div class="cards_right">
						<?php echo get_age_range('18','17');?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						26-34
					</div>
					<div class="cards_right">
						<?php echo get_age_range('26','34');?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						35-45
					</div>
					<div class="cards_right">
						<?php echo get_age_range('35','45');?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						46-55
					</div>
					<div class="cards_right">
						<?php echo get_age_range('46','55');?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						56+
					</div>
					<div class="cards_right">
						<?php echo get_age_range('10','17');?>
					</div>
				</div>
			</div>
		</div>
	 	<?php }else if(isset($_GET['blood'])){?>
	 		<div class="panel panel-default">
			<div class="panel-heading">
				<h2>Blood Group Info</h2>
			</div>
			<div class="panel-body">
				
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						A+
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','blood','A+')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						A-
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','blood','A-')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						B+
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','blood','B+')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						B-
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','blood','B-')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						O+
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','blood','O+')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						O-
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','blood','O-')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						AB+
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','blood','AB+')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						AB-
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','blood','AB-')->num_rows;?>
					</div>
				</div>
			</div>
		</div>
	 	<?php }else if(isset($_GET['occ'])){?>
	 	<div class="panel panel-default">
			<div class="panel-heading">
				<h2>Members Occupation Info</h2>
			</div>
			<div class="panel-body">
				
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Job
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','occ','Job')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Business
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','occ','Business')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Student
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','occ','Student')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Unemployed
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','occ','Unemployed')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Housewife
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','occ','Housewife')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Immigrant
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','occ','Immigrant')->num_rows;?>
					</div>
				</div>
			</div>
		</div>
	 	<?php }else if(isset($_GET['qua'])){?>
	 		<div class="panel panel-default">
			<div class="panel-heading">
				<h2>Members Qualification Info</h2>
			</div>
			<div class="panel-body">
				
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Primary
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','edu','Primary')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Secondary
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','edu','Secondary')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						<p style="font-size: 12px" >Higher Secondary</p>
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','edu','Higher Secondary')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Graguate
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','edu','Graguate')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						<p style="font-size: 14px" >Post-graguate</p>
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','edu','Post-graguate')->num_rows;?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						<p style="font-size: 14px" >Higher Degree</p>
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('flc_users','edu','Higher Degree')->num_rows;?>
					</div>
				</div>
			</div>
		</div>
	 	<?php }else if(isset($_GET['location'])){?>
	 		<div class="panel panel-default">
			<div class="panel-heading">
				<h2>Members Location Info</h2>
			</div>
			<div class="panel-body">
				
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Dhaka 
					</div>
					<div class="cards_right">
						<?php echo get_address_like('Dhaka');?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Chittagong 
					</div>
					<div class="cards_right">
						<?php echo get_address_like('Chittagong');?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Rajshahi
					</div>
					<div class="cards_right">
						<?php echo get_address_like('Rajshahi');?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Sylhet
					</div>
					<div class="cards_right">
						<?php echo get_address_like('Sylhet');?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Rongpur
					</div>
					<div class="cards_right">
						<?php echo get_address_like('Rongpur');?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Khulna 
					</div>
					<div class="cards_right">
						<?php echo get_address_like('Khulna');?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Barishal 
					</div>
					<div class="cards_right">
						<?php echo get_address_like('Barishal');?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Mymensingh
					</div>
					<div class="cards_right">
						<?php echo get_address_like('Mymensingh');?>
					</div>
				</div>
			</div>
		</div>
	 	<?php }else if(isset($_GET['income'])){?>
	 		<div class="panel panel-default">
			<div class="panel-heading">
				<h2>Total Income Report</h2>
			</div>
			<div class="panel-body">
				
				<div class="new_cards col-md-6 col-sm-6 col-xs-12">
					<div class="cards_left">
						Work income
					</div>
					<div class="cards_right">
						<?php echo get_incomes_reports('own_work');?>
					</div>
				</div>
				<div class="new_cards col-md-6 col-sm-6 col-xs-12">
					<div class="cards_left">
						Refer work income
					</div>
					<div class="cards_right">
						<?php echo get_incomes_reports('refer_work');?>
					</div>
				</div>
				<div class="new_cards col-md-6 col-sm-6 col-xs-12">
					<div class="cards_left">
						Joining income
					</div>
					<div class="cards_right">
						<?php echo get_incomes_reports('joining');?>
					</div>
				</div>
				<div class="new_cards col-md-6 col-sm-6 col-xs-12">
					<div class="cards_left">
						Instant bonus 
					</div>
					<div class="cards_right">
						0<?php //echo get_address_like('Sylhet');?>
					</div>
				</div>
				<div class="new_cards col-md-6 col-sm-6 col-xs-12">
					<div class="cards_left">
						Designation bonus 
					</div>
					<div class="cards_right">
						0<?php //echo get_address_like('Rongpur');?>
					</div>
				</div>
				<div class="new_cards col-md-6 col-sm-6 col-xs-12">
					<div class="cards_left">
						Provident fund 
					</div>
					<div class="cards_right">
						<?php echo get_provident_fund();?>
					</div>
				</div>
				<div class="new_cards col-md-6 col-sm-6 col-xs-12">
					<div class="cards_left">
						Product sales income
					</div>
					<div class="cards_right">
						<?php echo get_incomes_reports('purchase');?>
					</div>
				</div>
				<div class="new_cards col-md-6 col-sm-6 col-xs-12">
					<div class="cards_left">
						Delivery points income
					</div>
					<div class="cards_right">
						<?php echo get_incomes_reports('delivery');?>
					</div>
				</div>
			</div>
		</div>
		
	 	<?php }else if(isset($_GET['withdraw'])){?>
	 		<div class="panel panel-default">
			<div class="panel-heading">
				<h2>Total Withdraw Report</h2>
			</div>
			<div class="panel-body">
				<div class="new_cards col-md-4 col-sm-4 col-xs-12">
					<div class="cards_left">
						Total Primary
					</div>
					<div class="cards_right">
						<?php 
						$query = mysqli_query($db, "SELECT SUM(`p_balance`) as `sum` FROM `flc_users`");
						$p_balance = mysqli_fetch_assoc($query);
						echo $p_balance['sum'];
						?>
					</div>
				</div>
				<div class="new_cards col-md-4 col-sm-4 col-xs-12">
					<div class="cards_left">
						Total Primary
					</div>
					<div class="cards_right">
						<?php 
						$query = mysqli_query($db, "SELECT SUM(`s_balance`) as `sum` FROM `flc_users`");
						$s_balance = mysqli_fetch_assoc($query);
						echo $s_balance['sum'];
						?>
					</div>
				</div>
				<div class="new_cards col-md-4 col-sm-4 col-xs-12">
					<div class="cards_left">
						Total Primary
					</div>
					<div class="cards_right">
						<?php 
						$query = mysqli_query($db, "SELECT SUM(`balance`) as `sum` FROM `flc_users`");
						$balance = mysqli_fetch_assoc($query);
						echo $balance['sum'];
						?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Success
					</div>
					<div class="cards_right">
						<?php echo get_withdraws('success');?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Pending
					</div>
					<div class="cards_right">
						<?php echo get_withdraws('pending');?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Cancelled
					</div>
					<div class="cards_right">
						<?php echo get_withdraws('cancelled');?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Bkash
					</div>
					<div class="cards_right">
						<?php echo get_withdraws('bkash');?>
					</div>
				</div>
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						Bank
					</div>
					<div class="cards_right">
						<?php echo get_withdraws('bank');?>
					</div>
				</div>
			</div>
		</div>
	 	<?php }else if(isset($_GET['sale'])){?>
	 		<div class="panel panel-default">
			<div class="panel-heading">
				<h2>Total Product Sales</h2>
			</div>
			<div class="panel-body">
				
				<div class="new_cards col-md-3 col-sm-3 col-xs-12">
					<div class="cards_left">
						iSecure
					</div>
					<div class="cards_right">
						<?php echo get_table_data_specific('i_purchase','status','1')->num_rows;?>
					</div>
				</div>
				
			</div>
		</div>
	 	<?php }?>
	 	
		
	
	
		
	
	
		
	
	
	
		<div  class="col-md-12  text-center" style="text-decoration:none;">
		 <form class="form-inline pull-left" action="<?php echo $_SERVER['REQUEST_URI']?>" method="POST" >
		     <div class="form-group" >
		         <input class="form-control" type="text" name="report_from"  id="datepicker" placeholder="From Date"   />
		     </div>
		     <div class="form-group" >
		         <input class="form-control" type="text" name="report_to"  id="datepicker2" placeholder="To Date"   />
		     </div>
		     
		     <div class="form-group" >
		         <input class="btn btn-success" type="submit" value="Search"  id="datepicker" placeholder="To Date"   />
		     </div>
		 </form>	
		 <div class="clearfix" ></div>
			<div class="panel panel-default">
				<div class="panel-heading">
					<h4>Admin Report</h4>
				</div>
				
				<div class="panel-body">
					<table class="table table-bordered table-striped">
						<tr class="text-center" >
						    <th class="text-center" >Work Income</th>
						    <th class="text-center" >Referal Work Income</th>
						    <th class="text-center">Activtated Users</th>
						    <th class="text-center">Activation Income</th>
						   
						    <th class="text-center">Product Sells </th>
						    <th class="text-center">Product Sells Income </th>
						    <th class="text-center">Product Delivered </th>
						    <th class="text-center">Delivery Points Income</th>
						</tr>
						<?php if(isset($_POST['report_from'])){?>
						<tr>
						    
						    <th>
						        <?php echo round(get_report_work_income($_POST['report_from'],$_POST['report_to']),2);?>
						    </th>
						    <th>
						        <?php echo round(get_report_ref_work_income($_POST['report_from'],$_POST['report_to']),2);?>
						    </th>
						    <th><?php echo get_report_activated_users($_POST['report_from'],$_POST['report_to']);?></th>
						    <th><?php echo get_report_act_income($_POST['report_from'],$_POST['report_to']);?></th>
						   
						    <th><?php echo get_report_bkash_sells($_POST['report_from'],$_POST['report_to']);?></th>
						    <th><?php echo get_report_product_sells_incomes($_POST['report_from'],$_POST['report_to']);?></th>
						    <th>
						        <?php echo product_delivered($_POST['report_from'],$_POST['report_to']);?>
						    </th>
							<th>
						        <?php echo get_report_distributed($_POST['report_from'],$_POST['report_to']);?>
						    </th>
						</tr>
						<?php }?>
						
					</table>
				</div>
			</div>
		</div>
<?php

  include 'include/footer.php';
?>