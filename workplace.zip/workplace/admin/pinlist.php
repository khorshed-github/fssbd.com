<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
  if(loggedin() == false){
	  header("Location:login.php");
  }

  if(checkaccess($_SESSION['flc_admin'], 'dynamics.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
error_reporting(0);
if(isset($_GET['delete'])){
    $id = sanetize($_GET['delete']);
    $sql = mysqli_query($db, "DELETE FROM `adds` WHERE `id` = '$id'");
    if($sql == true){
        header('Location:adds.php');
    }
}

if(isset($_POST['edit_value'])){
	$value 	= sanetize($_POST['edit_value']);
	$id 	= sanetize($_GET['edit']);
    $sql = mysqli_query($db, "UPDATE `i_pins` SET `pin` = '$value' WHERE `id` = '$id'");
    if($sql == true){
        header("Location:pinlist.php");
    }
}
if(isset($_POST['pin_1'])){
	foreach($_POST as $pins){
		$sql = mysqli_query($db, "INSERT INTO `i_pins` (`pin`)VALUES('$pins')");
	}
	header('Location:pinlist.php');
}
?>
	
	<div class="container col-md-10 col-sm-10"  >
		 
		 <div href="#" class="" style="text-decoration:none;">
			<?php if(isset($_GET['edit'])){?>
				<div class="panel panel-default">
					<div class="panel-heading">
						Edit
					</div>
					<div class="panel-body">
						<form action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post" class="form-inline" enctype="multipart/form-data" >
							<div class="form-group">
								Edit Pin Number
							</div>
							<div class="form-group">
								<input type="text" name="edit_value" <?php echo 'value="'.get_table_data_single_row('i_pins','id',sanetize($_GET['edit']),'pin').'"'; ?> placeholder="script" class="form-control"  />
							</div>
						
							<div class="form-group">
								<input type="submit" value="Insert " class="btn btn-success"   />
							</div>
						</form>
						
					</div>
				</div>
			<?php }else if(isset($_GET['create'])){?>
				<div class="panel panel-default">
					<div class="panel-body">
						<form class="form-inline" action="pinlist.php" method="post"  >
							<?php 
							if(is_numeric($_GET['create'])){
								set_time_limit(3);
								$cont = 0;
								$count = 0;
								while($cont == 0){
									if($count == $_GET['create']){
										$cont = 1;
									}else{
										echo '
										<input type="text" name="pin_'.$count.'" class="form-control" style="margin:10px;"   />
										';
										$count++;
									}
								}
							}
							
							
							?>
							<br />
							<div class="form-group">
								<input type="submit" value="Create Pin" class="form-control"  />
							</div>
						</form>
					</div>
				</div>
			<?php } ?>
			
			<div class="panel panel-default">
				<div class="panel-body">
					<form class="form-inline" action="pinlist.php" method="get"  >
						<div class="input-group">
							<input type="text" name="create"  placeholder="Insert pin count" class="form-control" />
							<span class="input-group-btn">
								<button class="btn btn-default" type="submit">Create</button>
							</span>
						</div>
					</form>
				</div>
			</div>
			<div class="panel panel-default">
				<div class="panel-heading">
					<h4>Withdraw Requests </h4>
					
				</div>
				<span  ><?php if(!empty($error)){echo '<div class="alert alert-danger">'.$error[0].'</div> ';}?></span>
										
				<div class="panel-body table-responsive">
					
					<table class="table table-bordered table-striped">
						<tr class="text-nowrap" >
							<th>Action</th>
							<th>Pin-Number</th>
							<th>User Number</th>
							<th>Status</th>
							
							
						</tr>
						<?php 
						if(!isset($_GET['list'])){
						foreach(get_ten_data('i_pins') as $users){
						
						?>
							<tr>
								<td>
									<a href="pinlist.php?edit=<?php echo $users['id'];?>" class="btn btn-success btn-xs" >Edit</a>
								</td>
								<td><?php echo $users['pin']?></td>
								<td><?php echo get_table_data_single_row('i_users','id',$users['uid'],'number');?></td>
								<td><?php if($users['status'] == '1'){echo 'used';}else if($users['status'] == '0'){echo 'Unused';}?></td>
								
								
							</tr>
						<?php }}else{
							foreach(paginationed($_GET['list'],'i_pins') as $users){
							?>
							<tr>
								<td>
									<a href="pinlist.php?edit=<?php echo $users['id'];?>" class="btn btn-success btn-xs" >Edit</a>
								</td>
								<td><?php echo $users['pin']?></td>
								<td><?php echo get_table_data_single_row('i_users','id',$users['uid'],'number');?></td>
								<td><?php if($users['status'] == '1'){echo 'used';}else if($users['status'] == '0'){echo 'Unused';}?></td>
								
								
							</tr>
							<?php }}?>
					</table>
				</div>
				<div class="pagination">
					  <?php 
					  $count = 0;
					  
					  $rows = pagination_list('i_pins');
					  if($rows > 1){
						for($count = 0; $count < $rows; $count++ ){?>
						<li><a class="table_pagination_links <?php if($_GET['list'] == $count){echo 'active';}?>" <?php if($count  > ($_GET['list'] + 4)){echo 'style="display:none;"';}else if($count  < ($_GET['list'] - 4)){echo 'style="display:none;"';}?>  href="pinlist.php?list=<?php echo $count;?>"><?php echo $count+1;?></a></li>
					  <?php }}?>
				</div>
			 </div>
			
		
			</div>
		</div>
	</div>
<?php
  include 'include/footer.php';
?>