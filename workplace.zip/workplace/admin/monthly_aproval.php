<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
  //echo date('H:i', time());
  error_reporting(0);
  //print_r($_SESSION['aproval_checked']);
  if(loggedin() == false){
	  header("Location:login.php");
  }
	if(checkaccess($_SESSION['flc_admin'], 'daily_aproval.php') == false){
		echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
		You don\'t have access to this page
		</div>';
		die();
	}
	
	$day =  gmdate('j', time()+(6*60*60));
	//$hour =  gmdate('G', time()+(6*60*60));
	//echo $day.' '.$hour;
	if($day !== get_table_data_single_row('dynamics','content','withdrawals_date','value')){
		echo '<div class="alert alert-danger col-md-10 text-center">Request will be available at withdraw date</div>';
		die();
	}
if(isset($_POST['percent'])){
	$percent = sanetize($_POST['percent']);
	foreach($_SESSION['aproval_checked'] as $ids){
		$userinfo = get_table_data_specific('flc_users','id',$ids);
		$userinfo = mysqli_fetch_assoc($userinfo);
		$cut = ($userinfo['s_balance'] / 100) * $percent;
		$amount = $userinfo['s_balance'] - $cut;
		$old_balance = $userinfo['balance'];
		$new_s_balance = $userinfo['balance'] + $amount;
		$update = mysqli_query($db,"UPDATE `flc_users` SET `balance` = '$new_s_balance',`s_balance` = '0' WHERE `id` = '$ids'");
		accounts_update($ids, $amount,'Finilized balance credited',$old_balance,$new_s_balance,'cr');
	}
	//$sql = mysqli_query($db, "UPDATE `flc_users` SET `s_balance` = '0'");
	$sql = mysqli_query($db, "SELECT * FROM `flc_users` WHERE `s_balance` != '0.00'");
	foreach($sql as $idds){
	    $userinfo = get_table_data_specific('flc_users','id',$idds);
		$userinfo = mysqli_fetch_assoc($userinfo);
		
		$amount = $userinfo['s_balance'];
		$new_s_balance = $userinfo['balance'] + $amount;
		$update = mysqli_query($db,"UPDATE `flc_users` SET `balance` = '$new_s_balance',`s_balance` = '0' WHERE `id` = '$idds'");
	}
	unset($_SESSION['aproval_checked']);
	header('Location:monthly_aproval.php');
}
?>
	
	<div class="container col-md-10 col-sm-10"  >
		 <div href="#" class="" style="text-decoration:none;">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h4>Monthly Aprovals</h4>
				</div>
				<div class="panel-body table-responsive">
					<div class="form-group">
						<div class="btn btn-success select_all_aproval_two" >Select All</div>
					</div>
					<table class="table table-bordered table-striped">
						<tr class="text-nowrap" >
							<th>Check for Aprove</th>
							<th>User-name</th>
							<th>Number</th>
							<th>Secondary Balance</th>
						</tr>
						<?php 
						if(!isset($_GET['list'])){
						foreach(get_ten_data_aproval_monthly('flc_users') as $users){?>
							<tr>
								<td>
									<input type="checkbox" class="checked_for_aproval" value="<?php echo $users['id'];?>"  <?php if(is_select_aproval($users['id']) == true){echo 'checked';}?>  /> 
								</td>
								<td><?php echo $users['username']?></td>
								<td><?php echo $users['number']?></td>
								
								<td><?php echo $users['s_balance']?></td>
							</tr>
						<?php }}else{
							foreach(paginationed_aproval_monthly($_GET['list'],'flc_users') as $users){
							?>
							<tr>
								<td>
									<input type="checkbox"  class="checked_for_aproval" value="<?php echo $users['id'];?>"  <?php if(is_select_aproval($users['id']) == true){echo 'checked';}?>  /> 
								</td>
								<td><?php echo $users['username']?></td>
								<td><?php echo $users['number']?></td>
								
								<td><?php echo $users['s_balance']?></td>
							</tr>
							<?php }}?>
					</table>
				</div>
				<div class="pagination">
					  <?php 
					  $count = 0;
					  
					  $rows = pagination_list_aproval_monthly('flc_users');
					  if($rows > 1){
						for($count = 0; $count < $rows; $count++ ){?>
						<li><a class="table_pagination_links <?php if($_GET['list'] == $count){echo 'active';}?>" <?php if($count  > ($_GET['list'] + 4)){echo 'style="display:none;"';}else if($count  < ($_GET['list'] - 4)){echo 'style="display:none;"';}?>  href="monthly_aproval.php?list=<?php echo $count;?>"><?php echo $count+1;?></a></li>
					  <?php }}?>
				</div>
				
			 </div>
				<form action="monthly_aproval.php" method="post" class="form-inline"  >
					<div class="form-group">
						<input type="text" name="percent" placeholder="Insert Percentage"  class="form-control"    />
						<input type="submit" class="btn btn-success"  value="Submit" />
					</div>
				</form>
				<br />
		 </div>
		 
	</div>
<?php
  include 'include/footer.php';
?>