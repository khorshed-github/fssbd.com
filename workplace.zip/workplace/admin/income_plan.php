<?php
	include 'include/head.php';
	include 'include/header.php';
	include 'include/nav.php';
	  if(loggedin() == false){
	  header("Location:login.php");
  }
  if(checkaccess($_SESSION['flc_admin'], 'income_plan.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
	$error = array();
	if(isset($_POST['edit_direct_work'])){
		$id = sanetize($_GET['edit_direct_work']);
		$amount = sanetize($_POST['edit_direct_work']);
		$min = sanetize($_POST['edit_direct_work_min']);
		$max = sanetize($_POST['edit_direct_work_max']);
		if(!empty($amount)){
			$sql = mysqli_query($db, "UPDATE `direct_income` SET `price` = '$amount',`min` = '$min',`max` = '$max' WHERE `id` = '$id'");
			if($sql == true){
				header('Location:income_plan.php');
			}
		}else{
			$error[] = 'Please insert amount';
		}
	}
	if(isset($_POST['referal_income'])){
		$id = sanetize($_GET['referal_income']);
		$amount = sanetize($_POST['referal_income']);
		$level = sanetize($_POST['referal_income_level']);
		if(!empty($amount)){
			$sql = mysqli_query($db, "UPDATE `work_referral` SET `percent` = '$amount',`level` = '$level' WHERE `id` = '$id'");
			if($sql == true){
				header('Location:income_plan.php');
			}
		}else{
			$error[] = 'Please insert value';
		}
	}
	if(isset($_POST['add_referal_income'])){
		//$id = sanetize($_GET['add_work_referal']);
		$amount = sanetize($_POST['add_referal_income']);
		$level = sanetize($_POST['add_referal_income_level']);
		if(!empty($amount)){
			$sql = mysqli_query($db, "INSERT INTO `work_referral` (`level`,`percent`)VALUES('$level','$amount')");
			
			if($sql == true){
				header('Location:income_plan.php');
			}
		}else{
			$error[] = 'Please insert value';
		}
	}
	
	if(isset($_POST['referal_joining'])){
		$id = sanetize($_GET['referal_joining']);
		$level = sanetize($_POST['referal_joining_level']);
		$amount = sanetize($_POST['referal_joining']);
		if(!empty($amount)){
			$sql = mysqli_query($db, "UPDATE `joining_referal` SET `bdt` = '$amount',`level` = '$level' WHERE `id` = '$id'");
			if($sql == true){
				header('Location:income_plan.php');
			}
		}else{
			$error[] = 'Please insert value';
		}
	}
	if(isset($_POST['add_referal_joining'])){
		$id = sanetize($_GET['add_join_referal']);
		$level = sanetize($_POST['add_referal_joining_level']);
		$amount = sanetize($_POST['add_referal_joining']);
		if(!empty($amount)){
			$sql = mysqli_query($db, "INSERT INTO `joining_referal` (`level`,`bdt`)VALUES('$level',$amount)");
			if($sql == true){
				header('Location:income_plan.php');
			}
		}else{
			$error[] = 'Please insert value';
		}
	}
	
	if(isset($_POST['purchase_joining'])){
		$id = sanetize($_GET['purchase_joining']);
		
			$level = sanetize($_POST['purchase_joining_level']);
			$amount = sanetize($_POST['purchase_joining']);
			$amount2 = sanetize($_POST['purchase_joining_non']);
			if(!empty($amount)){
				$sql = mysqli_query($db, "UPDATE `purchase_level` SET `perc` = '$amount',`perc2` = '$amount2',`level` = '$level'  WHERE `id` = '$id'");
				if($sql == true){
					header('Location:income_plan.php');
				}
			}else{
				$error[] = 'Please insert value';
			}
		
	}
	if(isset($_POST['add_purchase_joining'])){
		//$id = sanetize($_GET['product_referal_add']);
		
			$level = sanetize($_POST['add_purchase_joining_level']);
			$amount = sanetize($_POST['add_purchase_joining']);
			$amount2 = sanetize($_POST['add_purchase_joining_non']);
			if(!empty($amount)){
				$sql = mysqli_query($db, "INSERT INTO `purchase_level` (`level`,`perc`,`perc2`)VALUES('$level','$amount','$amount2')");
				if($sql == true){
					header('Location:income_plan.php');
				}
			}else{
				$error[] = 'Please insert value';
			}
		
	}
	if(isset($_POST['desination_bonus_level_1'])){
		$id = sanetize($_GET['desination_bonus']);
		$level1 = sanetize($_POST['desination_bonus_level_1']);
		$level2 = sanetize($_POST['desination_bonus_level_1']);
		$upto6 = sanetize($_POST['desination_bonus_upto_6']);
		$designation = sanetize($_POST['desination_bonus_designation']);
		$bonus = sanetize($_POST['desination_bonus_bonus']);
		if(!empty($level1) && !empty($level2) && !empty($upto6) && !empty($designation) && !empty($bonus)){
			$sql = mysqli_query($db, "UPDATE `designation_bonus` SET 
			`level_1` = '$level1',
			`level_2` = '$level2', 
			`upto_6` = '$upto6', 
			`designation` = '$designation' ,
			`bonus` = '$bonus' 
			WHERE `id` = '$id'");
			if($sql == true){
				header('Location:income_plan.php');
			}
		}else{
			$error[] = 'All Fields Required';
		}
	}
	if(isset($_GET['referal_income_delete'])){
		$id = $_GET['referal_income_delete'];
		$delete = mysqli_query($db, "DELETE FROM `work_referral` WHERE `id` = '$id'");
		header("Location:income_plan.php");
	}
	if(isset($_GET['referal_joining_delete'])){
		$id = $_GET['referal_joining_delete'];
		$delete = mysqli_query($db, "DELETE FROM `joining_referal` WHERE `id` = '$id'");
		header("Location:income_plan.php");
	}
	if(isset($_GET['purchase_joining_delete'])){
		$id = $_GET['purchase_joining_delete'];
		$delete = mysqli_query($db, "DELETE FROM `purchase_level` WHERE `id` = '$id'");
		header("Location:income_plan.php");
	}
?>
	
	<div class="container col-md-10 col-sm-10"  >
		 <?php if(isset($_GET['edit_direct_work'])){?>
			 <form action="<?php $_SERVER['REQUEST_URI'];?>" method="post"  class="form-inline">
				<div class="form-group">
					<input type="text" class="form-control"   name="edit_direct_work" placeholder="Insert New Price"   />
				</div>
				<div class="form-group">
					<input type="text" class="form-control"   name="edit_direct_work_min" placeholder="Minimum Steps"   />
				</div>
				<div class="form-group">
					<input type="text" class="form-control"   name="edit_direct_work_max" placeholder="Maximum Steps"   />
				</div>
				<div class="form-group">
					<input type="submit" class="btn btn-success" value="Edit"  />
				</div>
			 </form>
		 <?php }else if(isset($_GET['referal_income'])){?>
			 <form action="<?php $_SERVER['REQUEST_URI'];?>" method="post"  class="form-inline">
				<div class="form-group">
					<input type="text" class="form-control"   name="referal_income_level" placeholder="Insert New level"   />
				</div>
				<div class="form-group">
					<input type="text" class="form-control"   name="referal_income" placeholder="Insert New Percentage"   />
				</div>
				<div class="form-group">
					<input type="submit" class="btn btn-success" value="Edit"  />
				</div>
			 </form>
		 <?php }else if(isset($_GET['add_work_referal'])){?>
			 <form action="<?php $_SERVER['REQUEST_URI'];?>" method="post"  class="form-inline">
				<div class="form-group">
					<input type="text" class="form-control"   name="add_referal_income_level" placeholder="Insert New level"   />
				</div>
				<div class="form-group">
					<input type="text" class="form-control"   name="add_referal_income" placeholder="Insert New Percentage"   />
				</div>
				<div class="form-group">
					<input type="submit" class="btn btn-success" value="Edit"  />
				</div>
			 </form>
		 <?php }else if(isset($_GET['price_edit'])){?>
			 <form action="<?php $_SERVER['REQUEST_URI'];?>" method="post"  class="form-inline">
				<div class="form-group">
					<input type="text" class="form-control"   name="price_edit" placeholder="Insert Amount"   />
				</div>
				<div class="form-group">
					<input type="submit" class="btn btn-success" value="Edit"  />
				</div>
			 </form>
		 <?php }else if(isset($_GET['referal_joining'])){?>
			 <form action="<?php $_SERVER['REQUEST_URI'];?>" method="post"  class="form-inline">
				<div class="form-group">
					<input type="text" class="form-control"   name="referal_joining_level" placeholder="Insert Level"   />
				</div>
				<div class="form-group">
					<input type="text" class="form-control"   name="referal_joining" placeholder="Insert Amount"   />
				</div>
				<div class="form-group">
					<input type="submit" class="btn btn-success" value="Edit"  />
				</div>
			 </form>
		 <?php }else if(isset($_GET['add_join_referal'])){?>
			 <form action="<?php $_SERVER['REQUEST_URI'];?>" method="post"  class="form-inline">
				<div class="form-group">
					<input type="text" class="form-control"   name="add_referal_joining_level" placeholder="Insert Level"   />
				</div>
				<div class="form-group">
					<input type="text" class="form-control"   name="add_referal_joining" placeholder="Insert Amount"   />
				</div>
				<div class="form-group">
					<input type="submit" class="btn btn-success" value="Edit"  />
				</div>
			 </form>
		 <?php }else if(isset($_GET['purchase_joining'])){?>
			 <form action="<?php $_SERVER['REQUEST_URI'];?>" method="post"  class="form-inline">
				<div class="form-group">
					<input type="text" class="form-control"   name="purchase_joining_level" placeholder="Level"   />
				</div>
				<div class="form-group">
					<input type="text" class="form-control"   name="purchase_joining" placeholder="Purchased"   />
				</div>
				<div class="form-group">
					<input type="text" class="form-control"   name="purchase_joining_non" placeholder="Non-purchased"   />
				</div>
				<div class="form-group">
					<input type="submit" class="btn btn-success" value="Edit"  />
				</div>
			 </form>
		 <?php }else if(isset($_GET['product_referal_add'])){?>
			 <form action="<?php $_SERVER['REQUEST_URI'];?>" method="post"  class="form-inline">
				<div class="form-group">
					<input type="text" class="form-control"   name="add_purchase_joining_level" placeholder="Level"   />
				</div>
				<div class="form-group">
					<input type="text" class="form-control"   name="add_purchase_joining" placeholder="Purchased"   />
				</div>
				<div class="form-group">
					<input type="text" class="form-control"   name="add_purchase_joining_non" placeholder="Non-purchased"   />
				</div>
				<div class="form-group">
					<input type="submit" class="btn btn-success" value="Add"  />
				</div>
			 </form>
		 <?php }else if(isset($_GET['desination_bonus'])){?>
			 <form action="<?php $_SERVER['REQUEST_URI'];?>" method="post"  class="form-inline">
				<div class="form-group">
					<input type="text" class="form-control"   name="desination_bonus_level_1" placeholder="Level 1"   />
				</div>
				<div class="form-group">
					<input type="text" class="form-control"   name="desination_bonus_level_2" placeholder="Level 2"   />
				</div>
				<div class="form-group">
					<input type="text" class="form-control"   name="desination_bonus_upto_6" placeholder="Upto 6"   />
				</div>
				<div class="form-group">
					<input type="text" class="form-control"   name="desination_bonus_designation" placeholder="Designation"   />
				</div>
				<div class="form-group">
					<input type="text" class="form-control"   name="desination_bonus_bonus" placeholder="Bonus"   />
				</div>
				<div class="form-group">
					<input type="submit" class="btn btn-success" value="Edit"  />
				</div>
			 </form>
		 <?php } ?>
		 <?php if(!empty($error)){
			 echo '<div class="alert alert-danger">'.$error[0].'</div>';
		 }?>
		 <br />
		<div class="panel panel-primary">
				<div class="panel-heading">
					<h4>Direct Work Income Plan</h4>
				</div>
				<div class="panel-body">
					<table class="table table-bordered table-striped">
						<tr  >
							
							<th >Daily Work Steps</th>
							<th >Point Price</th>
							<th >Daily Estimated Income</th>
							<th >Monthly Estimated Income</th>
							<th >Steps Limit</th>
						</tr>
						<tr>
							<td><?php echo $daily_work_one = get_table_data_single_row('direct_income','id','1','step');?> Steps</td>
							<td><?php echo $price_one = get_table_data_single_row('direct_income','id','1','price');?> <a class="btn btn-success btn-xs pull-right" href="income_plan.php?edit_direct_work=1">Edit</a></td>
							<td><?php echo $day_work_one = $daily_work_one * $price_one;?></td>
							<td><?php echo $month_work_one = $day_work_one * 30;?></td>
							<td>Upto <?php echo get_table_data_single_row('direct_income','id','1','min');?> - <?php echo get_table_data_single_row('direct_income','id','1','max');?> steps</td>
						</tr>
						<tr>
							<td><?php echo $daily_work_one =  get_table_data_single_row('direct_income','id','2','step');?> Steps</td>
							<td><?php echo $price_one = get_table_data_single_row('direct_income','id','2','price');?> <a class="btn btn-success btn-xs pull-right"  href="income_plan.php?edit_direct_work=2">Edit</a></td>
							<td><?php echo $day_work_one = $daily_work_one * $price_one;?></td>
							<td><?php echo $month_work_one = $day_work_one * 30;?></td>
							<td>Upto <?php echo get_table_data_single_row('direct_income','id','2','min');?> - <?php echo get_table_data_single_row('direct_income','id','2','max');?> steps</td>
						
							
						</tr>
						<tr>
							<td><?php echo $daily_work_one =  get_table_data_single_row('direct_income','id','3','step');?> Steps</td>
							<td><?php echo $price_one = get_table_data_single_row('direct_income','id','3','price');?> <a class="btn btn-success btn-xs pull-right"  href="income_plan.php?edit_direct_work=3">Edit</a></td>
							<td><?php echo $day_work_one = $daily_work_one * $price_one;?></td>
							<td><?php echo $month_work_one = $day_work_one * 30;?></td>
							
							<td>Upto <?php echo get_table_data_single_row('direct_income','id','3','min');?> - <?php echo get_table_data_single_row('direct_income','id','3','max');?> steps</td>
						
						</tr>
						<tr>
							<td><?php echo $daily_work_one =  get_table_data_single_row('direct_income','id','4','step');?> Steps</td>
							<td><?php echo $price_one = get_table_data_single_row('direct_income','id','4','price');?> <a class="btn btn-success btn-xs pull-right"  href="income_plan.php?edit_direct_work=4">Edit</a></td>
							<td><?php echo $day_work_one = $daily_work_one * $price_one;?></td>
							<td><?php echo $month_work_one = $day_work_one * 30;?></td>
							
							<td>Upto <?php echo get_table_data_single_row('direct_income','id','4','min');?> - <?php echo get_table_data_single_row('direct_income','id','4','max');?> steps</td>
						
						</tr>
						
					</table>
				</div>
			 </div>
		
		 
		 <div class="clearfix"></div>
		<div  class="col-md-6  text-center" style="text-decoration:none;">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h4>Work Referral Income Plan</h4>
				</div>
				<div class="panel-body">
					<table class="table table-bordered table-striped">
						<?php $work_levels = get_table_data_all('work_referral');
						foreach($work_levels as $work_level){
						?>
						<tr>
							<td>Level <?php echo get_table_data_single_row('work_referral','id',$work_level['id'],'level');?></td>
							<td> <a class="btn btn-danger btn-xs pull-right"  href="income_plan.php?referal_income_delete=<?php echo $work_level['id'];?>">Delete</a> <a class="btn btn-success btn-xs pull-right" style="margin-right:5px;"   href="income_plan.php?referal_income=<?php echo $work_level['id'];?>">Edit</a> <?php echo get_table_data_single_row('work_referral','id',$work_level['id'],'percent');?>% </td>
						</tr>
						<?php }?>
						
					</table>
					<a class="btn btn-success" href="income_plan.php?add_work_referal" >Add New</a>
				</div>
			 </div>
		 </div>
		<div  class="col-md-6  text-center" style="text-decoration:none;">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h4>Joining Referral Income Plan</h4>
				</div>
				<div class="panel-body">
					<table class="table table-bordered table-striped">
						
						<?php 
						$joining_levels = get_table_data_all('joining_referal');
						foreach($joining_levels as $joining_level){?>
						<tr>
							<td>Level <?php echo get_table_data_single_row('joining_referal','id',$joining_level['id'],'level');?></td>
							<td><a class="btn btn-danger btn-xs pull-right"  href="income_plan.php?referal_joining_delete=<?php echo $joining_level['id'];?>">Delete</a><a class="btn btn-success btn-xs pull-right" style="margin-right:5px;"   href="income_plan.php?referal_joining=<?php echo $joining_level['id'];?>">Edit</a> <?php echo get_table_data_single_row('joining_referal','id',$joining_level['id'],'bdt');?> BDT</td>
						</tr>
						<?php } ?>
						
						
					</table>
					<a class="btn btn-success" href="income_plan.php?add_join_referal" >Add New</a>
				</div>
			 </div>
		 </div>
		<div  class="col-md-6  text-center" style="text-decoration:none;">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h4>Product Referral</h4>
				</div>
				<div class="panel-body">
					<table class="table table-bordered table-striped">
						
						<?php 
						$product_referals = get_table_data_all('purchase_level');
						foreach($product_referals  as $product_referal){
						
						?>
						<tr>
							<td>Level <?php echo get_table_data_single_row('purchase_level','level',$product_referal['level'],'level');?></td>
							<td> <?php echo get_table_data_single_row('purchase_level','level',$product_referal['level'],'perc');?> %</td>
							<td> <?php echo get_table_data_single_row('purchase_level','level',$product_referal['level'],'perc2');?> %</td>
							<td><a class="btn btn-danger btn-xs pull-right"  href="income_plan.php?purchase_joining_delete=<?php echo $product_referal['id'];?>">Delete</a> <a class="btn btn-success btn-xs pull-right" style="margin-right:5px;"   href="income_plan.php?purchase_joining=<?php echo $product_referal['id'];?>">Edit</a></td>
						</tr>
						<?php }?>
						
					</table>
					<a class="btn btn-success" href="income_plan.php?product_referal_add">Add New</a>
				</div>
			 </div>
		 </div>
		 <div  class="col-lg-6 col-md-6 col-sm-6 col-xs-12 text-center" style="text-decoration:none;">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h4> Instant Bonus</h4>
					</div>
					<div class="panel-body">
						<table class="table table-bordered table-striped">
							<tr>
								<td><?php echo get_table_data_single_row('instant_bonus','id','1','reward')?></td>
							</tr>
							<tr>
								<td><?php echo get_table_data_single_row('instant_bonus','id','2','reward')?></td>
								
							</tr>
							<tr>
								<td><?php echo get_table_data_single_row('instant_bonus','id','3','reward')?></td>
								
							</tr>
							<tr>
								<td><?php echo get_table_data_single_row('instant_bonus','id','4','reward')?></td>
								
							</tr>
							<tr>
								<td><?php echo get_table_data_single_row('instant_bonus','id','5','reward')?></td>
								
							</tr>
							<tr>
								<td><?php echo get_table_data_single_row('instant_bonus','id','6','reward')?></td>
								
							</tr>
							
						</table>
					</div>
				</div>
    		</div>
			
		 <div class="clearfix"></div>
		 <div  class="text-center" style="text-decoration:none;">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h4>Designation Bonus</h4>
				</div>
				<div class="panel-body">
					<table class="table table-bordered table-striped">
						<tr>
							<th class="text-center">Level 1</th>
							<th class="text-center">Level 2</th>
							<th class="text-center">Upto Level 6</th>
							<th class="text-center">Designation</th>
							<th class="text-center">Bonus</th>
						</tr>
						<tr>
							<td><a class="btn btn-success btn-xs pull-left"  href="income_plan.php?desination_bonus=1">Edit</a><?php echo get_table_data_single_row('designation_bonus','id','1','level_1')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','1','level_2')?></td>
							<td>0-<?php echo get_table_data_single_row('designation_bonus','id','1','upto_6')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','1','designation')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','1','bonus')?> BDT</td>
							
						</tr>
						<tr>
							<td><a class="btn btn-success btn-xs pull-left"  href="income_plan.php?desination_bonus=2">Edit</a><?php echo get_table_data_single_row('designation_bonus','id','2','level_1')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','2','level_2')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','2','upto_6')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','2','designation')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','2','bonus')?> BDT</td>
							
						</tr>
						<tr>
							<td><a class="btn btn-success btn-xs pull-left"  href="income_plan.php?desination_bonus=3">Edit</a><?php echo get_table_data_single_row('designation_bonus','id','3','level_1')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','3','level_2')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','3','upto_6')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','3','designation')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','3','bonus')?> BDT</td>
							
						</tr>
						<tr>
							<td><a class="btn btn-success btn-xs pull-left"  href="income_plan.php?desination_bonus=4">Edit</a><?php echo get_table_data_single_row('designation_bonus','id','4','level_1')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','4','level_2')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','4','upto_6')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','4','designation')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','4','bonus')?> BDT</td>
							
						</tr>
						<tr>
							<td><a class="btn btn-success btn-xs pull-left"  href="income_plan.php?desination_bonus=5">Edit</a><?php echo get_table_data_single_row('designation_bonus','id','5','level_1')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','5','level_2')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','5','upto_6')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','5','designation')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','5','bonus')?> BDT</td>
							
						</tr>
						<tr>
							<td><a class="btn btn-success btn-xs pull-left"  href="income_plan.php?desination_bonus=6">Edit</a><?php echo get_table_data_single_row('designation_bonus','id','6','level_1')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','6','level_2')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','6','upto_6')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','6','designation')?></td>
							<td><?php echo get_table_data_single_row('designation_bonus','id','6','bonus')?> BDT</td>
							
						</tr>
						
					</table>
				</div>
			 </div>
		 </div>
		 <div class="clearfix"></div>
		 <div  class="text-center" style="text-decoration:none;">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h4> Instant Bonue</h4>
				</div>
				<div class="panel-body">
					<div  class="col-md-4  text-center" style="text-decoration:none;">
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4>Big Bonus</h4>
							</div>
							<div class="panel-body">
								<table class="table table-bordered table-striped">
									<tr>
										<td>Level 1</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','1','level_1');?> Members</td>
									</tr>
									<tr>
										<td>Level 2</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','1','level_2');?> Members</td>
									</tr>
									<tr>
										<td>Duration</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','1','duration');?> Days</td>
									</tr>
									<tr>
										<td>Reward</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','1','reward')?></td>
									</tr>
									
									
								</table>
							</div>
						 </div>
					 </div>
					 <div  class="col-md-4  text-center" style="text-decoration:none;">
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4>Lead Bonus</h4>
							</div>
							<div class="panel-body">
								<table class="table table-bordered table-striped">
									<tr>
										<td>Level 1</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','2','level_1');?> Members</td>
									</tr>
									<tr>
										<td>Level 2</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','2','level_2');?> Members</td>
									</tr>
									<tr>
										<td>Duration</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','2','duration');?> Days</td>
									</tr>
									<tr>
										<td>Reward</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','2','reward')?></td>
									</tr>
									
								</table>
							</div>
						 </div>
					 </div>
					 <div  class="col-md-4  text-center" style="text-decoration:none;">
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4>Cap Bonus</h4>
							</div>
							<div class="panel-body">
								<table class="table table-bordered table-striped">
									
									<tr>
										<td>Level 1</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','3','level_1');?> Members</td>
									</tr>
									<tr>
										<td>Level 2</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','3','level_2');?> Members</td>
									</tr>
									<tr>
										<td>Duration</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','3','duration');?> Days</td>
									</tr>
									<tr>
										<td>Reward</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','3','reward')?></td>
									</tr>
								</table>
							</div>
						 </div>
					 </div>
				</div>
			 </div>
		 </div>
		 <div class="clearfix"></div>
		 <div  class="text-center" style="text-decoration:none;">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<h4> Instant Bonue #2</h4>
				</div>
				<div class="panel-body">
					<div  class="col-md-4  text-center" style="text-decoration:none;">
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4>Big Bonus</h4>
							</div>
							<div class="panel-body">
								<table class="table table-bordered table-striped">
									
									<tr>
										<td>Level 1</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','4','level_1');?> Members</td>
									</tr>
									<tr>
										<td>Level 2</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','4','level_2');?> Members</td>
									</tr>
									<tr>
										<td>Upto Level 6</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','4','upto_6');?> Members</td>
									</tr>
									<tr>
										<td>Duration</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','4','duration');?> Days</td>
									</tr>
									<tr>
										<td>Reward</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','4','reward')?></td>
									</tr>
									
								</table>
							</div>
						 </div>
					 </div>
					 <div  class="col-md-4  text-center" style="text-decoration:none;">
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4>Lead Bonus</h4>
							</div>
							<div class="panel-body">
								<table class="table table-bordered table-striped">
									<tr>
										<td>Level 1</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','5','level_1');?> Members</td>
									</tr>
									<tr>
										<td>Level 2</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','5','level_2');?> Members</td>
									</tr>
									<tr>
										<td>Upto Level 6</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','5','upto_6');?> Members</td>
									</tr>
									<tr>
										<td>Duration</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','5','duration');?> Days</td>
									</tr>
									<tr>
										<td>Reward</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','5','reward')?></td>
									</tr>
									
								</table>
							</div>
						 </div>
					 </div>
					 <div  class="col-md-4  text-center" style="text-decoration:none;">
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4> Cap Bonus</h4>
							</div>
							<div class="panel-body">
								<table class="table table-bordered table-striped">
									
									<tr>
										<td>Level 1</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','6','level_1');?> Members</td>
									</tr>
									<tr>
										<td>Level 2</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','6','level_2');?> Members</td>
									</tr>
									<tr>
										<td>Upto Level 6</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','6','upto_6');?> Members</td>
									</tr>
									<tr>
										<td>Duration</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','6','duration');?> Days</td>
									</tr>
									<tr>
										<td>Reward</td>
										<td><?php echo get_table_data_single_row('instant_bonus','id','6','reward')?></td>
									</tr>
								
								</table>
							</div>
						 </div>
					 </div>
				</div>
			 </div>
		 </div>
		 
		 
	</div>
	
<?php
  include 'include/footer.php';
?>