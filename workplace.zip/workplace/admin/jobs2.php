<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
  if(loggedin() == false){
	  header("Location:login.php");
  }

  if(checkaccess($_SESSION['flc_admin'], 'jobs2.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
//DELETE FROM `jobs2` WHERE `id` > '100'
 error_reporting(0);
//print_r($_SESSION);

$error = array();
	if(isset($_POST['type'])){
		
		$id = sanetize($_GET['edit']);
		$type = sanetize($_POST['type']);
		$link = sanetize($_POST['image']);
		$script = sanetize($_POST['script']);
		
		if($type == 0){
			
			
			$file_name = $_FILES['file']['name'];
			$file_tmp = $_FILES['file']['tmp_name'];
			$rand = rand(10000,90000);
			$new_file_name = $rand.$file_name;
			move_uploaded_file($file_tmp, '../images/job/'.$new_file_name);
			$sql = mysqli_query($db, "UPDATE `jobs` SET `link` = '$link',`image` = '$new_file_name',`type` = '$type' WHERE `id` = '$id'");
			header('Location:jobs.php');
		}else if($type == 1){
			$script = urlencode($_POST['script']);
			$sql = mysqli_query($db, "UPDATE `jobs` SET `script` = '$script',`type` = '$type' WHERE `id` = '$id'");
			header('Location:jobs.php');
		}
	}
?>
	
	<div class="container col-md-10 col-sm-10"  >
		<?php if(isset($_GET['edit'])){?>
			<div class="panel panel-default">
			<div class="panel-body">
				<form action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post" enctype="multipart/form-data" >
					<div class="form-group">
						<select name="type" id="" class="form-control">
							<?php 
							$type = get_table_data_single_row('jobs','id',$_GET['edit'],'type');
							if($type == '1'){
								echo '
								<option value="1" >Script</option>
								<option value="0" >Link</option>
								';
							}else if($type == '0'){
								echo '
								<option value="0" >Link</option>
								<option value="1" >Script</option>
								';
							}else if($type == ''){
								echo '
								<option value="0" >Link</option>
								<option value="1" >Script</option>
								';
							}?>
							
						</select>
					</div>								
					<div class="form-group">
						<input type="text" <?php echo 'value="'.get_table_data_single_row('jobs','id',$_GET['edit'],'script').'"';?> name="script" class="form-control"  placeholder="Insert Script" />
					</div>								
					<div class="form-group">
						<input type="text" <?php echo 'value="'.get_table_data_single_row('jobs','id',$_GET['edit'],'image').'"';?> name="image" class="form-control"  placeholder="Insert Link" />
					</div>
					<div class="form-group">
						<input type="file"  name="file"   id="add_image_one"  />
					</div>
					<?php if(!empty($error)){
						echo '<div class="alert alert-danger">'.$error[0].'</div>';
					}?>
					<div class="form-group">
						<input type="submit" class="btn btn-success"  value="SUBMIT"  />
					</div>
				</form>
			</div>
		</div>
		<?php }?>
		<div class="panel panel-default">
			<div class="panel-body">
				<div class="table-responsive">
					<table class="table table-bordered table-striped">
						<tr>
							<th>Action</th>
							<th>type</th>
							<th>Link</th>
							<th>Image</th>
							<th>Script</th>
							
							
						</tr>
						<?php 
						$sql = get_table_data_specific('jobs','jobid',sanetize($_GET['view']));
						if($sql->num_rows == 0){
							$count = 0;
							$jobs = 1;
							while($count == 0){
								if($jobs == 121){
									$count = 1;
								}else{
									$insert  = mysqli_query($db, "INSERT INTO `jobs` 
									(`jobid`,`serial`)
									VALUES
									('".$_GET['view']."','$jobs')
									");
									$jobs++;
								}
							}
						}
						if(!isset($_GET['list'])){
						$sl = 1;
						foreach(get_table_data_specific('jobs','jobid',sanetize($_GET['view'])) as $jobs){
							if($sl < 11){
							?>
							<tr>
								<td>
									<a href="jobs2.php?edit=<?php echo $jobs['id']?>" class="btn btn-info btn-xs">Edit</a>
								</td>
								<td><?php  if($jobs['type'] == '0'){echo 'link';}else if($jobs['type'] == '1'){echo 'Script';}?></td>
								<td><?php echo $jobs['link'];?></td>
								<td><?php echo $jobs['image'];?></td>
								<td><?php echo $jobs['script'];?></td>
							</tr>
							<?php }
							$sl++;
						}}else{
							foreach(paginationed_job_details(sanetize($_GET['list']),sanetize($_GET['view'])) as $jobs){
							
							?>
							<tr>
								<td class="form-inline" style="width:50px;" >
									<a href="jobs2.php?edit=<?php echo $jobs['id']?>" class="btn btn-info btn-xs">Edit</a>
								</td>
								<td><?php  if($jobs['type'] == '0'){echo 'link';}else if($jobs['type'] == '1'){echo 'Script';}?></td>
								<td><?php echo $jobs['link'];?></td>
								<td><?php echo $jobs['image'];?></td>
								<td><?php echo $jobs['script'];?></td>
								
							</tr>
							<?php }
						}?>
					</table>
				</div>
				<div class="pagination">
					  <?php 
					  $count = 0;
					  
					  $rows = pagination_list_job_details($_GET['view']);
					  if($rows > 1){
						for($count = 0; $count < $rows; $count++ ){?>
						<li><a class="table_pagination_links <?php if($_GET['list'] == $count){echo 'active';}?>" <?php if($count  > ($_GET['list'] + 4)){echo 'style="display:none;"';}else if($count  < ($_GET['list'] - 4)){echo 'style="display:none;"';}?>  href="jobs2.php?view=<?php echo $_GET['view']?>&list=<?php echo $count;?>"><?php echo $count+1;?></a></li>
					  <?php }}?>
				</div>
			</div>
		</div>
	</div>
<?php
  include 'include/footer.php';
?>