$(document).ready(function(){
	$('#datepicker').datepicker({dateFormat:"yy-mm-dd",});
	$('#datepicker2').datepicker({dateFormat:"yy-mm-dd",});
	$('#datepicker3').datepicker({dateFormat:"yy-mm-dd",});
	$('#datepicker4').datepicker({dateFormat:"yy-mm-dd",});
	$('#datepicker5').datepicker({dateFormat:"yy-mm-dd",});
	$('#datepicker7').datepicker({dateFormat:"yy-mm-dd",});
	$('#datepicker8').datepicker({dateFormat:"yy-mm-dd",});
	$('#datepicker9').datepicker({dateFormat:"yy-mm-dd",});
	$("#register_form").submit(function(e) {

		var url = "include/register.php"; // the script where you handle the form input.

		$.ajax({
			   type: "POST",
			   url: url,
			   data: $("#register_form").serialize(), // serializes the form's elements.
			   success: function(data)
			   {
				  
				var response = JSON.parse(data);
				
				if(response.success == 1){
					$('#register_form_error').html('<div class="alert alert-success animated fadeIn">Successfully Registered </div>');
					window.setTimeout(function(){
						// Move to a new location or you can do something else
						window.location.href = "index.php";
					}, 3000);
				}else{
					$('#register_form_error').html('<div class="alert alert-danger animated fadeIn">'+response.message+'</div>');
				}
			   }
			 });
		e.preventDefault(); // avoid to execute the actual submit of the form.
	});
	$("#login_form").submit(function(e) {

		var url = "include/login.php"; // the script where you handle the form input.

		$.ajax({
			   type: "POST",
			   url: url,
			   data: $("#login_form").serialize(), // serializes the form's elements.
			   success: function(data)
			   {
				  
				var response = JSON.parse(data);
				
				if(response.success == 1){
					$('#login_form_error').html('<div class="alert alert-success animated fadeIn">Redirecting Please Wait...</div>');
					window.setTimeout(function(){
						// Move to a new location or you can do something else
						window.location.href = "login.php";
					}, 3000);
				}else{
					$('#login_form_error').html('<div class="alert alert-danger animated fadeIn">'+response.message+'</div>');
				}
			   }
			 });
		e.preventDefault(); // avoid to execute the actual submit of the form.
	});
	$("#otp_form").submit(function(e) {

		var url = "include/login.php"; // the script where you handle the form input.

		$.ajax({
			   type: "POST",
			   url: url,
			   data: $("#otp_form").serialize(), // serializes the form's elements.
			   success: function(data)
			   {
				  
				var response = JSON.parse(data);
				
				if(response.success == 1){
					$('#otp_form_error').html('<div class="alert alert-success animated fadeIn">Redirecting to Dashboard</div>');
					window.setTimeout(function(){
						// Move to a new location or you can do something else
						window.location.href = "index.php";
					}, 3000);
				}else{
					$('#otp_form_error').html('<div class="alert alert-danger animated fadeIn">'+response.message+'</div>');
				}
			   }
			 });
		e.preventDefault(); // avoid to execute the actual submit of the form.
	});
	$("#profile_update_form").submit(function(e) {

		var url = "include/profile.php"; // the script where you handle the form input.

		$.ajax({
			   type: "POST",
			   url: url,
			   data: $("#profile_update_form").serialize(), // serializes the form's elements.
			   success: function(data)
			   {
				//alert(data); 
				var response = JSON.parse(data);
				
				if(response.success == 1){
					$('#profile_update_form_error').html('<div class="alert alert-success animated fadeIn">Profile Successfully Updated</div>');
					window.setTimeout(function(){
						// Move to a new location or you can do something else
						window.location.href = "profile.php";
					}, 3000);
				}else{
					$('#profile_update_form_error').html('<div class="alert alert-danger animated fadeIn">'+response.message+'</div>');
				}
			   }
			 });
		e.preventDefault(); // avoid to execute the actual submit of the form.
	});
	$('.jobs').click(function(){
		var num = $(this).attr('rev');
		var next = +num + +1;
		var task_status = $('#task_status').val();
		
		if(next == 4){
			
			var next_2 = +next + +3;
			window.setTimeout(function(){
				$('.jobs').addClass('gl423569');
				$('.jobs_'+next_2).removeClass('gl423569');			
			}, 1000);
		}else{
			if(next == 17){
				//alert(next);
				$.post('include/custom.php',{job_locator : next});
			}
			if(next == 18){
				//alert(task_status);
				$.post('include/custom.php',{job_locators : task_status});
			}
			window.setTimeout(function(){
				$('.jobs').addClass('gl423569');
				$('.jobs_'+next).removeClass('gl423569');			
			}, 1000);
		}
		
	});
	
	

	
	$('#prev_btn').click(function(){
		$('#next_btn').removeAttr('disabled');
		$('#next_btn').removeClass('clickdisable');
		var first = $('.showns').first().attr('value');
		var first_one = $('.datas').first().attr('value');
		var prev_one = first;
		var prev_ten = first - 10;
		$('.datas').addClass('hiddens');
		$('.datas').removeClass('showns');
		
		while(prev_one > prev_ten){
			var this_one = $('.sl_' + prev_ten).attr('value');
			if(this_one == first_one){
				
				$('#prev_btn').attr('disabled','disabled');
				$('#prev_btn').addClass('clickdisable');
			}
			$('.sl_' + prev_ten).removeClass('hiddens');
			$('.sl_' + prev_ten).addClass('showns');
			prev_ten++ 	
		}
		
		
	});
	
	$('#next_btn').click(function(){
		$('#prev_btn').removeAttr('disabled');
		$('#prev_btn').removeClass('clickdisable');
		var last_value = $('.showns').last().attr('value');
		var last_one = $('.datas').last().attr('value');
		
		var next_one = +last_value + +1;
		var next_ten = +last_value + +11;
		$('.datas').addClass('hiddens');
		$('.datas').removeClass('showns');
		
		while(next_one < next_ten){
			var this_one = $('.sl_' + next_one).attr('value');
			if(this_one == last_one){
				
				$('#next_btn').attr('disabled','disabled');
				$('#next_btn').addClass('clickdisable');
			}
			$('.sl_' + next_one).removeClass('hiddens');
			$('.sl_' + next_one).addClass('showns');
			next_one++;	
		}
		
		
	});
	$('.checked_for_aproval').click(function(){
		var value = $(this).val();
		$.post('include/custom.php',{page_session : value});
	});
	$('.select_all_aproval').click(function(){
		var all_select = 1;
		$.post('include/custom.php',{select_all : all_select});
		$('.checked_for_aproval').attr('checked','checked');
	});
	$('.select_all_aproval_two').click(function(){
		var all_select = 1;
		$.post('include/custom.php',{select_all_two : all_select});
		$('.checked_for_aproval').attr('checked','checked');
	});
	$('.take_accept_id').click(function(){
	   var value = $(this).attr('rev');
	   alert(value);
	   $('#accept_confirm').attr('href','?accept='+value);
	});
	
	$('.take_cancel_id').click(function(){
	   var value = $(this).attr('rev');
	   alert(value);
	   $('#accept_confirm').attr('href','?accept='+value);
	});
	
	$('.withdraw_take_accept_id').click(function(){
	   var id = $(this).attr('rev');
	   var trxid = $('#trxid_'+id).val();
	   $('#withdraw_id').val(id);
	   $('#withdraw_trxid').val(trxid);
	});
});
