<?php
include 'include/head.php';

include 'include/header.php';
include 'include/nav.php';
  if(loggedin() == false){
	  header("Location:login.php");
  }
 
if(checkaccess($_SESSION['flc_admin'], 'subadmin.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
function getalllist(){
	global $db;
	$sql = mysqli_query($db, "SELECT * FROM `admin`");
	$data = mysqli_fetch_field($sql);
	$names = array();
	while($name = mysqli_fetch_field($sql)){
	 $names[] = $name->name;
	}
	return $names;
}
if(isset($_GET['delete'])){
    $id = sanetize($_GET['delete']);
    $sql = mysqli_query($db, "DELETE FROM `admin` WHERE `id` = '$id'");
    if($sql == true){
        header('Location:subadmin.php');
    }
}
function adminlist(){
	global $db;
	$sql = mysqli_query($db, "SELECT * FROM `admin`");
	return $sql;
}
include 'include/createsubadmin.php';
$postvalue = array();
if(isset($_POST['number'])){
	$number = $_POST['number'];
	$password = $_POST['password'];
	$passhash = md5(sha1(md5($password)));
//	
	echo get_table_data_specific('admin','number',$number)->num_rows;
	if(get_table_data_specific('admin','number',$number)->num_rows == 0){
	    foreach($_POST as $value){
    			$postvalue[] = $value;
    	}
    	//print_r($postvalue);
    	$sql = mysqli_query($db, "INSERT INTO `admin` (`number`,`password`)VALUES('$number','$passhash')");
    	if($sql == true){
    		foreach($postvalue as $page){
    			$sql2 = mysqli_query($db, "UPDATE `admin` SET `".$page."` = '1' WHERE `number` = '$number' AND `password` = '$passhash'");
    			
    		}
    		echo '<script type="text/javascript">alert("Account created")</script>';
    	}else{
    	    echo mysqli_error($db);
    	}
	}else{
	    echo '<script type="text/javascript">alert("Number already Exists")</script>';
	}
}
?>
<div id="content" class="content-adjusted col-md-9" >
	<div class="row">
		<div class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-heading">
				</div>
				<div class="panel-body">
					
					<div class="table-responsive overflowclass">
						<form action="subadmin.php" method="post" >
							<div class="col-md-12">
								<div class="col-md-3">Number</div>
								<div class="col-md-3"><input type="text" name="number" class="form-control"/></div>
								<div class="col-md-3">Password</div>
								<div class="col-md-3"><input type="text" name="password" class="form-control"/></div>
							</div>
							<br />
							<br />
							<div class="col-md-12">
							<ul>
									<?php foreach(getalllist() as $value){
										if($value !== 'account' && $value !== 'password' && $value !== 'number' ){
										?>
										
										<li class="col-md-4 creatsubadminlist" >
										    <input id="<?php echo $value;?>" type="checkbox" name="<?php echo $value;?>" value="<?php echo $value;?>" /> &nbsp;
										    <label for="<?php echo $value;?>"><?php echo $value;?></label> 
										</li>
									
									<?php }}?>
									</ul>	
								<br />
								<br />
								
								<div class="col-md-12">
									<div class="col-md-3">
										<input type="submit" class="btn btn-success form-control" value="Create Subadmin"/>
									</div>
								</div>
							</div>
							<br />
							<br />
						
								
					
						</form>
					</div>
					<br />
					<br />
				   <div class="table-responsive">
									
									<table class="table table-striped table-bordered" >
									    <tr>
									        <th>Number</th>
									        <th>Action</th>
									    </tr>
									   <?php foreach(get_table_data_all('admin') as $admins){ 
									   if($admins['id'] !== '1'){
									   ?>
									     <tr>
									        <td><?php echo $admins['number']?></td>
									        <td><a href="subadmin.php?delete=<?php echo $admins['id']?>" >Remove</a></td>
									    </tr>
									   <?php }}?>
									</table>
									
								</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
include 'include/footer.php';
?>