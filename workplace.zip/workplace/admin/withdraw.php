<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
  if(loggedin() == false){
	  header("Location:login.php");
  }
 //error_reporting(0);
 $search = null;
if(isset($_POST['withdraw_id'])){
	$id = sanetize($_POST['withdraw_id']);
	$trxid = sanetize($_POST['withdraw_trxid']);
	$uid = get_table_data_single_row('withdraw','id',$id,'uid');
	$number = get_table_data_single_row('flc_users','id',$uid,'number');
	$amount = get_table_data_single_row('withdraw','id',$id,'amount');
	$charge = ($amount / 100) *  get_table_data_single_row('dynamics','content','withdraw_charge','value');
    $amount_without_charge = $amount - $charge;
    $provident = ($amount / 100) * get_table_data_single_row('dynamics','content','provident_fund','value');
    $amount_without_prfund = $amount_without_charge - $provident;
     					
	if(!empty($trxid)){
		$update  = mysqli_query($db, "UPDATE `withdraw` SET `trxid` = '$trxid', `status` = '1',`rec_amount` = '$amount_without_prfund',`charge` = '$charge',`provident` = '$provident',`adminid`= '".$_SESSION['flc_admin']."' WHERE `id` = '$id'");
		sendsms($number,'Dear SELF EMPLOYMENTS  user, Your have salary '.$amount_without_prfund.'TK as your withdrawal  request. continue your job and earn unlimited');
		header('Location:'.$_SERVER['REQUEST_URI']);
	}else{
		$error[] = 'Transection ID required';
	}
	
}
if(isset($_GET['cancel'])){
	$id = sanetize($_GET['cancel']);
	$uid = get_table_data_single_row('withdraw','id',$id,'uid');
	$number = get_table_data_single_row('flc_users','id',$uid,'number');
	$balance = get_table_data_single_row('flc_users','id',$uid,'balance');
	$amount = get_table_data_single_row('withdraw','id',$id,'amount');
	$new_balance = $balance + $amount;
	$sql = mysqli_query($db, "UPDATE `flc_users` SET `balance` = '$new_balance' WHERE `id` = '$uid'");
	accounts_update($uid,$amount,'Withdraw request canceled and refunded on balance',$balance,$new_balance,'cr');
	$update  = mysqli_query($db, "UPDATE `withdraw` SET `status` = '2',`adminid` = '".$_SESSION['flc_admin']."' WHERE `id` = '$id'");
	sendsms($number,'Dear  user, Your withdraw request canceled and refunded');
	header('Location:withdraw.php');
}
if(isset($_POST['name_search'])){
	$name = sanetize($_POST['name_search']);
	$sql = mysqli_query($db, "SELECT `id` FROM `flc_users` WHERE `username` LIKE '%".$name."%'");
	$search = array();
	foreach($sql as $ids){
		$sql2 = mysqli_query($db, "SELECT * FROM `withdraw` WHERE `uid` = '".$ids['id']."'");
		if($sql2->num_rows !== 0){
			foreach($sql2 as $sqls){
				array_push($search,$sqls);
			}
		}
	}
	
}
if(isset($_POST['number_search'])){
	$name = sanetize($_POST['number_search']);
	$sql = mysqli_query($db, "SELECT `id` FROM `flc_users` WHERE `number` LIKE '%".$name."%'");
	$search = array();
	foreach($sql as $ids){
		$sql2 = mysqli_query($db, "SELECT * FROM `withdraw` WHERE `uid` = '".$ids['id']."'");
		if($sql2->num_rows !== 0){
			foreach($sql2 as $sqls){
				array_push($search,$sqls);
			}
		}
	}
	
}
if(isset($_POST['refid_search'])){
	$refid = sanetize($_POST['refid_search']);
	$id = $refid - 112233;
	$sql = mysqli_query($db, "SELECT `id` FROM `flc_users` WHERE `id` = '$id'");
	$search = array();
	foreach($sql as $ids){
		$sql2 = mysqli_query($db, "SELECT * FROM `withdraw` WHERE `uid` = '".$ids['id']."'");
		if($sql2->num_rows !== 0){
			foreach($sql2 as $sqls){
				array_push($search,$sqls);
			}
		}
	}
	
}
if(isset($_POST['account_search'])){
	$number = sanetize($_POST['account_search']);
	
	$sql  = mysqli_query($db, "SELECT * FROM `withdraw` WHERE `receiver` = '$number'");
	$sql2  = mysqli_query($db, "SELECT * FROM `withdraw` WHERE `acc_number` = '$number'");
	$search = array();
	if($sql->num_rows !== 0){
		foreach($sql as $sqls){
			 array_push($search,$sqls);
			
		}
	}
	if($sql2->num_rows !== 0){
		foreach($sql2 as $sql2s){
			 array_push($search,$sql2s);
		}
	}
}
if(isset($_POST['amount_search'])){
	$amount = sanetize($_POST['amount_search']);
	$search = mysqli_query($db, "SELECT * FROM `withdraw` WHERE `amount` = '$amount'");
}
if(isset($_POST['date_search_from'])){
	$from = sanetize($_POST['date_search_from']);
	$to = sanetize($_POST['date_search_to']);
	$search = mysqli_query($db, "SELECT * FROM `withdraw` WHERE `date` BETWEEN '$from' AND '$to'");
}

?>
	<div class="modal fade" id="acceptModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="myModalLabel">Confirm Request</h4>
          </div>
          <div class="modal-body">
              <p>Are you sure, you want to accept? </p>
            <form action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post" >
                <input type="text" name="withdraw_trxid" class="form-control"  id="withdraw_trxid"   />
                <input type="hidden" name="withdraw_id" id="withdraw_id"  />
                <input type="submit" value="Yes" class="btn btn-success"   />
                <a href="withdraw.php" class="btn btn-danger"  >No</a>
            </form>
            
          </div>
          <div class="modal-footer">
            
           
          </div>
        </div>
      </div>
    </div>
	<div class="container col-md-10 col-sm-10"  >
		 
		 <div href="#" class="" style="text-decoration:none;">
			<?php if(!empty($search)){?>
			<div class="panel panel-default ">
				<div class="panel-body table-responsive">
					<table class="table table-bordered table-striped">
						<tr class="text-nowrap" >
							<th>Action</th>
							<th>User-Name</th>
							<th>User-Number</th>
							<th>Referer-Number</th>
							<th>ReferID</th>
							<th>Payment Method</th>
							<th>Account Number</th>
							<th>Amount</th>
							<th>Charge</th>
							<th>Providend Fund</th>
							<th>You Will Send</th>
							<th>Transection ID</th>
							<th>Date</th>
							<th>Time</th>
							<th>Bank Name</th>
							<th>Branch Name</th>
							<th>Account Name</th>
							<th>Account Number</th>
							<th>Accepted BY</th>
							
						</tr>
						<?php 
						
						foreach($search as $users){
						$charge  = 0;
						$provident = 0;
						?>
							<tr>
								<td class="text-nowrap">
									<?php if($users['status'] == '1'){
										echo 'Accepted';
									}else if($users['status'] == '2'){
										echo 'Canceled';
									}else if($users['status'] == '0'){?>
										<input type="text" class="form-control"  id="trxid_<?php echo $users['id'];?>" placeholder="Insert Transection ID"  />
										<div class="btn btn-success withdraw_take_accept_id" data-toggle="modal" data-target="#acceptModal" rev="<?php echo $users['id'];?>"   >Accept</div>
										<a class="btn btn-danger btn-sm" href="withdraw.php?cancel=<?php echo  $users['id'];?>">Cancel</a>
									<?php }?>
								</td>
								<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'username');?></td>
								<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'number');?></td>
								<td><?php echo get_table_data_single_row('flc_users','id',get_table_data_single_row('flc_users','id',$users['uid'],'ref'),'number');?></td>
								<td><?php echo $users['id'] + 112233;?></td>
								<td><?php echo $users['method']?></td>
								<td><?php echo $users['receiver']?></td>
								<td><?php echo $users['amount']?></td>
								<td>
								    <?php if($users['charge'] == '0.00' ||  $users['charge'] == ''){ 
									    $charge = ($users['amount'] / 100) * get_table_data_single_row('dynamics','content','withdraw_charge','value');
									    echo $charge;
									}else{echo $users['charge'];}?>
								</td>
							    <td>
							        <?php if($users['provident'] == '0.00' || $users['provident'] == ''){ 
									    echo $provident = ($users['amount'] / 100) * get_table_data_single_row('dynamics','content','provident_fund','value');
									
									}else{echo $users['provident'];}?>
								</td>
								<td>
								    <?php if($users['rec_amount'] == '0.00' || $users['rec_amount'] == ''){ 
									    echo $rec_amount = $users['amount'] - ($charge + $provident);
									}else{echo $users['rec_amount'];}?>
								</td>
								<td><?php echo $users['trxid']?></td>
								<td><?php echo $users['date']?></td>
								<td><?php echo $users['time']?></td>
								<td><?php echo $users['bank_name']?></td>
								<td><?php echo $users['branch_name']?></td>
								<td><?php echo $users['acc_name']?></td>
								<td><?php echo $users['acc_number']?></td>
								<td><?php echo get_table_data_single_row('admin','id',$users['adminid'],'number')?></td>
								
							</tr>
						<?php  
						    }?>
						</table>
					</div>
				</div>
			</div>
			<?php }?>
			
			<div class="panel panel-default">
				<div class="panel-heading">
					<h4>Withdraw Requests</h4>
				</div>
				
				
				<span  ><?php if(!empty($error)){echo '<div class="alert alert-danger">'.$error[0].'</div> ';}?></span>
										
				<div class="panel-body table-responsive">
					<div class="form-group form-inline">
						<form class="pull-left" action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post"   >
							<input type="text" class="form-control"  name="name_search" placeholder="Search Name"  />
							<input type="submit" class="btn btn-success" value="&#128269;" />
						</form>
						<form class="pull-left" action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post"   >
							<input type="text" class="form-control"  name="number_search" placeholder="Search Mobile"  />
							<input type="submit" class="btn btn-success" value="&#128269;" />
						</form>
						<form class="pull-left" action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post"   >
							<input type="text" class="form-control"  name="refid_search" placeholder="Search Refer ID"  />
							<input type="submit" class="btn btn-success" value="&#128269;" />
						</form>
						<form class="pull-left" action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post"   >
							<input type="text" class="form-control"  name="account_search" placeholder="Account Number"  />
							<input type="submit" class="btn btn-success" value="&#128269;" />
						</form>
						<form class="pull-left" action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post"   >
							<input type="text" class="form-control"  name="amount_search" placeholder="Withdraw Amount"  />
							<input type="submit" class="btn btn-success" value="&#128269;" />
						</form>
						<form class="pull-left" action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post"   >
							<input type="text" class="form-control"  name="date_search_from" id="datepicker2" placeholder="From Date"  />
							<input type="text" class="form-control"  name="date_search_to" id="datepicker3"  placeholder="To Date"  />
							<input type="submit" class="btn btn-success" value="&#128269;" />
						</form>
					</div>
					<br />
					<br />
					<br />
					<form class="form-inline" method="get" action="withdraw_print.php"   >
					    <input type="text" class="form-control"  name="print_search_from" id="datepicker4" placeholder="From Date"  />
						<input type="text" class="form-control"  name="print_search_to" id="datepicker5"  placeholder="To Date"  />
						<select class="form-control" name="print_search_method"  >
						    <option value="bkash" >Bkash</option>
						    <option value="bank" >Bank</option>
						</select>
						<input type="submit" class="btn btn-success" value="Print" />
					</form>
					<br />
					<br />
					<table class="table table-bordered table-striped">
						<tr class="text-nowrap" >
							<th>Action</th>
							<th>User-Name</th>
							<th>User-Number</th>
							<th>Referer-Number</th>
							<th>ReferID</th>
							<th>Payment Method</th>
							<th>Account Number</th>
							<th>Amount</th>
							<th>Charge</th>
							<th>Providend Fund</th>
							<th>You Will Send</th>
							<th>Transection ID</th>
							<th>Date</th>
							<th>Time</th>
							<th>Bank Name</th>
							<th>Branch Name</th>
							<th>Account Name</th>
							<th>Account Number</th>
							<th>Accepted BY</th>
							
						</tr>
						<?php 
						if(!isset($_GET['list'])){
						foreach(get_ten_data('withdraw') as $users){
						$charge  = 0;
						$provident = 0;
						?>
							<tr>
								<td class="text-nowrap">
									<?php if($users['status'] == '1'){
										echo 'Accepted';
									}else if($users['status'] == '2'){
										echo 'Canceled';
									}else if($users['status'] == '0'){?>
										
										<input type="text" class="form-control" id="trxid_<?php echo $users['id'];?>" placeholder="Insert Transection ID"  />
										<div class="btn btn-success withdraw_take_accept_id" data-toggle="modal" data-target="#acceptModal" rev="<?php echo $users['id'];?>"   >Accept</div>
										<a class="btn btn-danger btn-sm" href="withdraw.php?cancel=<?php echo  $users['id'];?>">Cancel</a>
										<?php }?>
								</td>
								<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'username');?></td>
								<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'number');?></td>
								<td><?php echo get_table_data_single_row('flc_users','id',get_table_data_single_row('flc_users','id',$users['uid'],'ref'),'number');?></td>
								<td><?php echo $users['id'] + 112233;?></td>
								<td><?php echo $users['method']?></td>
								<td><?php echo $users['receiver']?></td>
								<td><?php echo $users['amount']?></td>
								<td>
								    <?php if($users['charge'] == '0.00' ||  $users['charge'] == ''){ 
									    $charge = ($users['amount'] / 100) * get_table_data_single_row('dynamics','content','withdraw_charge','value');
									    echo $charge;
									}else{echo $users['charge'];}?>
								</td>
							    <td>
							        <?php if($users['provident'] == '0.00' || $users['provident'] == ''){ 
									    echo $provident = ($users['amount'] / 100) * get_table_data_single_row('dynamics','content','provident_fund','value');
									
									}else{echo $users['provident'];}?>
								</td>
								<td>
								    <?php if($users['rec_amount'] == '0.00' || $users['rec_amount'] == ''){ 
									    echo $rec_amount = $users['amount'] - ($charge + $provident);
									}else{echo $users['rec_amount'];}?>
								</td>
								<td><?php echo $users['trxid']?></td>
								<td><?php echo $users['date']?></td>
								<td><?php echo $users['time']?></td>
								<td><?php echo $users['bank_name']?></td>
								<td><?php echo $users['branch_name']?></td>
								<td><?php echo $users['acc_name']?></td>
								<td><?php echo $users['acc_number']?></td>
								<td><?php echo get_table_data_single_row('admin','id',$users['adminid'],'number')?></td>
								
							</tr>
						<?php  
						    }
						}else{
							foreach(paginationed($_GET['list'],'withdraw') as $users){
							?>
							<tr>
								<td class="text-nowrap">
									<?php if($users['status'] == '1'){
										echo 'Accepted';
									}else if($users['status'] == '2'){
										echo 'Canceled';
									}else if($users['status'] == '0'){?>
									
									<input type="text" class="form-control" id="trxid_<?php echo $users['id'];?>" placeholder="Insert Transection ID"  />
										<div class="btn btn-success withdraw_take_accept_id" data-toggle="modal" data-target="#acceptModal" rev="<?php echo $users['id'];?>"   >Accept</div>
										<a class="btn btn-danger btn-sm" href="withdraw.php?cancel=<?php echo  $users['id'];?>">Cancel</a>
									<!--<div class="dropdown">
										  <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
											Action
											<span class="caret"></span>
										  </button>
											<ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
												<li><a href="withdraw.php?accept=<?php echo $users['id'];?>">Accept </a></li>
												<li><a href="withdraw.php?cancel=<?php echo $users['id'];?>">Cancel</a></li>
											</ul>
										</div>-->
									<?php }?>
								</td>
								<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'username');?></td>
								<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'number');?></td>
								<td><?php echo get_table_data_single_row('flc_users','id',get_table_data_single_row('flc_users','id',$users['uid'],'ref'),'number');?></td>
								<td><?php echo $users['id'] + 112233;?></td>
								
								<td><?php echo $users['method']?></td>
								<td><?php echo $users['receiver']?></td>
								<td><?php echo $users['amount']?></td>
								<td>
								    <?php if($users['charge'] == '0.00' ||  $users['charge'] == ''){ 
									    $charge = ($users['amount'] / 100) * get_table_data_single_row('dynamics','content','withdraw_charge','value');
									    echo $charge;
									}else{echo $users['charge'];}?>
								</td>
							    <td>
							        <?php if($users['provident'] == '0.00' || $users['provident'] == ''){ 
									    echo $provident = ($users['amount'] / 100) * get_table_data_single_row('dynamics','content','provident_fund','value');
									
									}else{echo $users['provident'];}?>
								</td>
								<td>
								    <?php if($users['rec_amount'] == '0.00' || $users['rec_amount'] == ''){ 
									    echo $rec_amount = $users['amount'] - ($charge + $provident);
									}else{echo $users['rec_amount'];}?>
								</td>
								<td><?php echo $users['trxid']?></td>
								<td><?php echo $users['date']?></td>
								<td><?php echo $users['time']?></td>
								
								<td><?php echo $users['bank_name']?></td>
								<td><?php echo $users['branch_name']?></td>
								<td><?php echo $users['acc_name']?></td>
								<td><?php echo $users['acc_number']?></td>
								<td><?php echo get_table_data_single_row('admin','id',$users['adminid'],'number')?></td>
								
							</tr>
							<?php }}?>
					</table>
				</div>
				<div class="pagination">
					  <?php 
					  $count = 0;
					  
					  $rows = pagination_list('withdraw');
					  if($rows > 1){
						for($count = 0; $count < $rows; $count++ ){?>
						<li><a class="table_pagination_links <?php if($_GET['list'] == $count){echo 'active';}?>" <?php if($count  > ($_GET['list'] + 4)){echo 'style="display:none;"';}else if($count  < ($_GET['list'] - 4)){echo 'style="display:none;"';}?>  href="withdraw.php?list=<?php echo $count;?>"><?php echo $count+1;?></a></li>
					  <?php }}?>
				</div>
			 </div>
		 </div>
		
		
		
		 
		 
	</div>
<?php
  include 'include/footer.php';
?>