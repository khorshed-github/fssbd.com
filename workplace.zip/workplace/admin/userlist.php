<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
  error_reporting(0);
  if(loggedin() == false){
	  header("Location:login.php");
  }
  $search = null;
  if(checkaccess($_SESSION['flc_admin'], 'userlist.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
  //print_r($_SESSION);
  //error_reporting(0);
  if(isset($_POST['new_pass'])){
	  $uid = sanetize($_GET['passch']);
	  $new_pass = sanetize($_POST['new_pass']);
	  if(!empty($new_pass)){
		  $passhash = md5(sha1(md5($new_pass)));
		  $sql = mysqli_query($db, "UPDATE `flc_users` SET `password` = '$passhash' WHERE `id` = '$uid'");
		  if($sql == true){
			  header("Location:userlist.php");
		  }
	  }
  }
  
  if(isset($_POST['new_pin'])){
	  $uid = sanetize($_GET['pinch']);
	  $new_pass = sanetize($_POST['new_pin']);
	  if(!empty($new_pass)){
		  $passhash = md5($new_pass);
		  $sql = mysqli_query($db, "UPDATE `flc_users` SET `pin` = '$passhash',`pinnormal` = '$new_pass' WHERE `id` = '$uid'");
		  if($sql == true){
			  header("Location:userlist.php");
		  }
	  }
  }
if(isset($_POST['smstext'])){
  $uid = sanetize($_GET['sendsms']);
  $number = get_table_data_single_row('flc_users','id',$uid,'number');
  $message = sanetize($_POST['smstext']);
  if(!empty($message)){
	  sendsms($number, $message);
	  header('Location:userlist.php');
  }
}
  if(isset($_POST['remarks'])){
	$uid = sanetize($_GET['fundupdate']);
	$add = sanetize($_POST['add']);
	$cut = sanetize($_POST['cut']);
	$remarks = sanetize($_POST['remarks']);
		if(!empty($remarks)){
			if(empty($add) && !empty($cut)){
				$old_balance = get_table_data_single_row('flc_users','id',$uid,'balance');
				$new_balance = $old_balance - $cut;
				$sql = mysqli_query($db, "UPDATE `flc_users` SET `balance` = '$new_balance' WHERE `id` = '$uid'");
				accounts_update($uid, $cut, $remarks, $old_balance, $new_balance,'dr');
				$number =  get_table_data_single_row('flc_users','id',$uid,'number');
				$message = 'Dear SELF EMPLOYMENTS user, '.$cut.'TK has been deducted from your balance for '.$remarks; 
				sendsms($number, $message);
				if($sql == true){
					header('Location:userlist.php');
				}
			}else if(empty($cut) && !empty($add)){
				 $old_balance = get_table_data_single_row('flc_users','id',$uid,'balance');
				$new_balance = $old_balance + $add;
				$sql = mysqli_query($db, "UPDATE `flc_users` SET `balance` = '$new_balance' WHERE `id` = '$uid'");
				accounts_update($uid, $add, $remarks, $old_balance, $new_balance,'cr');
				$number =  get_table_data_single_row('flc_users','id',$uid,'number');
				$message = 'Dear SELF EMPLOYMENTS user, '.$add.'TK has been added on your balance for '.$remarks; 
				sendsms($number, $message);
				if($sql == true){
					header('Location:userlist.php');
				}
			}
		}
  }
  if(isset($_GET['act'])){
	  $uid = sanetize($_GET['act']);
	  $sql = mysqli_query($db, "UPDATE `flc_users` SET `status` = '1' WHERE `id` = '$uid'");
	  header('Location:userlist.php');
  }
  if(isset($_GET['deact'])){
	   $uid = sanetize($_GET['deact']);
	  $sql = mysqli_query($db, "UPDATE `flc_users` SET `status` = '2' WHERE `id` = '$uid' ");
	  header('Location:userlist.php');
  }
  if(isset($_GET['login'])){
	  $uid = sanetize($_GET['login']);
	  
			$_SESSION['flc_logged'] = $uid;
			header('Location:../profile.php');
	  
	  
  }
  if(isset($_GET['varify'])){
	  $sql = mysqli_query($db, "UPDATE `flc_users` SET `varify` = '1' WHERE `id` = '".sanetize($_GET['varify'])."'");
	  header('Location:userlist.php');
  }
  
  if(isset($_GET['unvarify'])){
	  $sql = mysqli_query($db, "UPDATE `flc_users` SET `varify` = '0' WHERE `id` = '".sanetize($_GET['varify'])."'");
	  header('Location:userlist.php');
  }
  if(isset($_GET['search'])){
	  $number = sanetize($_GET['search']);
	  $sql = get_table_data_specific('flc_users','number',$number);
	  $search  = $sql;
  }
  if(isset($_GET['search_name'])){
	  $name = sanetize($_GET['search_name']);
	  $search = mysqli_query($db, "SELECT * FROM `flc_users` WHERE `username` LIKE '%".$name."%'");
	  
	  
  }
  if(isset($_GET['search_refid'])){
	  $refid = sanetize($_GET['search_refid']);
	  $id = $refid - 112233;
	  $search = mysqli_query($db, "SELECT * FROM `flc_users` WHERE `id` = '$id'");
  }
  if(isset($_GET['search_email'])){
	  $email = sanetize($_GET['search_email']);
	  $search = mysqli_query($db, "SELECT * FROM `flc_users` WHERE `email` = '$email'");
  }
  if(isset($_GET['from_date'])){
	  $from = sanetize($_GET['from_date']);
	  $to = sanetize($_GET['to_date']);
	  $search = mysqli_query($db, "SELECT * FROM `flc_users` WHERE `j_date` BETWEEN '$from' AND '$to'");
  }
  if(isset($_POST['instBonus'])){
	  $id = sanetize($_GET['inst']);
	  $instBonus = sanetize($_POST['instBonus']);
	  $sql = mysqli_query($db, "UPDATE `flc_users` SET `inst` = '$instBonus' WHERE `id` = '$id'");
	  header("Location:userlist.php");
  }
?>
	
	<div class="container col-md-10 col-sm-10"  >
		 
		 <div href="#" class="" style="text-decoration:none;">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h4>Users List</h4>
				</div>
				<div class="panel-body table-responsive">
					
					<?php if(isset($_GET['passch'])){?>
						<form action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post" >
							<div class="form-inline">
								<input type="text" name="new_pass"  class="form-control" placeholder="Insert New Password" />
								<input type="submit" class="btn btn-success" value="Change" />
								<a href="userlist.php" class="btn btn-danger" >Cancel</a>
							</div>
						</form>
					<?php }else if(isset($_GET['pinch'])){?>
						<form action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post" >
							<div class="form-inline">
								<input type="text" name="new_pin"  class="form-control" placeholder="Insert New PIN" />
								<input type="submit" class="btn btn-success" value="Change" />
								<a href="userlist.php" class="btn btn-danger" >Cancel</a>
							</div>
						</form>
					<?php }else if(isset($_GET['fundupdate'])){?>
						<form action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post" >
							<div class="form-inline">
								<input type="text" class="form-control" name="add"  placeholder="Add Fund" />
								<input type="text" class="form-control" name="cut" placeholder="Cut Fund" />
								<input type="text" class="form-control" name="remarks" placeholder="Remarks" />
								<input type="submit" class="btn btn-success" value="Change" />
								<a href="userlist.php" class="btn btn-danger" >Cancel</a>
							</div>
						</form>
					<?php }else if(isset($_GET['sendsms'])){?>
					    <form action="<?php echo $_SERVER['REQUEST_URI'];?>"   method="post">
    						<div class="form-group" >
    						    <textarea name="smstext" placeholder="Write message under 160 characters"  class="form-control"  ></textarea>
    						</div>
    						
    						<div class="form-group" >
    						    <input type="submit" value="Send" class="btn btn-success"   />
    						</div>
    						
    					</form>
					<?php }else if(isset($_GET['inst'])){?>
					    <form action="<?php echo $_SERVER['REQUEST_URI'];?>"   method="post">
    						<div class="form-group" >
    						    <input name="instBonus" placeholder="Instent Bonus"  class="form-control"  />
    						</div>
    					
    						<div class="form-group" >
    						    <input type="submit" value="Send" class="btn btn-success"   />
    						</div>
    						
    					</form>
					<?php } ?>
					<br />
					<div class="form-group">
						
						<form action="userlist.php" class="form-inline pull-left"  method="get">
							<input type="text"  name="search_name" placeholder="Search Name" class="form-control"  />
							<input type="submit" value="&#128269;" class="btn btn-success"   />
						</form>
						<form action="userlist.php" class="form-inline pull-left"  method="get">
							<input type="text"  name="search" placeholder="Search Number" class="form-control"  />
							<input type="submit" value="&#128269;" class="btn btn-success"   />
						</form>
						<form action="userlist.php" class="form-inline pull-left"  method="get">
							<input type="text"  name="search_refid" placeholder="ReferID" class="form-control"  />
							<input type="submit" value="&#128269;" class="btn btn-success"   />
						</form>
						<form action="userlist.php" class="form-inline pull-left"  method="get">
							<input type="text"  name="search_email" placeholder="Search Email" class="form-control"  />
							<input type="submit" value="&#128269;" class="btn btn-success"   />
						</form>
						<form action="userlist.php" method="get"  class="form-inline pull-left">
							<input type="text" name="from_date" placeholder="From Date"  id="datepicker2"  class="form-control" />
							<input type="text" name="to_date" placeholder="To Date" id="datepicker3" class="form-control" />
							<input type="submit" value="&#128269;" class="btn btn-success"   />
						</form>
					</div>
					<br />
					<br />
					<?php if(!empty($search)){?>
						<table class="table table-bordered table-striped">
						<tr class="text-nowrap" >
							<th>Action</th>
							<th>Profile Status</th>
							<th>Profile Image</th>
							<th>Nid Front</th>
							<th>Nid Back</th>
							<th>User-name</th>
							<th>Number</th>
							<th>Referrer Numbr</th>
							<th>ReferID</th>
							<th>Joining Date</th>
							<th>Activation Date</th>
							<th>Joining Status</th>
							<th>Varification Status</th>
							<th>Completed Steps</th>
							<th>Total Income</th>
							<th>Total Withdraw</th>
							<th>Last Withdraw</th>
							<th>Primary Balance</th>
							<th>Secondary Balance</th>
							<th>Finalized Balance</th>
							<th>Instant Bonus</th>
							<th>Email</th>
							<th>Device</th>
							<th>Age</th>
							<th>Date of Birth</th>
							<th>Gender</th>
							<th>Occupation</th>
							<th>Education</th>
							<th>Address</th>
						</tr>
						<?php 
						
						foreach($search as $users){?>
							<tr>
								<td>
									<div class="dropdown">
									  <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
										Action
										<span class="caret"></span>
									  </button>
										<ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
											<li><a href="userlist.php?pinch=<?php echo $users['id'];?>">Pin Change</a></li>
											<li><a href="userlist.php?passch=<?php echo $users['id'];?>">Pass Change</a></li>
											<li><a href="transections.php?uid=<?php echo $users['id'];?>">Account Statement</a></li>
										    <li><a href="userlist.php?login=<?php echo $users['id'];?>">Account Login</a></li>
											<li><a href="userlist.php?fundupdate=<?php echo $users['id'];?>">Funds Mgt</a></li>
											<li><a href="userlist.php?deact=<?php echo $users['id']; ?>" >Suspend</a></li>
											<li><a href="userlist.php?act=<?php echo $users['id']; ?>" >Cancel Suspension</a></li>
											<li><a href="userlist.php?sendsms=<?php echo $users['id']; ?>" >Send SMS</a></li>
											<li><a href="userlist.php?varify=<?php echo $users['id']; ?>" >Varify Now</a></li>
											<li><a href="userlist.php?unvarify=<?php echo $users['id']; ?>" >Un-varify</a></li>
											<li><a href="userlist.php?inst=<?php echo $users['id']; ?>" >Instent Bonus</a></li>
											
										</ul>
									</div>
								</td>
								<td>
									<?php if($users['varify'] == '1'){echo 'varified';}else if($users['varify'] == '0'){ echo 'Un-varified';}?>
								</td>
								<td><img width="180px;"  src="../images/profileImage/<?php echo $users['profilepic']?>" alt="image" /></td>
								<td><img width="180px;"  src="../images/profileImage/<?php echo $users['nid_front']?>" alt="image" /></td>
								<td><img width="180px;"  src="../images/profileImage/<?php echo $users['nid_back']?>" alt="image" /></td>
								<td><?php echo $users['username']?></td>
								<td><?php echo $users['number']?></td>
								<td><?php echo get_table_data_single_row('flc_users','id',$users['ref'],'number');?></td>
								<td><?php echo $users['id']+ 112233;?></td>
								<td><?php echo $users['j_date']?></td>
								<td><?php echo $users['a_date']?></td>
								<td><?php  if($users['status'] == '1'){ echo 'Active';}else if($users['status'] == '0'){ echo 'Inactive';}else if($users['status'] == '2'){echo 'Suspended';}?></td>
								<td><?php  if($users['varify'] == '1'){ echo 'Varified';}else if($users['varify'] == '0'){ echo 'Un-varified';}else if($users['varify'] == '2'){echo 'Suspended';}?></td>
								<td><?php echo $users['points']?></td>
								<td><?php echo get_total_income($users['id']);?></td>
								<td><?php echo get_total_withdraw($users['id']);?></td>
								<td><?php echo get_last_withdraw($users['id']);?></td>
								<td><?php echo $users['p_balance']?></td>
								<td><?php echo $users['s_balance']?></td>
								<td><?php echo $users['balance']?></td>
								<td><?php echo $users['inst']?></td>
								<td><?php echo $users['email']?></td>
								<td><?php echo $users['device']?></td>
								<td><?php if(!empty($users['dob'])){echo get_age($users['dob']);}?></td>
								<td><?php echo $users['dob']?></td>
								<td><?php echo $users['blood']?></td>
								<td><?php echo $users['gender']?></td>
								<td><?php echo $users['occ']?></td>
								<td><?php echo $users['edu']?></td>
								<td><?php echo $users['address']?></td>
							</tr>
						<?php }?>
					</table>
					<br />
					<?php }?>
					
					
					<table class="table table-bordered table-striped">
						<tr class="text-nowrap" >
							<th>Action</th>
							<th>User-name</th>
							<th>Number</th>
							<th>Referrer Numbr</th>
							<th>ReferID</th>
							<th>Joining Date</th>
							<th>Activation Date</th>
							<th>Joining Status</th>
							<th>Varification Status</th>
						
						</tr>
						<?php 
						if(!isset($_GET['list'])){
						foreach(get_ten_data('flc_users') as $users){?>
							<tr>
								<td>
									<div class="dropdown">
									  <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
										Action
										<span class="caret"></span>
									  </button>
											<ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
											<li><a href="userlist.php?pinch=<?php echo $users['id'];?>">Pin Change</a></li>
											<li><a href="userlist.php?passch=<?php echo $users['id'];?>">Pass Change</a></li>
											<li><a href="transections.php?uid=<?php echo $users['id'];?>">Account Statement</a></li>
										    <li><a href="userlist.php?login=<?php echo $users['id'];?>">Account Login</a></li>
											<li><a href="userlist.php?fundupdate=<?php echo $users['id'];?>">Funds Mgt</a></li>
											<li><a href="userlist.php?deact=<?php echo $users['id']; ?>" >Suspend</a></li>
											<li><a href="userlist.php?act=<?php echo $users['id']; ?>" >Cancel Suspension</a></li>
											<li><a href="userlist.php?sendsms=<?php echo $users['id']; ?>" >Send SMS</a></li>
											<li><a href="userlist.php?varify=<?php echo $users['id']; ?>" >Varify Now</a></li>
											<li><a href="userlist.php?unvarify=<?php echo $users['id']; ?>" >Un-varify</a></li>
											<li><a href="userlist.php?inst=<?php echo $users['id']; ?>" >Instent Bonus</a></li>
											
										</ul>
									</div>
								</td>
								<td><?php echo $users['username']?></td>
								<td><?php echo $users['number']?></td>
								<td><?php echo get_table_data_single_row('flc_users','id',$users['ref'],'number');?></td>
								<td><?php echo $users['id']+ 112233;?></td>
								<td><?php echo $users['j_date']?></td>
								<td><?php echo $users['a_date']?></td>
								<td><?php  if($users['status'] == '1'){ echo 'Active';}else if($users['status'] == '0'){ echo 'Inactive';}else if($users['status'] == '2'){echo 'Suspended';}?></td>
								<td><?php  if($users['varify'] == '1'){ echo 'Varified';}else if($users['varify'] == '0'){ echo 'Un-varified';}else if($users['varify'] == '2'){echo 'Suspended';}?></td>
							
							</tr>
						<?php }}else{
							foreach(paginationed($_GET['list'],'flc_users') as $users){
							?>
							<tr>
								<td>
									<div class="dropdown">
									  <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
										Action
										<span class="caret"></span>
									  </button>
											<ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
											<li><a href="userlist.php?pinch=<?php echo $users['id'];?>">Pin Change</a></li>
											<li><a href="userlist.php?passch=<?php echo $users['id'];?>">Pass Change</a></li>
											<li><a href="transections.php?uid=<?php echo $users['id'];?>">Account Statement</a></li>
											<?php 
											if($_SESSION['flc_admin'] == '1'){?>
											    <li><a href="userlist.php?login=<?php echo $users['id'];?>">Account Login</a></li>
											<?php }
											
											?>
											<li><a href="userlist.php?fundupdate=<?php echo $users['id'];?>">Funds Mgt</a></li>
											<li><a href="userlist.php?deact=<?php echo $users['id']; ?>" >Suspend</a></li>
											<li><a href="userlist.php?act=<?php echo $users['id']; ?>" >Cancel Suspension</a></li>
											<li><a href="userlist.php?sendsms=<?php echo $users['id']; ?>" >Send SMS</a></li>
											<li><a href="userlist.php?varify=<?php echo $users['id']; ?>" >Varify Now</a></li>
											<li><a href="userlist.php?unvarify=<?php echo $users['id']; ?>" >Un-varify</a></li>
											<li><a href="userlist.php?inst=<?php echo $users['id']; ?>" >Instent Bonus</a></li>
											
										</ul>
									</div>
								</td>
								<td><?php echo $users['username']?></td>
								<td><?php echo $users['number']?></td>
								<td><?php echo get_table_data_single_row('flc_users','id',$users['ref'],'number');?></td>
								<td><?php echo $users['id']+ 112233;?></td>
								<td><?php echo $users['j_date']?></td>
								<td><?php echo $users['a_date']?></td>
								<td><?php  if($users['status'] == '1'){ echo 'Active';}else if($users['status'] == '0'){ echo 'Inactive';}else if($users['status'] == '2'){echo 'Suspended';}?></td>
								<td><?php  if($users['varify'] == '1'){ echo 'Varified';}else if($users['varify'] == '0'){ echo 'Un-varified';}else if($users['varify'] == '2'){echo 'Suspended';}?></td>
							
							</tr>
							<?php }}?>
					</table>
				</div>
				<div class="pagination">
					  <?php 
					  $count = 0;
					  
					  $rows = pagination_list('flc_users');
					  if($rows > 1){
						for($count = 0; $count < $rows; $count++ ){?>
						<li><a class="table_pagination_links <?php if($_GET['list'] == $count){echo 'active';}?>" <?php if($count  > ($_GET['list'] + 4)){echo 'style="display:none;"';}else if($count  < ($_GET['list'] - 4)){echo 'style="display:none;"';}?>  href="userlist.php?list=<?php echo $count;?>"><?php echo $count+1;?></a></li>
					  <?php }}?>
				</div>
			 </div>
		 </div>
	</div>
<?php
  include 'include/footer.php';
?>