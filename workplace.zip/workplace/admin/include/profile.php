<?php
include '../conf/conn.php';
include '../conf/common_function.php';
include '../conf/function.php';

$response = array();
$response['success'] = 0;
if(loggedin() == true){
	$uid = $_SESSION['flc_logged'];
}
if(isset($_POST['profile_username'])){
	$username = sanetize($_POST['profile_username']);
    $email = sanetize($_POST['profile_email']);
    $dob = sanetize($_POST['profile_dob']);
    $gender = sanetize($_POST['profile_gender']);
    $occ = sanetize($_POST['profile_occ']); 
    $edu = sanetize($_POST['profile_edu']);
    $address = sanetize($_POST['profile_address']);
	if(isset($_POST['profile_device'])){
		$device = sanetize($_POST['profile_device']);
	}
	$sql = mysqli_query($db, "UPDATE `flc_users` SET 
	`username` = '$username',
	`email` = '$email',
	`dob` = '$dob',
	`gender` = '$gender',
	`occ` = '$occ',
	`device` = '$device',
	`edu` = '$edu',
	`address` = '$address'
	WHERE `id` = '$uid'");
	if($sql == true){
		$response['success'] = 1; 
	}else{
		$response['message'] = mysqli_error($db); 
	}
}
echo json_encode($response);
?>