<?php
if(loggedin() == false){
	header("Location:login.php");
}
?>
