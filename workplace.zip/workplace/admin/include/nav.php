<nav class="navbar navbar-info">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="admin-main-menu navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#admin-main-menu" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#" style="width:200px; padding-top:4px;" ><img width="100%" src="images/logo.png" alt="" /></a>
    </div>
  </div><!-- /.container-fluid -->
</nav>

<!-- Collect the nav links, forms, and other content for toggling -->
<div class="container-fluid">
  <div class="row">
<div class="col-lg-2 col-md-2 col-sm-3 col-xs-12 dashboard_side_panel">
  <div class="collapse navbar-collapse row" id="admin-main-menu">
  	<div class="list-group row" style="margin-bottom:0px;">
  		<a href="index.php?members" class="list-group-item <?php if($_SERVER['SCRIPT_NAME'] == '/freelance/index.php'){echo 'active';}?>" ><i class="fa fa-window-restore"></i> Dashboard</a>
  		<a href="userlist.php" class="list-group-item <?php if($_SERVER['SCRIPT_NAME'] == '/freelance/userlist.php'){echo 'active';}?>"><i class="fa fa-address-book"></i> Member Management</a>
  		<a href="daily_aproval.php" class="list-group-item <?php if($_SERVER['SCRIPT_NAME'] == '/freelance/daily_aproval.php'){echo 'active';}?>"><i class="fa fa-address-book"></i> Daily Balance Aproval</a>
  		<a href="monthly_aproval.php" class="list-group-item <?php if($_SERVER['SCRIPT_NAME'] == '/freelance/monthly_aproval.php'){echo 'active';}?>"><i class="fa fa-address-book"></i> Monthly Balance Aproval</a>
  		<a href="jobs.php" class="list-group-item <?php if($_SERVER['SCRIPT_NAME'] == '/freelance/tasks.php'){echo 'active';}?>"><i class="fa fa-share-alt"></i> Work Management</a>
  		<a href="sites.php" class="list-group-item <?php if($_SERVER['SCRIPT_NAME'] == '/freelance/tasks.php'){echo 'active';}?>"><i class="fa fa-share-alt"></i> Site Management</a>
  		<a href="act_request.php" class="list-group-item <?php if($_SERVER['SCRIPT_NAME'] == '/freelance/act_request.php'){echo 'active';}?>"><i class="fa fa-user"></i> Activation Requests</a>
  		<a href="purchases.php" class="list-group-item <?php if($_SERVER['SCRIPT_NAME'] == '/freelance/act_request.php'){echo 'active';}?>"><i class="fa fa-user"></i> Purchase Requests</a>
  		<a href="varification.php" class="list-group-item <?php if($_SERVER['SCRIPT_NAME'] == '/freelance/act_request.php'){echo 'active';}?>"><i class="fa fa-user"></i> Varification Requests</a>
  		<a href="dps.php" class="list-group-item <?php if($_SERVER['SCRIPT_NAME'] == '/freelance/act_request.php'){echo 'active';}?>"><i class="fa fa-user"></i> Delivery Points</a>
  		<a href="addfund.php" class="list-group-item <?php if($_SERVER['SCRIPT_NAME'] == '/freelance/addfund.php'){echo 'active';}?>"><i class="fa fa-user"></i> Deposit Request</a>
  		<a href="withdraw.php" class="list-group-item <?php if($_SERVER['SCRIPT_NAME'] == '/freelance/withdraw.php'){echo 'active';}?>"><i class="fa fa-user"></i> Withdraw Requests</a>
  		
  		<a href="adds.php" class="list-group-item <?php if($_SERVER['SCRIPT_NAME'] == '/freelance/tasks.php'){echo 'active';}?>"><i class="fa fa-share-alt"></i> Other Adds Management</a>
  		<a href="texts.php" class="list-group-item <?php if($_SERVER['SCRIPT_NAME'] == '/freelance/texts.php'){echo 'active';}?>"><i class="fa fa-font"></i> Texts</a>
  		<a href="income_plan.php" class="list-group-item <?php if($_SERVER['SCRIPT_NAME'] == '/freelance/regular.php'){echo 'active';}?>"><i class="fa fa-check-square-o"></i> Income Plans</a>
  		<a href="transections.php" class="list-group-item <?php if($_SERVER['SCRIPT_NAME'] == '/freelance/transections.php'){echo 'active';}?>"><i class="fa fa-exchange"></i> Transactions</a>
  		<a href="dynamics.php" class="list-group-item <?php if($_SERVER['SCRIPT_NAME'] == '/freelance/support.php'){echo 'active';}?>"><i class="fa fa-question"></i> Dynamic Values</a>
  		<a href="subadmin.php" class="list-group-item <?php if($_SERVER['SCRIPT_NAME'] == '/freelance/support.php'){echo 'active';}?>"><i class="fa fa-question"></i> Create Subadmin</a>
  		<a href="logout.php" class="list-group-item <?php if($_SERVER['SCRIPT_NAME'] == '/freelance/logout.php'){echo 'active';}?>"><i class="fa fa-power-off"></i> Logout</a>
  	</div>
  	
  </div>
  
</div>

<!-- /.navbar-collapse -->