<?php
include '../conf/conn.php';
include '../conf/common_function.php';
include '../conf/function.php';

$response = array();
$response['success'] = 0;
if(loggedin() == true){
	/*$uid = $_SESSION['flc_logged'];*/
	$uid = $_SESSION['flc_admin'];
}

//$_POST['job_locators'] = 'task_1&step_1';
if(isset($_POST['task_time_back'])){
	$time = sanetize($_POST['task_time_back']);
	$delay = sanetize($_POST['delay']);
	$times = $time + $delay;
	$elapsed = $times - time();
	if($times == time()){
		$response['success'] = 1;
	}else if($times < time()){
		$response['success'] = 1;
	}else{
		$response['message'] =  date('i:s',$elapsed);
	}
}
if(isset($_POST['waiting_time'])){
	$time = sanetize($_POST['waiting_time']);
	$times = $time + 15;
	$elapsed = $times - time();
	if($times == time()){
		$response['success'] = 1;
	}else if($times < time()){
		$response['success'] = 1;
	}else{
		$response['message'] =  date('i:s',$elapsed);
	}
}

echo json_encode($response);
?>