<?php
include '../conf/conn.php';
include '../conf/common_function.php';
include '../conf/function.php';

$response = array();
$response['success'] = 0;
if(loggedin() == true){
	$uid = $_SESSION['flc_logged'];
}
if(isset($_POST['job_locator'])){
	$_SESSION['semi_final'] = 1;
}
//$_POST['job_locators'] = 'task_2&step_10';
//$_SESSION['semi_final'] = 1;
if(isset($_POST['job_locators'])){
	$task_status = $_POST['job_locators'];
	$array = explode('&', $task_status);
	$array2 = explode('_',$array[0]);
	$array3 = explode('_',$array[1]);
	if(isset($_SESSION['semi_final'])){
		$sql = mysqli_query($db, "UPDATE `steps` SET `status` = '1' WHERE `uid` = '$uid' AND `taskid` = '".$array2[1]."' AND `step` = '".$array3[1]."' AND `date` = '".dates()."'");
		if($array3[1] == '10'){
			$sql2 = mysqli_query($db, "UPDATE `steps` SET `completed` = '".time()."' WHERE `uid` = '$uid' AND `taskid` = '".$array2[1]."' AND `step` = '".$array3[1]."'  AND `date` = '".dates()."'");
			$sql3 = mysqli_query($db, "UPDATE `dailytask` SET `status` = '1' WHERE `task` = '".$array2[1]."' AND `uid` = '$uid' AND `date` = '".dates()."'");
			$old_point = get_table_data_single_row('flc_users','id',$uid,'point');
			$new_point = $old_point + 1;
			$old_points = get_table_data_single_row('flc_users','id',$uid,'points');
			$new_points = $old_points + 1;
			$update = mysqli_query($db, "UPDATE `flc_users` SET `point` = '$new_point',`points` = '$new_points' WHERE `id` = '$uid'");
			$earning_rate = get_earning_rate($uid);
			$old_balance = get_table_data_single_row('flc_users','id',$uid,'balance');
			$new_balance = $old_balance + $earning_rate;
			$give_work_income = mysqli_query($db, "UPDATE `flc_users` SET `balance` = '$new_balance' WHERE `id` = '$uid'");
			send_uppler_level_commission($uid,$earning_rate);
			accounts_update($uid,$earning_rate,'Work earning deposited on balance',$old_balance,$new_balance,'cr');
			unset($_SESSION['semi_final']);
		}
	}
}
if(isset($_POST['page_session'])){
	if(!isset($_SESSION['aproval_checked'])){
		$_SESSION['aproval_checked'][] = $_POST['page_session'];
	}else if(isset($_SESSION['aproval_checked'])){
		$found = 0;
		foreach($_SESSION['aproval_checked'] as $key => $value){
			if($value == $_POST['page_session']){
				$found = 1;
				$keyid = $key;
			}
		}
		if($found == 0){
			$_SESSION['aproval_checked'][] = $_POST['page_session'];
		}else if($found == 1){
			unset($_SESSION['aproval_checked'][$keyid]);
		}
	}
}
if(isset($_POST['select_all'])){
	$sql = mysqli_query($db, "SELECT `id` FROM `flc_users` WHERE `p_balance` != '0.00'");
	unset($_SESSION['aproval_checked']);
	foreach($sql as $id){
		$_SESSION['aproval_checked'][] = $id['id'];
	}
}
if(isset($_POST['select_all_two'])){
	$sql = mysqli_query($db, "SELECT `id` FROM `flc_users` WHERE `s_balance` != '0.00'");
	unset($_SESSION['aproval_checked']);
	foreach($sql as $id){
		$_SESSION['aproval_checked'][] = $id['id'];
	}
}
echo json_encode($response);
?>