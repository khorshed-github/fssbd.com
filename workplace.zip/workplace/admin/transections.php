<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
  if(loggedin() == false){
	  header("Location:login.php");
  }
  if(checkaccess($_SESSION['flc_admin'], 'transections.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
?>
	
	<div class="container col-md-10 col-sm-10"  >
				<nav class="pull-right" aria-label="Pagination">
				  <ul class="pager">
					<li><a class="btn btn-default btn-xs clickdisable" id="prev_btn"><i class="glyphicon glyphicon-triangle-left"></i> Previous</a></li>
					<li><a class="btn btn-default btn-xs" id="next_btn">Next <i class="glyphicon glyphicon-triangle-right"></i></a></li>
				  </ul>
				</nav>
				<div class="clearfix"></div>
				<div class="panel panel-default">
					
					<div class="panel-heading">
						Transections
					</div>
					<div class="panel-body table-responsive">
						<table class="table table-bordered table-striped">
							<thead>
								<tr>
									<th>Remarks</th>
									<th>Debit</th>
									<th>Credit</th>
									<th>Old Balance</th>
									<th>New Balance</th>
									<th>Date</th>
									<th>Time</th>
								</tr>
							</thead>
							<tbody>
								<?php 
								if(!isset($_GET['uid'])){
								    if(get_table_data_all('accounts')->num_rows < 11){
								foreach(get_table_data_all('accounts') as $users){
									
									?>
									<tr>
										<td><?php echo $users['details'];?></td>
										<td><?php echo $users['dr_amount'];?></td>
										<td><?php echo $users['cr_amount'];?></td>
										<td><?php echo $users['old_bal'];?></td>
										<td><?php echo $users['new_bal'];?></td>
										<td><?php echo $users['date'];?></td>
										<td><?php echo $users['time'];?></td>
									</tr>
								<?php 
								}}else if(get_table_data_all('accounts')->num_rows >= 11){
									$sl = 1;
									foreach(get_table_data_all('accounts') as $users){
										if($sl < 11){
											?>
												<tr value="<?php echo $sl?>" class="datas showns sl_<?php echo $sl?>"  >
														<td><?php echo $users['details'];?></td>
														<td><?php echo $users['dr_amount'];?></td>
														<td><?php echo $users['cr_amount'];?></td>
														<td><?php echo $users['old_bal'];?></td>
														<td><?php echo $users['new_bal'];?></td>
														<td><?php echo $users['date'];?></td>
														<td><?php echo $users['time'];?></td>
													</tr>
											<?php 
										}else if($sl >= 11){
											?>
												<tr value="<?php echo $sl?>" class="datas hiddens sl_<?php echo $sl?>"  >
													<td><?php echo $users['details'];?></td>
													<td><?php echo $users['dr_amount'];?></td>
													<td><?php echo $users['cr_amount'];?></td>
													<td><?php echo $users['old_bal'];?></td>
													<td><?php echo $users['new_bal'];?></td>
													<td><?php echo $users['date'];?></td>
													<td><?php echo $users['time'];?></td>
												</tr>
											<?php 
										}
										$sl++;
									}	
								}
								}else if(isset($_GET['uid'])){
								    $uid = sanetize($_GET['uid']);
								    if(get_table_data_specific_inv('accounts','uid',$uid)->num_rows < 11){
								foreach(get_table_data_specific_inv('accounts','uid',$uid) as $users){
									
									?>
									<tr>
										<td><?php echo $users['details'];?></td>
										<td><?php echo $users['dr_amount'];?></td>
										<td><?php echo $users['cr_amount'];?></td>
										<td><?php echo $users['old_bal'];?></td>
										<td><?php echo $users['new_bal'];?></td>
										<td><?php echo $users['date'];?></td>
										<td><?php echo $users['time'];?></td>
									</tr>
								<?php 
								}}else if(get_table_data_specific_inv('accounts','uid',$uid)->num_rows >= 11){
									$sl = 1;
									foreach(get_table_data_specific_inv('accounts','uid',$uid) as $users){
										if($sl < 11){
											?>
												<tr value="<?php echo $sl?>" class="datas showns sl_<?php echo $sl?>"  >
														<td><?php echo $users['details'];?></td>
														<td><?php echo $users['dr_amount'];?></td>
														<td><?php echo $users['cr_amount'];?></td>
														<td><?php echo $users['old_bal'];?></td>
														<td><?php echo $users['new_bal'];?></td>
														<td><?php echo $users['date'];?></td>
														<td><?php echo $users['time'];?></td>
													</tr>
											<?php 
										}else if($sl >= 11){
											?>
												<tr value="<?php echo $sl?>" class="datas hiddens sl_<?php echo $sl?>"  >
													<td><?php echo $users['details'];?></td>
													<td><?php echo $users['dr_amount'];?></td>
													<td><?php echo $users['cr_amount'];?></td>
													<td><?php echo $users['old_bal'];?></td>
													<td><?php echo $users['new_bal'];?></td>
													<td><?php echo $users['date'];?></td>
													<td><?php echo $users['time'];?></td>
												</tr>
											<?php 
										}
										$sl++;
									}	
								}
								}
								?>
							</tbody>
						</table>
					</div>
				</div>
			
	</div>
<?php
  include 'include/footer.php';
?>