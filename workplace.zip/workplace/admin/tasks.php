<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
	//error_reporting(0);
  if(loggedin() == false){
	  header("Location:login.php");
  } 
  if(checkaccess($_SESSION['flc_admin'], 'tasks.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
  
 if(isset($_GET['date'])){
  $date = $_GET['date'];
  $sql  = mysqli_query($db, "SELECT * FROM `jobs2` WHERE `date` = '$date' AND `status` = '0' LIMIT 1");
  $data = mysqli_fetch_assoc($sql);
  $id = $data['id'];
	
 }else if(isset($_GET['edit'])){
	  
  $id = $_GET['edit'];
 }
	$error = array();
	if(isset($_POST['type_1'])){
		
		$count = 1;
		$array = array();
		$cont = 0;
		while($cont == 0){
			if($count == 101){
				$cont = 1;
			}else{
				$array[$count][] = $_POST['type_'.$count];
				$array[$count][] = $_POST['image_'.$count];
				$array[$count][] = $_POST['script_'.$count];
				$count++;
			}
		}
		
		foreach($array as $key => $data){
			if($data[0] == 0){
				$counter = $key;
				$link = $data[1];
				$file_name = $_FILES['file_'.$counter]['name'];
				$file_tmp = $_FILES['file_'.$counter]['tmp_name'];
				$rand = rand(10000,90000);
				$new_file_name = $rand.$file_name;
				move_uploaded_file($file_tmp, '../images/job/'.$new_file_name);
				$sql = mysqli_query($db, "INSERT INTO `jobs` 
				(`jobid`,`serial`,`type`,`link`,`image`)
				VALUES
				('$id','$counter','".$data[0]."','$link','$new_file_name')
				");
			}else if($data[0] == 1){
				$script = urlencode($_POST['script_'.$key]);
				$sql = mysqli_query($db, "INSERT INTO `jobs` 
				(`jobid`,`serial`,`type`,`script`)
				VALUES
				('$id','$key','".$data[0]."','$script')
				");
			}
		}
		$sql = mysqli_query($db, "UPDATE `jobs2` SET `status` = '1' WHERE `id` = '$id'");
		header('Location:tasks.php');
	}
//print_r($_SESSION);
?>
	
	<div class="container col-md-10 col-sm-10"  >
		<div class="panel panel-default">
			<div class="panel-body">
				<div class="btn btn-warning">Job Date : <?php echo get_table_data_single_row('jobs2','id',$id,'date'); ?></div>
				<div class="btn btn-info">Job  : <?php echo get_table_data_single_row('jobs2','id',$id,'taskid'); ?></div>
				<div class="btn btn-primary">Step  : <?php echo get_table_data_single_row('jobs2','id',$id,'step'); ?></div>
			</div>
		</div>
		<form action="<?php echo $_SERVER['REQUEST_URI']?>" method="post" enctype="multipart/form-data"   >
			<span><?php if(!empty($error)){ echo '<div class="alert alert-warning">'.$error[0].'</div>';}?></span>
			<div class="panel panel-info">
				<div class="panel-heading">
					Ads Management
				</div>
				<div class="panel-body">
					<table class="table table-bordered">
						<tr>
							<td>1</td>
							<td>
									<div class="form-group">
										<select name="type_1" id="" class="form-control">
											<option value="3">Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_1').'"';}?> name="script_1" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_1').'"';}?> name="image_1" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_1"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>2</td>
							<td>
									<div class="form-group">
										<select name="type_2" id="" class="form-control">
										<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_2').'"';}?> name="script_2" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_2').'"';}?> name="image_2" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_2"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>3</td>
							<td>
									<div class="form-group">
										<select name="type_3" id="" class="form-control">
										<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_3').'"';}?> name="script_3" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_3').'"';}?> name="image_3" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_3"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>4</td>
							<td>
									<div class="form-group">
										<select name="type_4" id="" class="form-control">
										<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_4').'"';}?> name="script_4" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_4').'"';}?> name="image_4" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_4"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>5</td>
							<td>
									<div class="form-group">
										<select name="type_5" id="" class="form-control">
										<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_5').'"';}?> name="script_5" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_5').'"';}?> name="image_5" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_5"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>6</td>
							<td>
									<div class="form-group">
										<select name="type_6" id="" class="form-control">
										<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_6').'"';}?> name="script_6" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_6').'"';}?> name="image_6" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_6"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>7</td>
							<td>
									<div class="form-group">
										<select name="type_7" id="" class="form-control">
										<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_7').'"';}?> name="script_7" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_7').'"';}?> name="image_7" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_7"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>8</td>
							<td>
									<div class="form-group">
										<select name="type_8" id="" class="form-control">
										<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_8').'"';}?> name="script_8" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_8').'"';}?> name="image_8" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_8"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>9</td>
							<td>
									<div class="form-group">
										<select name="type_9" id="" class="form-control">
										<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_9').'"';}?> name="script_9" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_9').'"';}?> name="image_9" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_9"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>10</td>
							<td>
									<div class="form-group">
										<select name="type_10" id="" class="form-control">
										<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_10').'"';}?> name="script_10" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_10').'"';}?> name="image_10" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_10"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>11</td>
							<td>
									<div class="form-group">
										<select name="type_11" id="" class="form-control">
										<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_11').'"';}?> name="script_11" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_11').'"';}?> name="image_11" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_11"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>12</td>
							<td>
									<div class="form-group">
										<select name="type_12" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_12').'"';}?> name="script_12" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_12').'"';}?> name="image_12" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_12"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>13</td>
							<td>
									<div class="form-group">
										<select name="type_13" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_13').'"';}?> name="script_13" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_13').'"';}?> name="image_13" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_13"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>14</td>
							<td>
									<div class="form-group">
										<select name="type_14" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_14').'"';}?> name="script_14" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_14').'"';}?> name="image_14" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_14"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>15</td>
							<td>
									<div class="form-group">
										<select name="type_15" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_15').'"';}?> name="script_15" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_15').'"';}?> name="image_15" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_15"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>16</td>
							<td>
									<div class="form-group">
										<select name="type_16" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_16').'"';}?> name="script_16" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_16').'"';}?> name="image_16" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_16"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>17</td>
							<td>
									<div class="form-group">
										<select name="type_17" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_17').'"';}?> name="script_17" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_17').'"';}?> name="image_17" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_17"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>18</td>
							<td>
									<div class="form-group">
										<select name="type_18" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_18').'"';}?> name="script_18" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_18').'"';}?> name="image_18" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_18"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>19</td>
							<td>
									<div class="form-group">
										<select name="type_19" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_19').'"';}?> name="script_19" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_19').'"';}?> name="image_19" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_19"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>20</td>
							<td>
									<div class="form-group">
										<select name="type_20" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_20').'"';}?> name="script_20" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_20').'"';}?> name="image_20" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_20"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>21</td>
							<td>
								<div class="form-group">
									<select name="type_21" id="" class="form-control">
										<option value="3" >Select</option>
										<option value="0">Link</option>
										<option value="1">Script</option>
									</select>
								</div>								
								<div class="form-group">
									<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_21').'"';}?> name="script_21" class="form-control"  placeholder="Insert Script" />
								</div>								
								<div class="form-group">
									<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_21').'"';}?> name="image_21" class="form-control"  placeholder="Insert Link" />
								</div>
								<div class="form-group">
									<input type="file"  name="file_21"   id="add_image_one"  />
								</div>
							</td>
						</tr>
						<tr>
							<td>22</td>
							<td>
								<div class="form-group">
									<select name="type_22" id="" class="form-control">
										<option value="3" >Select</option>
										<option value="0">Link</option>
										<option value="1">Script</option>
									</select>
								</div>								
								<div class="form-group">
									<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_22').'"';}?> name="script_22" class="form-control"  placeholder="Insert Script" />
								</div>								
								<div class="form-group">
									<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_22').'"';}?> name="image_22" class="form-control"  placeholder="Insert Link" />
								</div>
								<div class="form-group">
									<input type="file"  name="file_22"   id="add_image_one"  />
								</div>
							</td>
						</tr>
						<tr>
							<td>23</td>
							<td>
								<div class="form-group">
									<select name="type_23" id="" class="form-control">
										<option value="3" >Select</option>
										<option value="0">Link</option>
										<option value="1">Script</option>
									</select>
								</div>								
								<div class="form-group">
									<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_23').'"';}?> name="script_23" class="form-control"  placeholder="Insert Script" />
								</div>								
								<div class="form-group">
									<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_23').'"';}?> name="image_23" class="form-control"  placeholder="Insert Link" />
								</div>
								<div class="form-group">
									<input type="file"  name="file_23"   id="add_image_one"  />
								</div>
							</td>
						</tr>
						<tr>
							<td>24</td>
							<td>
								<div class="form-group">
									<select name="type_24" id="" class="form-control">
										<option value="3" >Select</option>
										<option value="0">Link</option>
										<option value="1">Script</option>
									</select>
								</div>								
								<div class="form-group">
									<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_24').'"';}?> name="script_24" class="form-control"  placeholder="Insert Script" />
								</div>								
								<div class="form-group">
									<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_24').'"';}?> name="image_24" class="form-control"  placeholder="Insert Link" />
								</div>
								<div class="form-group">
									<input type="file"  name="file_24"   id="add_image_one"  />
								</div>
							</td>
						</tr>
						<tr>
							<td>25</td>
							<td>
									<div class="form-group">
										<select name="type_25" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_25').'"';}?> name="script_25" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_25').'"';}?> name="image_25" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_25"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>26</td>
							<td>
									<div class="form-group">
										<select name="type_26" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_26').'"';}?> name="script_26" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_26').'"';}?> name="image_26" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_26"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>27</td>
							<td>
									<div class="form-group">
										<select name="type_27" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_27').'"';}?> name="script_27" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_27').'"';}?> name="image_27" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_27"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>28</td>
							<td>
									<div class="form-group">
										<select name="type_28" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_28').'"';}?> name="script_28" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_28').'"';}?> name="image_28" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_28"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>29</td>
							<td>
									<div class="form-group">
										<select name="type_29" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_29').'"';}?> name="script_29" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_29').'"';}?> name="image_29" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_29"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>30</td>
							<td>
									<div class="form-group">
										<select name="type_30" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_30').'"';}?> name="script_30" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_30').'"';}?> name="image_30" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_30"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>31</td>
							<td>
									<div class="form-group">
										<select name="type_31" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_31').'"';}?> name="script_31" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_31').'"';}?> name="image_31" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_31"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>32</td>
							<td>
									<div class="form-group">
										<select name="type_32" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_32').'"';}?> name="script_32" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_32').'"';}?> name="image_32" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_32"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>33</td>
							<td>
									<div class="form-group">
										<select name="type_33" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_33').'"';}?> name="script_33" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_33').'"';}?> name="image_33" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_33"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>34</td>
							<td>
									<div class="form-group">
										<select name="type_34" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_34').'"';}?> name="script_34" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_34').'"';}?> name="image_34" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_34"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>35</td>
							<td>
									<div class="form-group">
										<select name="type_35" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_35').'"';}?> name="script_35" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_35').'"';}?> name="image_35" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_35"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>36</td>
							<td>
									<div class="form-group">
										<select name="type_36" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_36').'"';}?> name="script_36" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_36').'"';}?> name="image_36" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_36"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>37</td>
							<td>
									<div class="form-group">
										<select name="type_37" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_37').'"';}?> name="script_37" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_37').'"';}?> name="image_37" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_37"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>38</td>
							<td>
									<div class="form-group">
										<select name="type_38" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_38').'"';}?> name="script_38" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_38').'"';}?> name="image_38" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_38"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>39</td>
							<td>
									<div class="form-group">
										<select name="type_39" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_39').'"';}?> name="script_39" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_39').'"';}?> name="image_39" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_39"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>40</td>
							<td>
									<div class="form-group">
										<select name="type_40" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_40').'"';}?> name="script_40" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_40').'"';}?> name="image_40" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_40"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>41</td>
							<td>
									<div class="form-group">
										<select name="type_41" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_41').'"';}?> name="script_41" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_41').'"';}?> name="image_41" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_41"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>42</td>
							<td>
									<div class="form-group">
										<select name="type_42" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_42').'"';}?> name="script_42" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_42').'"';}?> name="image_42" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_42"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>43</td>
							<td>
									<div class="form-group">
										<select name="type_43" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_43').'"';}?> name="script_43" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_43').'"';}?> name="image_43" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_43"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>44</td>
							<td>
									<div class="form-group">
										<select name="type_44" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_44').'"';}?> name="script_44" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_44').'"';}?> name="image_44" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_44"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>45</td>
							<td>
									<div class="form-group">
										<select name="type_45" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_45').'"';}?> name="script_45" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_45').'"';}?> name="image_45" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_45"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>46</td>
							<td>
									<div class="form-group">
										<select name="type_46" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_46').'"';}?> name="script_46" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_46').'"';}?> name="image_46" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_46"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>47</td>
							<td>
									<div class="form-group">
										<select name="type_47" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_47').'"';}?> name="script_47" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_47').'"';}?> name="image_47" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_47"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>48</td>
							<td>
									<div class="form-group">
										<select name="type_48" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_48').'"';}?> name="script_48" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_48').'"';}?> name="image_48" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_48"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>49</td>
							<td>
									<div class="form-group">
										<select name="type_49" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_49').'"';}?> name="script_49" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_49').'"';}?> name="image_49" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_49"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>50</td>
							<td>
									<div class="form-group">
										<select name="type_50" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_50').'"';}?> name="script_50" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_50').'"';}?> name="image_50" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_50"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>51</td>
							<td>
									<div class="form-group">
										<select name="type_51" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_51').'"';}?> name="script_51" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_51').'"';}?> name="image_51" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_51"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>52</td>
							<td>
									<div class="form-group">
										<select name="type_52" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_52').'"';}?> name="script_52" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_52').'"';}?> name="image_52" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_52"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>53</td>
							<td>
									<div class="form-group">
										<select name="type_53" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_53').'"';}?> name="script_53" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_53').'"';}?> name="image_53" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_53"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>54</td>
							<td>
									<div class="form-group">
										<select name="type_54" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_54').'"';}?> name="script_54" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_54').'"';}?> name="image_54" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_54"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>55</td>
							<td>
									<div class="form-group">
										<select name="type_55" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_55').'"';}?> name="script_55" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_55').'"';}?> name="image_55" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_55"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>56</td>
							<td>
									<div class="form-group">
										<select name="type_56" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_56').'"';}?> name="script_56" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_56').'"';}?> name="image_56" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_56"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>57</td>
							<td>
									<div class="form-group">
										<select name="type_57" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_57').'"';}?> name="script_57" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_57').'"';}?> name="image_57" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_57"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>58</td>
							<td>
									<div class="form-group">
										<select name="type_58" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_58').'"';}?> name="script_58" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_58').'"';}?> name="image_58" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_58"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>59</td>
							<td>
									<div class="form-group">
										<select name="type_59" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_59').'"';}?> name="script_59" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_59').'"';}?> name="image_59" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_59"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>60</td>
							<td>
									<div class="form-group">
										<select name="type_60" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_60').'"';}?> name="script_60" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_60').'"';}?> name="image_60" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_60"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>61</td>
							<td>
									<div class="form-group">
										<select name="type_61" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_61').'"';}?> name="script_61" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_61').'"';}?> name="image_61" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_61"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>62</td>
							<td>
									<div class="form-group">
										<select name="type_62" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_62').'"';}?> name="script_62" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_62').'"';}?> name="image_62" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_62"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>63</td>
							<td>
									<div class="form-group">
										<select name="type_63" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_63').'"';}?> name="script_63" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_63').'"';}?> name="image_63" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_63"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>64</td>
							<td>
									<div class="form-group">
										<select name="type_64" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_1').'"';}?> name="script_64" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_1').'"';}?> name="image_64" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_64"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>65</td>
							<td>
									<div class="form-group">
										<select name="type_65" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_65').'"';}?> name="script_65" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_65').'"';}?> name="image_65" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_65"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>66</td>
							<td>
									<div class="form-group">
										<select name="type_66" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_66').'"';}?> name="script_66" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_66').'"';}?> name="image_66" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_66"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>67</td>
							<td>
									<div class="form-group">
										<select name="type_67" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_67').'"';}?> name="script_67" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_67').'"';}?> name="image_67" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_67"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>68</td>
							<td>
									<div class="form-group">
										<select name="type_68" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_68').'"';}?> name="script_68" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_68').'"';}?> name="image_68" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_68"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>69</td>
							<td>
									<div class="form-group">
										<select name="type_69" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_69').'"';}?> name="script_69" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_69').'"';}?> name="image_69" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_69"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>70</td>
							<td>
									<div class="form-group">
										<select name="type_70" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_70').'"';}?> name="script_70" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_70').'"';}?> name="image_70" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_70"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>71</td>
							<td>
									<div class="form-group">
										<select name="type_71" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_71').'"';}?> name="script_71" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_71').'"';}?> name="image_71" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_71"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>72</td>
							<td>
									<div class="form-group">
										<select name="type_72" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_72').'"';}?> name="script_72" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_72').'"';}?> name="image_72" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_72"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>73</td>
							<td>
									<div class="form-group">
										<select name="type_73" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_73').'"';}?> name="script_73" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_73').'"';}?> name="image_73" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_73"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>74</td>
							<td>
								<div class="form-group">
										<select name="type_74" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_74').'"';}?> name="script_74" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_74').'"';}?> name="image_74" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_74"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>75</td>
							<td>
									<div class="form-group">
										<select name="type_75" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_75').'"';}?> name="script_75" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_75').'"';}?> name="image_75" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_75"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>76</td>
							<td>
									<div class="form-group">
										<select name="type_76" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_76').'"';}?> name="script_76" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_76').'"';}?> name="image_76" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_76"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>77</td>
							<td>
									<div class="form-group">
										<select name="type_77" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_77').'"';}?> name="script_77" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_77').'"';}?> name="image_77" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_77"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>78</td>
							<td>
									<div class="form-group">
										<select name="type_78" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_78').'"';}?> name="script_78" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_78').'"';}?> name="image_78" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_78"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>79</td>
							<td>
									<div class="form-group">
										<select name="type_79" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_79').'"';}?> name="script_79" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_79').'"';}?> name="image_79" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_79"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>80</td>
							<td>
									<div class="form-group">
										<select name="type_80" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_80').'"';}?> name="script_80" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_80').'"';}?> name="image_80" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_80"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>81</td>
							<td>
									<div class="form-group">
										<select name="type_81" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_1').'"';}?> name="script_81" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_1').'"';}?> name="image_81" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_81"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>82</td>
							<td>
									<div class="form-group">
										<select name="type_82" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_82').'"';}?> name="script_82" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_82').'"';}?> name="image_82" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_82"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>83</td>
							<td>
									<div class="form-group">
										<select name="type_83" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_83').'"';}?> name="script_83" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_83').'"';}?> name="image_83" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_83"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>84</td>
							<td>
									<div class="form-group">
										<select name="type_84" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_84').'"';}?> name="script_84" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_84').'"';}?> name="image_84" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_84"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>85</td>
							<td>
									<div class="form-group">
										<select name="type_85" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_85').'"';}?> name="script_85" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_85').'"';}?> name="image_85" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_85"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>86</td>
							<td>
									<div class="form-group">
										<select name="type_86" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_86').'"';}?> name="script_86" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_86').'"';}?> name="image_86" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_86"   id="add_image_one"  />
									</div>
									
							</td>
						</tr>
						<tr>
							<td>87</td>
							<td>
									<div class="form-group">
										<select name="type_87" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_87').'"';}?> name="script_87" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_87').'"';}?> name="image_87" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_87"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>88</td>
							<td>
									<div class="form-group">
										<select name="type_88" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_88').'"';}?> name="script_88" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_88').'"';}?> name="image_88" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_88"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>89</td>
							<td>
									<div class="form-group">
										<select name="type_89" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_89').'"';}?> name="script_89" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_89').'"';}?> name="image_89" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_89"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>90</td>
							<td>
									<div class="form-group">
										<select name="type_90" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_90').'"';}?> name="script_90" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_90').'"';}?> name="image_90" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_90"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>91</td>
							<td>
									<div class="form-group">
										<select name="type_91" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_91').'"';}?> name="script_91" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_91').'"';}?> name="image_91" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_91"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>92</td>
							<td>
									<div class="form-group">
										<select name="type_92" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_92').'"';}?> name="script_92" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_92').'"';}?> name="image_92" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_92"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>93</td>
							<td>
									<div class="form-group">
										<select name="type_93" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_93').'"';}?> name="script_93" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_93').'"';}?> name="image_93" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_93"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>94</td>
							<td>
									<div class="form-group">
										<select name="type_94" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_94').'"';}?> name="script_94" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_94').'"';}?> name="image_94" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_94"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>95</td>
							<td>
									<div class="form-group">
										<select name="type_95" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_95').'"';}?> name="script_95" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_95').'"';}?> name="image_95" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_95"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>96</td>
							<td>
									<div class="form-group">
										<select name="type_96" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_96').'"';}?> name="script_96" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_96').'"';}?> name="image_96" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_96"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>97</td>
							<td>
									<div class="form-group">
										<select name="type_97" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_97').'"';}?> name="script_97" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_97').'"';}?> name="image_97" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_97"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>98</td>
							<td>
									<div class="form-group">
										<select name="type_98" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_98').'"';}?> name="script_98" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_98').'"';}?> name="image_98" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_98"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>99</td>
							<td>
									<div class="form-group">
										<select name="type_99" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_99').'"';}?> name="script_99" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_99').'"';}?> name="image_99" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_99"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>100</td>
							<td>
									<div class="form-group">
										<select name="type_100" id="" class="form-control">
											<option value="3" >Select</option>
											<option value="0">Link</option>
											<option value="1">Script</option>
										</select>
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'script_100').'"';}?> name="script_100" class="form-control"  placeholder="Insert Script" />
									</div>								
									<div class="form-group">
										<input type="text" <?php if(isset($_GET['edit'])){echo 'value="'.get_table_data_single_row('jobs2','id',$_GET['edit'],'image_100').'"';}?> name="image_100" class="form-control"  placeholder="Insert Link" />
									</div>
									<div class="form-group">
										<input type="file"  name="file_100"   id="add_image_one"  />
									</div>
							</td>
						</tr>
						<tr>
							<td>
								
							</td>
							<td>
								<input type="submit" value="Submit" class="btn btn-success form-control"  />
							</td>
						</tr>
					</table>
				</div>
			</div>
		</form>
	</div>
<?php
  include 'include/footer.php';
?>