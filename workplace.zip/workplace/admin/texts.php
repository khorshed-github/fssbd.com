<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
  if(loggedin() == false){
	  header("Location:login.php");
  }
error_reporting(0);
$text_update_msg = '';
if(isset($_POST['edit_text_id'])) {
    $edit_text_id1 = sanetize($_POST['edit_text_id']);
    $edit_text = $_POST['edit_text'];
    $edit_heading = $_POST['edit_heading'];
    $edit_date = date('Y-m-d',time());
    $sql = mysqli_query($db,"UPDATE `middletexts` SET `text_1`='$edit_text',`date`='$edit_date',`heading`= '$edit_heading' WHERE `id`='$edit_text_id1'");
    if($sql == true){
        $text_update_msg = '<div class="btn btn-success">Successfully updated</div>';
        header("Location: texts.php?text_edit=$edit_text_id1");
    }else {
        $text_update_msg = '<div class="btn btn-danger">Update error</div>';
    }
}
?>
<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
	 <div class="" style="text-decoration:none;">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h4>Texts Area</h4>
			</div>
			<span  ><?php if(!empty($error)){echo '<div class="alert alert-danger">'.$error[0].'</div> ';}?></span>
									
			<div class="panel-body table-responsive">
			    <?php if(isset($_GET['text_edit'])){
			        $text_edit_id = sanetize($_GET['text_edit']);
		        ?>
			    <div class="panel panel-primary">
			        <div class="panel-heading">Text Edit</div>
			        <div class="panel-body">
			            <div class="admin-text-edit">
			                <form class="" method="post" action="texts.php">
			                    <input type="hidden" name="edit_text_id" value="<?php echo $text_edit_id;?>">
			                    <div class="form-group">
			                        <input name="edit_heading" class="form-control"  value="<?php echo get_table_data_single_row('middletexts','id',$text_edit_id,'heading');?>" />
			                    </div>
								<div class="form-group">
			                        <textarea name="edit_text" class="form-control" rows="30"><?php echo get_table_data_single_row('middletexts','id',$text_edit_id,'text_1');?></textarea>
			                    </div>
			                    <div><?php $text_update_msg;?></div>
			                    <div class="admin-text-edit-btns">
			                        <a href="texts.php" class="btn btn-default">Back</a>
			                        <button class="btn btn-primary" type="submit">Save Changes</button>
			                    </div>
			                </form>
			            </div>
			        </div>
			    </div> 
		        <?php
			    }else{
			    ?>
				<table class="table table-bordered table-striped">
					<tr class="text-nowrap" >
						<th class="text-center">id</th>
						<th class="text-center">Heading</th>
						<th class="text-center">Text</th>
						<th class="text-center">Updated Date</th>
						<th class="text-center">Action</th>
					</tr>
					<?php
					foreach(get_table_data_all('middletexts') as $text){
					?>
					<tr>
			            <td><?php echo $text['id'];?></td>
			            <td><?php echo $text['heading'];?></td>
			            <td><?php echo $text['text_1'];?></td>
			            <td><?php echo $text['date'];?></td>
			            <td class="text-nowrap">
					         <a href="texts.php?text_edit=<?php echo $text['id'];?>" class="btn btn-warning">Edit</a>
	                    </td>
					</tr>
					<?php }?>
				</table>
				<?php }?>
			</div>
		 </div>
	 </div>  
</div>
<?php
  include 'include/footer.php';
?>