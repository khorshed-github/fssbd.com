<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
  if(loggedin() == false){
	  header("Location:login.php");
  }

  if(checkaccess($_SESSION['flc_admin'], 'dynamics.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
error_reporting(0);
if(isset($_GET['delete'])){
    $id = sanetize($_GET['delete']);
    $sql = mysqli_query($db, "DELETE FROM `working_sites` WHERE `id` = '$id'");
    if($sql == true){
        header('Location:sites.php');
    }
}

if(isset($_POST['edit_step'])){
	$step 	= sanetize($_POST['edit_step']);
	$url 	= sanetize($_POST['edit_url']);
	$id 	= sanetize($_GET['edit']);
    $sql = mysqli_query($db, "UPDATE `working_sites` SET `step` = '$step',`url` = '$url' WHERE `id` = '$id'");
    if($sql == true){
        header("Location:sites.php");
    }
}
if(isset($_POST['step'])){
	$step 	= sanetize($_POST['step']);
	$url 	= sanetize($_POST['url']);
    $sql = mysqli_query($db, "INSERT INTO `working_sites` (`step`,`url`,`status`)VALUES('$step','$url','1')");
	
    if($sql == true){
        header("Location:sites.php");
    }
}
?>
	
	<div class="container col-md-10 col-sm-10"  >
		 
		 <div href="#" class="" style="text-decoration:none;">
			<?php if(isset($_GET['new'])){?>
				<div class="panel panel-default">
					<div class="panel-heading">
						ADD New Site
					</div>
					<div class="panel-body">
						<form action="sites.php" method="post" class="form-inline" enctype="multipart/form-data" >
							<div class="form-group">
								<input type="text" name="step"  placeholder="Step" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="text" name="url" placeholder="URL" class="form-control"  />
							</div>
							
							<div class="form-group">
								<input type="submit" value="Insert " class="btn btn-success"   />
							</div>
						</form>
						
					</div>
				</div>
			<?php }else if($_GET['edit']){?>
				<div class="panel panel-default">
					<div class="panel-heading">
						Edit
					</div>
					<div class="panel-body">
						<form action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post" class="form-inline" enctype="multipart/form-data" >
							<div class="form-group">
								<input type="text" name="edit_step" value="<?php echo get_table_data_single_row('working_sites','id',$_GET['edit'],'step');?>" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="text" name="edit_url" <?php echo 'value="'.get_table_data_single_row('working_sites','id',sanetize($_GET['edit']),'url').'"'; ?> placeholder="script" class="form-control"  />
							</div>
						
							<div class="form-group">
								<input type="submit" value="Insert " class="btn btn-success"   />
							</div>
						</form>
						
					</div>
				</div>
			<?php }?>
			<div class="panel panel-default">
				<div class="panel-heading">
					<h4>Working Sites</h4>
				</div>
				
				<div class="panel-body table-responsive">
					<table class="table table-bordered table-striped">
						<tr class="text-nowrap" >
							<th>Action</th>
							<th>Step</th>
							<th>Site URL</th>
						</tr>
						<?php 
						foreach(get_table_data_all('working_sites') as $users){?>
							<tr>
								
								<td>
									<a href="sites.php?edit=<?php echo $users['id'];?>" class="btn btn-success btn-xs" >Edit</a>
									<a href="sites.php?delete=<?php echo $users['id'];?>" class="btn btn-danger btn-xs" >Delete</a>
								</td>
							
								<td><?php echo $users['step']?></td>
								<td><?php echo $users['url']?></td>
								
							</tr>
						<?php }?>
					</table>
					<div class="form-group">
						<a href="sites.php?new" class="btn btn-success">Add New Site</a>
					</div>
				</div>
				
			</div>
		
			</div>
		</div>
	</div>
<?php
  include 'include/footer.php';
?>