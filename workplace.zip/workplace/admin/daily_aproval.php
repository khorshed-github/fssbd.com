<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
  error_reporting(0);
  //print_r($_SESSION['aproval_checked']);
  if(loggedin() == false){
	  header("Location:login.php");
  }
	if(checkaccess($_SESSION['flc_admin'], 'daily_aproval.php') == false){
		echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
		You don\'t have access to this page
		</div>';
		die();
	}
	$hour =  gmdate('G', time()+(6*60*60));
	/*if($hour !== '0'){
		echo 'Request will be available at 12am';
		die();
	}*/
if(isset($_POST['percent'])){
	$percent = sanetize($_POST['percent']);
	foreach($_SESSION['aproval_checked'] as $ids){
		$userinfo = get_table_data_specific('flc_users','id',$ids);
		$userinfo = mysqli_fetch_assoc($userinfo);
		$cut = ($userinfo['p_balance'] / 100) * $percent;
		$amount = $userinfo['p_balance'] - $cut;
		$new_s_balance = $userinfo['s_balance'] + $amount;
		$update = mysqli_query($db,"UPDATE `flc_users` SET `s_balance` = '$new_s_balance',`p_balance` = '0' WHERE `id` = '$ids'");
		
	}
	//$sql = mysqli_query($db, "UPDATE `flc_users` SET `p_balance` = '0'");
	$sql = mysqli_query($db, "SELECT * FROM `flc_users` WHERE `p_balance` != '0.00'");
	foreach($sql as $idds){
	    $userinfo = get_table_data_specific('flc_users','id',$idds);
		$userinfo = mysqli_fetch_assoc($userinfo);
		
		$amount = $userinfo['p_balance'];
		$new_s_balance = $userinfo['s_balance'] + $amount;
		$update = mysqli_query($db,"UPDATE `flc_users` SET `s_balance` = '$new_s_balance',`p_balance` = '0' WHERE `id` = '$idds'");
	}
	unset($_SESSION['aproval_checked']);
	header('Location:daily_aproval.php');
}
?>
	
	<div class="container col-md-10 col-sm-10"  >
		 <div href="#" class="" style="text-decoration:none;">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h4>Daily Aprovals</h4>
				</div>
				<div class="panel-body table-responsive">
					<div class="form-group">
						<div class="btn btn-success select_all_aproval" >Select All</div>
					</div>
					<table class="table table-bordered table-striped">
						<tr class="text-nowrap" >
							<th>Check for Aprove</th>
							<th>User-name</th>
							<th>Number</th>
							<th>Primary Balance</th>
						</tr>
						<?php 
						if(!isset($_GET['list'])){
						foreach(get_ten_data_aproval('flc_users') as $users){?>
							<tr>
								<td>
									<input type="checkbox" class="checked_for_aproval" value="<?php echo $users['id'];?>"  <?php if(is_select_aproval($users['id']) == true){echo 'checked';}?>  /> 
								</td>
								<td><?php echo $users['username']?></td>
								<td><?php echo $users['number']?></td>
								
								<td><?php echo $users['p_balance']?></td>
							</tr>
						<?php }}else{
							foreach(paginationed_aproval($_GET['list'],'flc_users') as $users){
							?>
							<tr>
								<td>
									<input type="checkbox"  class="checked_for_aproval" value="<?php echo $users['id'];?>"  <?php if(is_select_aproval($users['id']) == true){echo 'checked';}?>  /> 
								</td>
								<td><?php echo $users['username']?></td>
								<td><?php echo $users['number']?></td>
								
								<td><?php echo $users['p_balance']?></td>
							</tr>
							<?php }}?>
					</table>
				</div>
				<div class="pagination">
					  <?php 
					  $count = 0;
					  
					  $rows = pagination_list_aproval('flc_users');
					  if($rows > 1){
						for($count = 0; $count < $rows; $count++ ){?>
						<li><a class="table_pagination_links <?php if($_GET['list'] == $count){echo 'active';}?>" <?php if($count  > ($_GET['list'] + 4)){echo 'style="display:none;"';}else if($count  < ($_GET['list'] - 4)){echo 'style="display:none;"';}?>  href="daily_aproval.php?list=<?php echo $count;?>"><?php echo $count+1;?></a></li>
					  <?php }}?>
				</div>
				
			 </div>
				<form action="daily_aproval.php" method="post" class="form-inline"  >
					<div class="form-group">
						<input type="text" name="percent" placeholder="Insert Percentage"  class="form-control"    />
						<input type="submit" class="btn btn-success"  value="Submit" />
					</div>
				</form>
				<br />
		 </div>
		 
	</div>
<?php
  include 'include/footer.php';
?>