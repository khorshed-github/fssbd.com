<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
  if(loggedin() == false){
	  header("Location:login.php");
  }
error_reporting(0);
  if(checkaccess($_SESSION['flc_admin'], 'act_request.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
  //sendsms('01813404900','test_message');
  //sendsms('01813404900','Dear SELF EMPLOYMENTS user, You have got '.$bdt.'TK joining commission for level '.$level.' User '.get_table_data_single_row('flc_users','id',$uid,'number'));
    			
  //print_r($_SESSION);
  //error_reporting(0);
if(isset($_GET['accept'])){
	$id = sanetize($_GET['accept']);
	$uid = get_table_data_single_row('i_purchase','id',$id,'uid');
	$amount = get_table_data_single_row('i_purchase','id',$id,'amount');
	$rand = get_table_data_single_row('i_purchase','id',$id,'token');
	$sql = mysqli_query($db, "UPDATE `i_purchase` SET `status` = '1' WHERE `id` = '$id'");
	sendsms(get_table_data_single_row('flc_users','id',$uid,'number'),'Dear User, You have successfully purchased a copy of software, Your token is '.$rand.' Please collect your copy from any delivery Point');
	if($sql == true){
		$uplvl = get_uppler_levels($uid,get_table_data_all('purchase_level')->num_rows);
		//print_r($uplvl);
		foreach($uplvl as $key => $ids){
			if($ids !== 0){
				$level = $key+1;
				$type = 13 + $level;
				$perc = get_table_data_single_row('purchase_level','level',$level,'perc');
				$comm = ($amount / 100) * $perc;
				$old_balance = get_table_data_single_row('flc_users','id',$ids,'balance');
				$new_balance = $old_balance + $comm;
				//echo $new_balance.'<br/>';
				$update = mysqli_query($db, "UPDATE `flc_users` SET `balance` = '$new_balance' WHERE `id` = '$ids'");
				accounts_update($ids, $comm,'Product purchase referal for  Level '.$level.' User '.get_table_data_single_row('flc_users','id',$uid,'username'), $old_balance, $new_balance,'cr');
				if($type > 19){
					income_entry($ids,$uid,$comm,19,$type);
				}else{
					income_entry($ids,$uid,$comm,$type,$type);
				}
			}
		}
		header('Location:purchases.php');
	}else{
		echo mysqli_error($db);
	}
	
}
if(isset($_GET['cancel'])){
	$id = sanetize($_GET['cancel']);
	$sql = mysqli_query($db, "UPDATE `i_purchase` SET `status` = '2' WHERE `id` = '$id'");
	header('Location:purchases.php');
}
?>
	
	<div class="container col-md-10 col-sm-10"  >
		 
		 <div href="#" class="" style="text-decoration:none;">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h4>Purchase Requests</h4>
				</div>
				<div class="panel-body table-responsive">
					<div class=" panel panel-default col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="panel-heading row">
							<h4>Total Seuccessfull <br />Sell</h4>
						</div>
						<div class="panel-body">
							<h2><?php echo get_table_data_specific('i_purchase','status','1')->num_rows;?> </h2>
						</div>
					</div><div class=" panel panel-default col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="panel-heading row">
							<h4>Total Sell <br />Amount</h4>
						</div>
						<div class="panel-body">
							<h2><?php echo get_sell_total();?> BDT</h2>
						</div>
					</div>
					<div class=" panel panel-default col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="panel-heading row">
							<h4>Total Commission <br />Distributed</h4>
						</div>
						<div class="panel-body">
							<h2><?php echo get_distributed_total();?> BDT</h2>
						</div>
					</div>
					<table class="table table-bordered table-striped">
						<tr class="text-nowrap" >
							<th>Action</th>
							<th>User-Number</th>
							<th>Sender Number</th>
							<th>Sent Amount</th>
							<th>Transection ID</th>
							<th>Delivery Status</th>
							<th>Token No</th>
							<th>Delivered By</th>
							<th>Date</th>
							<th>Time</th>
						</tr>
						<?php 
						if(!isset($_GET['list'])){
						foreach(get_ten_data('i_purchase') as $users){?>
							<tr>
								<td>
									<?php if($users['status'] == '0'){?>
										<a class="btn btn-success btn-sm" href="purchases.php?accept=<?php echo $users['id'];?>">Accept</a>
										<a class="btn btn-danger btn-sm"  href="purchases.php?cancel=<?php echo $users['id'];?>">Cancel</a>
									<?php }else if($users['status'] == '1'){
										echo 'Accepted';
									}?>
								</td>
								<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'number')?></td>
								<td><?php echo $users['sender']?></td>
								<td><?php echo $users['amount']?></td>
								<td><?php echo $users['trxid']?></td>
								<td><?php if($users['delivery'] == '0'){echo 'Pending';}else if($users['delivery'] == '1'){ echo 'delivered';}?></td>
								<td><?php if($users['delivery'] == '1'){ echo $users['token'];}?></td>
								<td><?php if($users['delivery'] == '1'){ echo get_table_data_single_row('flc_users','id',$users['dp'],'number');}?></td>
								<td><?php echo $users['date']?></td>
								<td><?php echo $users['time']?></td>
								
							</tr>
						<?php }}else{
							foreach(paginationed($_GET['list'],'i_purchase') as $users){
							?>
							<tr>
								<td>
									<?php if($users['status'] == '0'){?>
										<a class="btn btn-success btn-sm" href="purchases.php?accept=<?php echo $users['id'];?>">Accept</a>
										<a class="btn btn-danger btn-sm"  href="purchases.php?cancel=<?php echo $users['id'];?>">Cancel</a>
									<?php }else if($users['status'] == '1'){
										echo 'Accepted';
									}?>
								</td>
								<td><?php echo get_table_data_single_row('flc_users','id',$users['uid'],'number')?></td>
								<td><?php echo $users['sender']?></td>
								<td><?php echo $users['amount']?></td>
								<td><?php echo $users['trxid']?></td>
								<td><?php if($users['delivery'] == '0'){echo 'Pending';}else if($users['delivery'] == '1'){ echo 'delivered';}?></td>
								<td><?php if($users['delivery'] == '1'){ echo $users['token'];}?></td>
								<td><?php if($users['delivery'] == '1'){ echo get_table_data_single_row('flc_users','id',$users['dp'],'number');}?></td>
								<td><?php echo $users['date']?></td>
								<td><?php echo $users['time']?></td>
							</tr>
							<?php }}?>
					</table>
				</div>
				<div class="pagination">
					  <?php 
					  $count = 0;
					  
					  $rows = pagination_list('i_purchase');
					  if($rows > 1){
						for($count = 0; $count < $rows; $count++ ){?>
						<li><a class="table_pagination_links <?php if($_GET['list'] == $count){echo 'active';}?>" <?php if($count  > ($_GET['list'] + 4)){echo 'style="display:none;"';}else if($count  < ($_GET['list'] - 4)){echo 'style="display:none;"';}?>  href="purchases.php?list=<?php echo $count;?>"><?php echo $count+1;?></a></li>
					  <?php }}?>
				</div>
			 </div>
		 </div>
		
		
		
		 
		 
	</div>
<?php
  include 'include/footer.php';
?>
