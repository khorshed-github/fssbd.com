<?php
  include 'include/head.php';
  include 'include/header.php';
  include 'include/nav.php';
  if(loggedin() == false){
	  header("Location:login.php");
  }

  if(checkaccess($_SESSION['flc_admin'], 'dynamics.php') == false){
	echo '<div class="col-md-9 col-sm-9 alert alert-danger text-center" >
	You don\'t have access to this page
	</div>';
	die();
}
error_reporting(0);
if(isset($_GET['delete'])){
    $id = sanetize($_GET['delete']);
    $sql = mysqli_query($db, "DELETE FROM `adds` WHERE `id` = '$id'");
    if($sql == true){
        header('Location:adds.php');
    }
}

if(isset($_POST['edit_value'])){
	$value 	= sanetize($_POST['edit_value']);
	$id 	= sanetize($_GET['edit']);
    $sql = mysqli_query($db, "UPDATE `dynamics` SET `value` = '$value' WHERE `id` = '$id'");
    if($sql == true){
        header("Location:dynamics.php");
    }
}
?>
	
	<div class="container col-md-10 col-sm-10"  >
		 
		 <div href="#" class="" style="text-decoration:none;">
			<?php if(isset($_GET['new'])){?>
				<div class="panel panel-default">
					<div class="panel-heading">
						Place New Ad
					</div>
					<div class="panel-body">
						<form action="adds.php" method="post" class="form-inline" enctype="multipart/form-data" >
							<div class="form-group">
								<select name="type" id="" class="form-control"  >
									<option value="0">Select Ad Type</option>
									<option value="1">Script</option>
									<option value="2">Link</option>
								</select>
							</div>
							<div class="form-group">
								<input type="text" name="script"  placeholder="script" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="text" name="link" placeholder="link" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="file" name="file" placeholder="image" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="text" name="date"  id="datepicker"  value="<?php echo dates();?>" name="file" placeholder="image" class="form-control"  />
							</div>
							<div class="form-group">
								<input type="submit" value="Insert " class="btn btn-success"   />
							</div>
						</form>
						
					</div>
				</div>
			<?php }else if($_GET['edit']){?>
				<div class="panel panel-default">
					<div class="panel-heading">
						Edit
					</div>
					<div class="panel-body">
						<form action="<?php echo $_SERVER['REQUEST_URI'];?>" method="post" class="form-inline" enctype="multipart/form-data" >
							<div class="form-group">
								<?php echo get_table_data_single_row('dynamics','id',$_GET['edit'],'description');?>
							</div>
							<div class="form-group">
								<input type="text" name="edit_value" <?php echo 'value="'.get_table_data_single_row('dynamics','id',sanetize($_GET['edit']),'value').'"'; ?> placeholder="script" class="form-control"  />
							</div>
						
							<div class="form-group">
								<input type="submit" value="Insert " class="btn btn-success"   />
							</div>
						</form>
						
					</div>
				</div>
			<?php }?>
			<div class="panel panel-default">
				<div class="panel-heading">
					<h4>Banner Adds</h4>
				</div>
				
				<div class="panel-body table-responsive">
					<table class="table table-bordered table-striped">
						<tr class="text-nowrap" >
							<th>Action</th>
							<th>Description</th>
							<th>Value</th>
							
						</tr>
						<?php 
						
						foreach(get_table_data_all('dynamics') as $users){?>
							<tr>
								
								<td>
									<a href="dynamics.php?edit=<?php echo $users['id'];?>" class="btn btn-success btn-xs" >Edit</a>
								</td>
							
								<td><?php echo $users['description']?></td>
								<td><?php echo $users['value']?></td>
								
							</tr>
						<?php }?>
					</table>
				</div>
				
			</div>
		
			</div>
		</div>
	</div>
<?php
  include 'include/footer.php';
?>